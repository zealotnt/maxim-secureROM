/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2000-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: inifunc.h
 * $Date: 2014/06/05 15:33:46EDT $
 */
#ifndef INC_INIFUNC_H
#define INC_INIFUNC_H

#if defined(WIN32) || defined(_WINDOWS) || defined(MSC_VER)

/* Just use the stock standard */
#define CT_GetPrivateProfileString GetPrivateProfileString

#else

/**
 * Clone the Windows GetPrivateProfileString() function. The only difference is
 * that this function will read the ini file from ($HOME)/.cryptoki directory.
 */
int CT_GetPrivateProfileString(const unsigned char *sectionIn,
							const char *keyIn,
							const char *defaultValue,
							char *buf,
							const int bufLen,
							const char *filename);
#endif

#endif /* INC_INIFUNC_H */
