/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2009-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: endyn.h
 * $Date: 2014/09/18 16:39:12EDT $
 */
#ifndef INC_ENDYN_H
#define INC_ENDYN_H

#include <integers.h>

#ifdef __cplusplus
extern "C" {
#endif


// Only one of IS_BIG_ENDIAN or IS_LITTL_ENDIAN may be defined
#if defined(IS_BIG_ENDIAN) && defined(IS_LITTLE_ENDIAN)
    #error Ambiguous predefined endianess for the platform
#endif

/*
 * If IS_BIG_ENDIAN and IS_LITTLE_ENDIAN are both undefined, attempt
 * to determine endianess from the compiler.
 *
 * This is intended for supported PTK platforms and is not intended
 * to be exhaustive.
 *
 * When building FM's IS_BIG_ENDIAN or IS_LITTLE_ENDIAN will be preset
 * by cfgbuild.h
 */
#if !defined(IS_BIG_ENDIAN) && !defined(IS_LITTLE_ENDIAN)
    /*
     * Assume Windows is always little endian (Windows can also be built for ARM
     * but it is typically little endian and not currently supported by PTK.)
     */
    # if defined(_WIN32) || defined(_WIN64) || defined(__WIN32__) || defined(__TOS_WIN__) || defined(__WINDOWS__)
        #define IS_LITTLE_ENDIAN
    #else
        /*
         * Check common compiler defined byte order macros.
         */
        #if defined(__BYTE_ORDER__)
            #if   __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
                #define IS_BIG_ENDIAN
            #elif __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
                #define IS_LITTLE_ENDIAN
            #else
                #error Unsupported byte order for the platform
            #endif
        #elif defined(__BYTE_ORDER)
            #if   __BYTE_ORDER == __BIG_ENDIAN
                #define IS_BIG_ENDIAN
            #elif __BYTE_ORDER == __LITTLE_ENDIAN
                #define IS_LITTLE_ENDIAN
            #else
                #error Unsupported byte order for the platform
            #endif
        #elif defined(_BYTE_ORDER)
            #if _BYTE_ORDER == _BIG_ENDIAN
                #define IS_BIG_ENDIAN
            #elif _BYTE_ORDER == _LITTLE_ENDIAN
                #define IS_LITTLE_ENDIAN
            #else
                #error Unsupported byte order for the platform
            #endif
        #endif
    #endif
#endif

/*
 * is current platform Big/Little endian?
 */
int IsBigEndian (void);
//
void BigEndianBuf(void * tgt, void * src, size_t len);

uint16			fromBEs(uint16 val);
uint16			toBEs(uint16 val);
unsigned long	fromBEl(uint32 val, const char* file, int line);
uint32			toBEl(unsigned long val, const char* file, int line);

#ifdef IS_BIG_ENDIAN

#define hton_short(x) (x)
#define ntoh_short(x) (x)
#define hton_long(x) (x)
#define ntoh_long(x) (x)

#elif defined IS_LITTLE_ENDIAN

#define hton_short(x) ((((x) >> 8)&0xffu) | (((x) << 8) & 0xff00u))
#define ntoh_short(x) hton_short(x)
#define hton_long(x) ((((x) >> 24)&0xffuL) | (((x) >> 8) & 0xff00uL) | (((x) << 8) & 0xff0000uL) | (((x) << 24) & 0xff000000uL))
#define ntoh_long(x) hton_long(x)

#else // unknown endian, use runtime functions in util.lib/libutil

#define hton_short(x) toBEs(x)
#define ntoh_short(x) fromBEs(x)
#define hton_long(x) toBEl(x,__FILE__,__LINE__)
#define ntoh_long(x) fromBEl(x,__FILE__,__LINE__)

#endif

#ifdef __cplusplus
}
#endif

#endif /* INC_ENDYN_H */
