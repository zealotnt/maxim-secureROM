/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2009-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: ctauth.h
 * $Date: 2014/06/05 15:33:31EDT $
 */
#ifndef CTAUTH_H
#define CTAUTH_H

#include "cryptoki.h"


#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

/* Creates the challenge response */
#ifdef WIN64 
__declspec(dllexport) 
#endif
CK_RV CT_Gen_AUTH_Response(CK_BYTE_PTR pPin,
                CK_ULONG ulPinLen, CK_BYTE_PTR pChallenge,
                CK_ULONG ulChallengeLen, CK_USER_TYPE userType,
                CK_BYTE_PTR pResponse, CK_ULONG_PTR pulResponse);

#ifdef __cplusplus
}
#endif

#endif

