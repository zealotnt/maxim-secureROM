/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1997-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: logerr.h
 * $Date: 2014/06/05 15:33:10EDT $
 */
#ifndef INC_LOGERR_H
#define INC_LOGERR_H

#ifndef NOIDENT
#pragma ident "@(#)RELEASE VERSION $Name:  $ SafeNet Inc"
#endif

#include <integers.h>

/*
 * Error logging support
 */

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

#ifdef BITS16
#  ifndef FAR
#    define FAR far
#  endif
#else
#  ifndef FAR
#    define FAR
#  endif
#endif

int logerr(const char FAR * str,...);
int logtrace(const char FAR * str,...);
int logtrace2(const char * str, int param1, int param2);
int logerrmem(const char FAR * txt, const unsigned char FAR * data, size_t len);
int logmem(const char FAR * txt, const unsigned char FAR * data, size_t len);
void SetLogFile(char FAR * lname);
int GetLogLevel(void);
void SetLogLevel(int level);

#ifdef __cplusplus
}
#endif

#endif /* ifndef INC_LOGERR_H */
