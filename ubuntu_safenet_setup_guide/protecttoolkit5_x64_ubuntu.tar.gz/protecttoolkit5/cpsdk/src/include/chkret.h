/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2009-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: chkret.h
 * $Date: 2014/06/05 15:33:44EDT $
 */

#ifndef NOIDENT
#pragma ident "@(#)RELEASE VERSION $Name:  $ SafeNet Inc"
#endif

#ifndef CHKRET_INCLUDED
#define CHKRET_INCLUDED

#define CHECK_RV(msg, rv) \
	if ( rv ) { \
		CT_ErrorString(rv,ErrorString,sizeof(ErrorString)); \
		printf("%s: error %lx, %s\n", msg, (unsigned long)rv, ErrorString); \
	}
#define CHECK_RV_RET(msg, rv) \
	do { if ( rv ) { \
		CHECK_RV(msg, rv); \
		return rv; \
	} else { \
		printf("%s\r\n", msg);\
	} } while(0);

/* check for session and object leaks */
#define LeakCheck(txt) \
		rv = GetObjectCount(slotID, &objCount); \
		if ( objCount != ObjCount ) { \
			printf( "%s: Wrong object count %lu\n", \
				txt, (unsigned long)objCount ); \
			DestroyAllObjects(slotID, NULL); \
		} \
		rv = GetSessionCount(slotID, &sessionCount, &rwSessionCount); \
		if ( sessionCount != SessionCount || \
			 rwSessionCount != RwSessionCount) { \
			printf( "%s: Wrong session count ro = %lu rw = %lu\n", \
				txt, (unsigned long)sessionCount, \
				(unsigned long)rwSessionCount ); \
			C_CloseAllSessions(slotID); \
		} \
		getFreeMem(slotID, &freeMem); \
		if ( freeMem != FreeMem ) { \
			if ( iter > 0 ) \
				printf( "%s:possible token memory leak; freemem was %lu; now %lu\n", \
					txt, (unsigned long) FreeMem, (unsigned long)freeMem ); \
			FreeMem = freeMem; \
		}

#endif
