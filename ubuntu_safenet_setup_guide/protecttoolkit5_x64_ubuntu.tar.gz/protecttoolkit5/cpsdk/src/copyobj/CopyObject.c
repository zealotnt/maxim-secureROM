/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: CopyObject.c
 * $Date: 2014/06/05 15:33:06EDT $
 */
/**
 * @file
 *      Sample program to demonstrate the copying of an object.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cryptoki.h"
#include "ctutil.h"

/** 
 * This macro is used to check the return value of a function and print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr, "Error occured : %s\n", string);    \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Copy a specified object on the specified slot.
 *
 * @param slotId
 *  Id of the slot the object is stored in.
 *
 * @param pObjName
 *  Name of the object to copy
 */
static CK_RV copyObject(CK_SLOT_ID slotId, CK_CHAR* pObjName);


/**
 * Find a specified object.
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param pObjName
 *  Null-terminated name of the object to find.
 *
 * @param phObj
 *  Location to store the object handle of the object if found.
 */
static CK_RV findObject(CK_SESSION_HANDLE hSession,
                        CK_CHAR* pObjName, 
                        CK_OBJECT_HANDLE* phObj);

/**
 * Display usage information.
 */
static void usage(void)
{
    printf("\ncopyobject [-?] -n<ObjectName> [-s<SlotId>]");
    printf("\n");
    printf("\n-?            help display");
    printf("\n-s            id of the slot where the object is located");
    printf("\n-n            name of the object to copy");
    printf("\n");
    exit(0);
}

/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    char* pArg = NULL;
    char* pValue = NULL;

    /* default values */
    CK_SLOT_ID slotId = 0;
    CK_CHAR* pObjName = NULL;

    int i = 0;

    /*
     * Process command line arguments
     */
#define GET_VALUE                       \
            if (pArg[1] == '\0')        \
            {                           \
                if (++i < argc)         \
                {                       \
                    pValue = argv[i];   \
                }                       \
                else                    \
                {                       \
                    usage();            \
                }                       \
            }                           \
            else                        \
            {                           \
                pValue = pArg+1;        \
            }

    for (i = 1; i < argc; ++i)
    {
        if (argv[i][0] == '-')
        {
            pArg = &argv[i][1];

            switch (toupper((int)*pArg))
            {
                case '?':
                    usage();
                break;

                case 'S':
                    GET_VALUE;
                    slotId = atoi(pValue);
                break;

                case 'N':
                    GET_VALUE;
                    pObjName = (unsigned char*)pValue;
                break;
            }
        }
    }

	if (!pObjName)
	{
		usage();
	}
    /*
     * Start cryptoki.
     */
    rv = C_Initialize(NULL);
    if (rv != CKR_OK) 
    {
        fprintf(stderr,
                "Could not initialize cryptoki - 0x%lx (%s)",
                rv,
                strError(rv));

        return rv;
    }

    /* 
     * Do the copy.
     */
    rv = copyObject(slotId, pObjName);
    if (rv == CKR_OK)
    {
        printf("Object %s copied successfully\n", pObjName);
    }
    else
    {
        printf("Object %s was not copied due to errors\n", pObjName);
    }


    /*
     * Done :-)
     */
    rv = C_Finalize(NULL);
    if (rv != CKR_OK) 
    {
        fprintf(stderr,
                "C_Finalize error - 0x%lx (%s)",
                rv,
                strError(rv));
    }

    return rv;
}


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV copyObject(CK_SLOT_ID slotId, CK_CHAR* pObjName)
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;
    
    CK_OBJECT_HANDLE hSourceObj = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hCopiedObj = CK_INVALID_HANDLE;

    /*
     * Attribute template for the copied object.
     *
     * Since we do not know what type of object we are copying, the only
     * attributes that we can set are CKA_TOKEN and CKA_LABEL.
     */
    static CK_BBOOL bTrue = TRUE;
    CK_ATTRIBUTE copyTpl[] =
    {
        {CKA_TOKEN,     &bTrue,     sizeof(CK_BBOOL)},
    };
    CK_COUNT tplCount = sizeof(copyTpl)/sizeof(CK_ATTRIBUTE);

    /* open a session */
    rv = C_OpenSession(slotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    if (rv != CKR_OK) goto end;

    /* find the object */
    rv = findObject(hSession, pObjName, &hSourceObj);
    if (rv != CKR_OK) goto end;

    /* 
     * Copy the object
     */
    rv = C_CopyObject(hSession, hSourceObj, copyTpl, tplCount, &hCopiedObj);
    if (rv != CKR_OK) goto end;

    rv = C_CloseSession(hSession);
    if (rv != CKR_OK) goto end;

end:
    /*
     * Clean up... close any open sessions.
     */
    if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

    return rv;
}

static CK_RV findObject(CK_SESSION_HANDLE hSession,
                        CK_CHAR* pObjName, 
                        CK_OBJECT_HANDLE* phObj)
{
    CK_RV rv = CKR_OK;

    CK_OBJECT_HANDLE hObj = CK_INVALID_HANDLE;
    CK_COUNT objCount = 0;

    static CK_BBOOL bTrue = TRUE;
    CK_ATTRIBUTE tpl[] =
    {
        {CKA_TOKEN,     &bTrue,     sizeof(CK_BBOOL)},
        {CKA_LABEL,     NULL,       0}
    };
    CK_COUNT tplSize = sizeof(tpl)/sizeof(CK_ATTRIBUTE);

    /* check arguments */
    if ((hSession == CK_INVALID_HANDLE) || (pObjName == NULL) || (phObj == NULL))
    {
        return CKR_ARGUMENTS_BAD;
    }

    /*
     * Set the CKA_LABEL value and value len in the attribute template.
     */
    tpl[1].pValue = pObjName;
    tpl[1].valueLen = (CK_ULONG)strlen((char*)pObjName);

    /*
     * Attempt to find the object.
     */
    rv = C_FindObjectsInit(hSession, tpl, tplSize);
    if (rv != CKR_OK) return rv;

    /* we are only interested the first object found */
    rv = C_FindObjects(hSession, &hObj, 1, &objCount);
    if (rv != CKR_OK) return rv;

    rv = C_FindObjectsFinal(hSession);
    if (rv != CKR_OK) return rv;

    /* check the results */
    if (objCount > 0)
    {
        /* an object was found, give its handle to the output parameter */
        *phObj = hObj;
    }
    else
    {
        /* Error - No object matching the given name was found */
        rv = CKR_GENERAL_ERROR;
    }

    return rv;
}
