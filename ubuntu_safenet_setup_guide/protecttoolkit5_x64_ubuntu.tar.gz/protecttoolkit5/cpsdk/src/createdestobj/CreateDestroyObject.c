/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: CreateDestroyObject.c
 * $Date: 2014/06/05 15:33:34EDT $
 */
/**
 * @file
 *      Sample program to demonstrate the creation and destruction of an
 *      object.
 */

#include <stdio.h>
#include <memory.h>
#include <string.h>

#include "cryptoki.h"
#include "ctvdef.h"
#include "ctutil.h"
#include "genmacro.h"

/** 
 * This macro is used to check the return value of a function and print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr, "Error occured : %s\n", string);    \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Create a token data object on the given session, returning a handle to the 
 * object.
 *
 * @param hSession
 *  Session to use to create the object. If the object is to be a private 
 *  object, it is up to the caller to login.
 *
 * @param phObject 
 *  Location to store the handle of the created object.
 *
 */
static CK_RV createObject(CK_SESSION_HANDLE hSession,
                          CK_OBJECT_HANDLE_PTR phObject);

static CK_RV createAESObject(CK_SESSION_HANDLE hSession,
							CK_CHAR *keyValue,
							CK_SIZE keyLength,
                          CK_OBJECT_HANDLE_PTR phObject);

/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hObject = CK_INVALID_HANDLE; 
    CK_OBJECT_HANDLE hAesObject = CK_INVALID_HANDLE; 
    CK_SLOT_ID slotId = 0;
    CK_FLAGS sessionFlags = CKF_RW_SESSION;
	static CK_CHAR AesKeyValue[] = { 
		0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 
		0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0x01};

    CK_CHAR tmpChar = 0;

    ARG_USED(argc);
    ARG_USED(argv);

    /* Initialise the cryptoki API */
    rv = C_Initialize(NULL);
    CHECK_CK_RV_GOTO(rv, "C_Initialize", end);

    /* Obtain a session so we can perform cryptoki operations */
    rv = C_OpenSession(slotId, sessionFlags, NULL, NULL, &hSession);
    CHECK_CK_RV_GOTO(rv, "C_OpenSession", end);

    /*
     * Create an object
     */
    printf("Creating Data object ... ");

    rv = createObject(hSession, &hObject);
    CHECK_CK_RV_GOTO(rv, "CreateObject", end);

    printf("Object created\n");

    printf("Creating Aes object ... ");

    rv = createAESObject(hSession, AesKeyValue, sizeof(AesKeyValue), &hAesObject);
    CHECK_CK_RV_GOTO(rv, "CreateAesObject", end);

    printf("Object created\n");

    /* Prompt the user to continue on to destroy the objects */
    printf("Press <enter> to destroy the objects ...\n");
    scanf("%c", &tmpChar);

    /*
     * Destroy the objects
     */
    printf("Destroying objects ... ");

    rv = C_DestroyObject(hSession, hObject);
    CHECK_CK_RV_GOTO(rv, "DestroyObject", end);

    rv = C_DestroyObject(hSession, hAesObject);
    CHECK_CK_RV_GOTO(rv, "DestroyObject", end);

    printf("Objects destroyed\n");

    /* We've finished our work, close the session */
    rv = C_CloseSession(hSession);
    CHECK_CK_RV_GOTO(rv, "C_CloseSession", end);

    /* We no longer need the cryptoki API ... */
    rv = C_Finalize(NULL);
    CHECK_CK_RV_GOTO(rv, "C_Finalize", end);

end:

    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Error performing create/destroy operation : 0x%lx\n",
                rv);

        /*
         * Clean up... we don't care if there are any (more) errors.
         */
        if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

        C_Finalize(NULL);
    }
    else
    {
        printf("Successfully performed create/destroy operation.");
    }

    return rv;
}


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV createObject(CK_SESSION_HANDLE hSession,
                          CK_OBJECT_HANDLE_PTR phObject)
{
    CK_RV rv = CKR_OK;

    static CK_OBJECT_CLASS objClass = CKO_DATA;
    static CK_CHAR objValue[] = "The actual data of the object"; 
    static CK_CHAR objLabel[] = "NewDataObject";
    static CK_BBOOL boolTrue = TRUE;

    /* 
     * This is the objects template, which lays out some of the attributes the 
     * object will have when it is created. The object will also contain other
     * attributes, which are populated with default values. 
     * The attributes in the template are :
     * 
     *  CKA_CLASS - Points to the objClass variable which contains the value
     *              CKO_DATA, meaning this object is a data object.
     *  CKA_VALUE - Points to a char array containing what will be the actual 
     *              value of the data object.
     *  CKA_LABEL - Points to a char array containing what will be the label
     *              of the data object.
     *  CKA_TOKEN - Points to a CK_BBOOL variable containing the value TRUE.
     *              This object, therefore will be a token object, which 
     *              means it will persist on the token between sessions.
     */
    CK_ATTRIBUTE objectTemplate[] = 
    {
        {CKA_CLASS, &objClass,  sizeof(objClass)},
        {CKA_VALUE, NULL,       0},
        {CKA_LABEL, NULL,       0},
        {CKA_TOKEN, &boolTrue,  sizeof(boolTrue)}  
    };
    CK_SIZE objectSize = sizeof(objectTemplate) / sizeof(CK_ATTRIBUTE);

    CK_ATTRIBUTE* pAttr = NULL;

    /* Fill in the CKA_LABEL */
    pAttr = FindAttribute(CKA_LABEL, objectTemplate, objectSize);
    pAttr->pValue = objLabel;
    pAttr->ulValueLen = (CK_ULONG)strlen((char*)objLabel);

    /* Fill in the CKA_VALUE */
    pAttr = FindAttribute(CKA_VALUE, objectTemplate, objectSize);
    pAttr->pValue = objValue;
    pAttr->ulValueLen = (CK_ULONG)strlen((char*)objValue);

    rv = C_CreateObject(hSession, objectTemplate, objectSize, phObject);

    return rv;
}

/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV createAESObject(CK_SESSION_HANDLE hSession,
							CK_CHAR *keyValue,
							CK_SIZE keyLength,
                          CK_OBJECT_HANDLE_PTR phObject)
{
    CK_RV rv = CKR_OK;

	static CK_OBJECT_CLASS objClass = CKO_SECRET_KEY;
	static CK_KEY_TYPE objKType = CKK_AES;
	static CK_BBOOL boolTrue = 1;
	static CK_BBOOL boolFalse = 0;

    CK_ATTRIBUTE objectTemplate[] = 
    {
        {CKA_VALUE, NULL,       0},
        {CKA_CLASS, &objClass,  sizeof(objClass)},
        {CKA_KEY_TYPE, &objKType,  sizeof(objKType)},
        {CKA_TOKEN, &boolFalse,  sizeof(boolFalse)},
        {CKA_ENCRYPT, &boolTrue,  sizeof(boolTrue)},
        {CKA_DECRYPT, &boolTrue,  sizeof(boolTrue)}
    };
    CK_SIZE objectSize = sizeof(objectTemplate) / sizeof(CK_ATTRIBUTE);
    CK_ATTRIBUTE* pAttr = NULL;

	pAttr = &objectTemplate[0];
	pAttr->pValue = keyValue;
	pAttr->ulValueLen = keyLength;

    rv = C_CreateObject(hSession, objectTemplate, objectSize, phObject);

    return rv;
}
