/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: GenKeyPBE.c
 * $Date: 2014/06/05 15:33:35EDT $
 */
/**
 * @file
 *     Sample program to demonstrate the generation of a symmetric key using
 *     a password based encryption (PBE) algorithm.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cryptoki.h"
#include "ctvdef.h"
#include "ctutil.h"
#include "genmacro.h"

/** 
 * This macro is used to check the return value of a function and print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr,                                     \
                "%s - 0x%lx (%s)\n",                         \
                 string,                                    \
                 rv,                                        \
                 strError(rv));                             \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Generate a secret key.
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param phKey
 *  Location to store the handle of the new secret key.
 *
 * @param pIv
 *  Location to store the initialisation vector that results from the
 *  key generation. This will always be an 8 byte array.
 */
static CK_RV generateKeyPBE(CK_SESSION_HANDLE hSession,
                            CK_OBJECT_HANDLE* phKey,
                            CK_BYTE* pIv);

/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;

    CK_OBJECT_HANDLE hKey = CK_INVALID_HANDLE;
    CK_BYTE iv[8];

    ARG_USED(argc);
    ARG_USED(argv);

    /*
     * Start cryptoki.
     */
    rv = C_Initialize(NULL);
    CHECK_CK_RV_GOTO(rv, "Could not initialize cryptoki", end);

    rv = C_OpenSession(0, CKF_RW_SESSION, NULL, NULL, &hSession);
    CHECK_CK_RV_GOTO(rv, "Could not open session", end);

    rv = generateKeyPBE(hSession, &hKey, iv);
    if (rv == CKR_OK) 
    {
        printf("\nSecret key was successfully generated.\n");
    }
    else
    {
        printf("\nSecret key was not generated\n");
        goto end;
    }

    rv = C_CloseSession(hSession);
    CHECK_CK_RV_GOTO(rv, "Could not close session", end);


    rv = C_Finalize(NULL);
    CHECK_CK_RV_GOTO(rv, "Could not finalise cryptoki", end);

    return rv;

end:
    /*
     * Error handling code... clean up.
     */
    if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

    C_Finalize(NULL);

    return rv;
}


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV generateKeyPBE(CK_SESSION_HANDLE hSession,
                            CK_OBJECT_HANDLE* phKey,
                            CK_BYTE* pIv)
{
    CK_RV rv = CKR_OK;

    CK_OBJECT_HANDLE hKey = CK_INVALID_HANDLE;

    /*
     * Mechanism attributes. We are using a PBE based mechanism for the key
     * generation which requires a parameter - CK_PBE_PARAMS.
     */
    CK_MECHANISM mech;
    CK_PBE_PARAMS pbeParams;
    CK_BYTE pInitVector[8];
    static CK_BYTE pPassword[] = "keygenpwd";
    static CK_ULONG ulPasswordLen = sizeof(pPassword);
    static CK_BYTE pSalt[] = "salt";
    static CK_ULONG ulSaltLen = sizeof(pSalt);
    static CK_ULONG ulIteration = 1;

    /*
     * Attribute values
     */
    static CK_BBOOL ckTrue = TRUE;
    static CK_BBOOL ckFalse = FALSE;
    static CK_CHAR keyLabel[] = "pbekey_example";

    /*
     * Attribute template for the secret key.
     */
    CK_ATTRIBUTE tpl[] = 
    {
        {CKA_LABEL,         NULL,       0},
        {CKA_TOKEN,         &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_ENCRYPT,       &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_DECRYPT,       &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_SIGN,          &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_VERIFY,        &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_EXPORT,        &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_IMPORT,        &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_WRAP,          &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_UNWRAP,        &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_EXPORTABLE,    &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_EXTRACTABLE,   &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_MODIFIABLE,    &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_SENSITIVE,     &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_DERIVE,        &ckFalse,   sizeof(CK_BBOOL)},
    };
    CK_COUNT tplSize = sizeof(tpl)/sizeof(CK_ATTRIBUTE);
    
    CK_ATTRIBUTE* pAttr = NULL;

    /*
     * Prepare the mechanism parameter.
     */
    pbeParams.pInitVector = pInitVector;
    pbeParams.pPassword = pPassword;
    pbeParams.ulPasswordLen = ulPasswordLen;
    pbeParams.pSalt = pSalt;
    pbeParams.ulSaltLen = ulSaltLen;
    pbeParams.ulIteration = ulIteration;

    /*
     * Prepare the mechanism.
     */
    mech.mechanism = CKM_PBE_MD5_DES_CBC;
    mech.pParameter = &pbeParams;
    mech.parameterLen = sizeof(pbeParams);

    /* Fill in the key label */
    pAttr = FindAttribute(CKA_LABEL, tpl, tplSize);
    pAttr->pValue = keyLabel;
    pAttr->ulValueLen = (CK_ULONG)strlen((char*)keyLabel);

    /*
     * Generate the secret key
     */
    rv = C_GenerateKey(hSession, &mech, tpl, tplSize, &hKey);
    if (rv == CKR_OK)
    {
        /* copy results to output parameters */
        *phKey = hKey;
        memcpy(pIv, pbeParams.pInitVector, 8);
    }
    else
    {
        fprintf(stderr,
                "Could not generate secret key - 0x%lx (%s)",
                rv,
                strError(rv));
    }
    
    return rv;
}

