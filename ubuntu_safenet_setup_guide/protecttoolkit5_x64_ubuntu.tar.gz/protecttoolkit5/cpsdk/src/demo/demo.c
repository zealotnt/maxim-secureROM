/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1998-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: demo.c
 * $Date: 2014/06/05 15:33:08EDT $
 */
/**
 * @file
 *      Setup for E-commerce Demo for CRYPTOKI.
 *      Sets up a trading party of 4 tokens.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cprovver.h"
#include "cryptoki.h"
#include "ctextra.h"
#include "ctutil.h"
#include "ctvdef.h"
#include "chkret.h"
#include "genmacro.h"

#define N_SLOTS 4

static int vflag = 0;	/* 1 - verbose */
static int qflag = 0;	/* 1 - quick (default all inputs) */
static int fflag = 0;	/* 1 - force (suppress warning) */
static int xflag = 0;	/* 1 - extra (more memory required) */
char ErrorString[100]; /* used to decode / report Cryptoki errors */
CK_SLOT_ID G_SlotID = 0;	/* global slot ID */

/* some local prototypes */
int warning(CK_SLOT_ID slotID);
CK_RV InitPins(CK_SLOT_ID slotID, char * label, char * soPin, char * uPin);
CK_RV InitToken(CK_SLOT_ID slotID, char * label, char * soPin, char * uPin, CK_SIZE keyBits,
		CK_OBJECT_HANDLE * phPubEnc, CK_OBJECT_HANDLE * phPriEnc,
		CK_OBJECT_HANDLE * phPubSign, CK_OBJECT_HANDLE * phPriSign );
CK_RV InitCA(CK_SLOT_ID slotID, char * label, char * soPin, char * uPin, CK_SIZE keyBits,
		CK_OBJECT_HANDLE * phCert, CK_OBJECT_HANDLE * phPri );
CK_RV Certify(
	CK_SLOT_ID slotIDC,
	CK_SESSION_HANDLE hSesC, CK_OBJECT_HANDLE hPriC,
	CK_SLOT_ID slotID,
	CK_SESSION_HANDLE hSession,
	CK_OBJECT_HANDLE hCertReq,
	CK_OBJECT_HANDLE * hCert);
int
getNamePin( char * txt, char ** nBuf, char * dname, char **pBuf, char * dPin );
CK_RV demo(CK_SLOT_ID slotID, CK_SIZE keyBits);

/* attribute templates share these data storage areas */
static CK_SIZE mBits;
static CK_BYTE pubLabel[128];
static CK_BYTE priLabel[128];
static CK_BYTE certLabel[128];
static CK_BYTE subject[256];
static CK_BYTE issuer[256];
static CK_BYTE id[256];
static CK_BBOOL enc;
static CK_BBOOL dec;
static CK_BBOOL sign;
static CK_BBOOL ver;
static CK_BBOOL wrap;
static CK_BBOOL unwrap;
static CK_BBOOL isTok;
static CK_BBOOL isPri;
static CK_BBOOL extract;
static CK_BBOOL True = TRUE;
static CK_BBOOL False = FALSE;
static CK_BYTE Trusted;

#undef FN
#define FN "main:"

int
main(int argc, char ** argv)
{
	static CK_SIZE keyBits = 512;
	static CK_SLOT_ID slotID = 0;
	CK_RV rv;
	char *arg;
	char *progName;
	unsigned int errCount;

	printf( "Cryptoki Demo setup " CPROV_VERSION_STR "\n" );
	printf( CPROV_COPYRIGHT_STR "\n" );

	if ((progName = strrchr(*argv, '/')) == NULL) {
		progName = *argv;
	}
	else {
		progName++;
	}

	for ( argv++, argc--; argc && *argv; argv++, argc-- ) {
		arg = *argv;

		if ( arg[0] == '-' ) {
			switch (arg[1]) {
			case 'h':
				printf("usage: %s [-q] [-f] [-x] [-m<modulus size>] [-s<slot>]\n", progName);
				printf("    -f     No warning.\n" );
				printf("    -m     Specify modulus size.\n" );
				printf("    -q     No prompting for token labels and PINs. Force defaults.\n" );
				printf("    -s     First slot number to use.\n" );
				printf("    -v     Verbose mode.\n" );
				printf("    -x     Extra keys created.\n" );

				return 1;

			case 'f':
				fflag = 1;
				break;

			case 'm':
				keyBits = atoi(arg+2);
				break;

			case 'q':
				qflag = 1;
				break;

			case 's':
				slotID = atoi(arg+2);
				break;

			case 'v':
				vflag = 1;
				break;

			case 'x':
				xflag = 1;
				break;

			default:
				fprintf(stderr, "%s: Illegal argument: '%s'\n", progName, arg);
				fprintf(stderr, "Use '%s -h' for help\n", progName);
				return 1;
			}
		}
		else {
			fprintf(stderr, "%s: Illegal argument: '%s'\n", progName, arg);
			fprintf(stderr, "Use '%s -h' for help\n", progName);
			return 1;
		}
	}

	/* This must be the first CRYPTOKI call made */
	rv = C_Initialize(NULL);
	if ( rv ) {
		CT_ErrorString(rv,ErrorString,sizeof(ErrorString));
		fprintf(stderr, "%s: C_Initialize error %lx, %s\n", progName, rv, ErrorString);
		return 1;
	}

	/* Check Cryptoki version */
	rv = CheckCryptokiVersion();
	if ( rv ) {
		fprintf( stderr, "%s: Incompatible Cryptoki version\n", progName );
		return -1;
	}

	errCount = 0;

	if ( ! fflag ) {
		/* warn that we are about to init a slot */
		warning(slotID);
	}

	/* check that there are enough slots */
	{
		CK_COUNT count;
		rv = C_GetSlotList(FALSE, NULL, &count);
		if ( rv ) {
			CT_ErrorString(rv,ErrorString,sizeof(ErrorString));
			fprintf(stderr, "%s: C_GetSlotList error %lx, %s\n", progName, rv, ErrorString);
			return 1;
		}
		else if ( count < N_SLOTS ) {
			fprintf(stderr, "%s: This program requires %d slots. Only %ld were found\n",
				progName, N_SLOTS, count);
			return 1;
		}
	}

	/* set up the demo slots */
	if ( demo(slotID, keyBits) )
		errCount ++;

	/* Finalize the CRYPTOKI service */
	rv = C_Finalize(NULL);
	if ( rv ) {
		CT_ErrorString(rv,ErrorString,sizeof(ErrorString));
		fprintf(stderr, "%s: C_Finalize error %lx, %s\n", progName, rv, ErrorString);
		return 1;
	}

	return errCount;
}

/*
**	Set up 4 tokens, a customer (A), merchant (M), bank (B) and a CA (C).
**	Set up key profiles, do public key certification and
**	key exchanges.
*/

#undef FN
#define FN "demo:"

CK_RV demo(CK_SLOT_ID slotID, CK_SIZE keyBits)
{
	CK_RV rv;
	char * txt;
	char soPin[32];
	char * name;
	char * pin;

	/* handles for the 4 tokens A, B, M and C */
	CK_SESSION_HANDLE hSesC, hSesA, hSesB, hSesM;
	CK_SLOT_ID slotIDa;
	CK_OBJECT_HANDLE hPubEncA, hPubSignA;
	CK_OBJECT_HANDLE hCertReqEncA, hCertEncA, hCertReqSignA,
                     hCertSignA = CK_INVALID_HANDLE;
	CK_SLOT_ID slotIDb;
	CK_OBJECT_HANDLE hPubEncB, hPubSignB;
	CK_OBJECT_HANDLE hCertReqEncB, hCertEncB, hCertReqSignB,
                     hCertSignB = CK_INVALID_HANDLE;
	CK_SLOT_ID slotIDm;
	CK_OBJECT_HANDLE hPubEncM, hPubSignM;
	CK_OBJECT_HANDLE hCertReqEncM, hCertEncM, hCertReqSignM,
                     hCertSignM = CK_INVALID_HANDLE;
	CK_SLOT_ID slotIDc;
	CK_OBJECT_HANDLE hCertC, hPriC;

	/* set up slot IDs sequentially from selected slot base */
	slotIDa = slotID + 0;
	slotIDb = slotID + 1;
	slotIDm = slotID + 2;
	slotIDc = slotID + 3;

	if ( ! qflag ) {
		printf( "Enter fields as requested\n" );
		printf( "Just hit 'Enter' to use default value.\n" );
	}

	/* set up basic token profiles */
	if ( qflag ) {
		*soPin = '\0';	/* force default (below) */
	}
	else {
		printf( "Security officer pin [%s] : ", "9999" );
		fgets( soPin, 32, stdin );
		{
			char *c;
			if ((c = strchr(soPin, '\n')) != NULL)
				*c = 0;
		}
	}
	if ( *soPin == '\0' ) {
		strcpy(soPin, "9999");
		printf( "%-20s pin = %s\n", "Security officer", soPin );
	}

	/* first token is for the customer. Default : Alice (0000) */
	txt = "Customer";
	getNamePin(txt, &name, "Alice", &pin, "0000");
	printf( "%-20s name = %-32s, pin = %s\n", txt, name, pin );
	rv = InitToken(slotIDa, name, soPin, pin, keyBits,
		&hPubEncA, &hCertReqEncA, &hPubSignA, &hCertReqSignA);
	CHECK_RV_RET(FN "InitToken Customer", rv);

	/* Second token is for the Bank. Default : NAB (1111) */
	txt = "Bank";
	getNamePin(txt, &name, "NAB", &pin, "1111");
	printf( "%-20s name = %-32s, pin = %s\n", txt, name, pin );
	rv = InitToken(slotIDb, name, soPin, pin, keyBits,
		&hPubEncB, &hCertReqEncB, &hPubSignB, &hCertReqSignB);
	CHECK_RV_RET(FN "InitToken Bank", rv);

	/* Third token is for the Merchant. Default : Meyer (2222) */
	txt = "Merchant";
	getNamePin(txt, &name, "Meyer", &pin, "2222");
	printf( "%-20s name = %-32s, pin = %s\n", txt, name, pin );
	rv = InitToken(slotIDm, name, soPin, pin, keyBits,
		&hPubEncM, &hCertReqEncM, &hPubSignM, &hCertReqSignM);
	CHECK_RV_RET(FN "InitToken Merchant", rv);

	/* Fourth token is for the CA. Default : Safenet (3333) */
	txt = "Safenet";
	getNamePin(txt, &name, "Safenet", &pin, "3333");
	printf( "%-20s name = %-32s, pin = %s\n", txt, name, pin );
	/* certification authority is a special initialisation */
	rv = InitCA(slotIDc, name, soPin, pin, keyBits, &hCertC, &hPriC);
	CHECK_RV_RET(FN "InitToken CA", rv);

	/* open up a session with CA token */
	rv = C_OpenSession(slotIDc, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSesC);
	CHECK_RV_RET(FN "C_OpenSession", rv);
	rv = C_Login(hSesC, CKU_USER, (CK_CHAR_PTR)pin, (CK_SIZE) strlen((char*)pin));
	CHECK_RV_RET(FN "C_Login CA as User", rv);

	/* Setting CKA_WRAP=1 and CKA_TRUSTED=1 requires SO login */
	rv = C_OpenSession(slotIDa, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSesA);
	CHECK_RV_RET(FN "C_OpenSession A", rv);
	rv = C_Login(hSesA, CKU_SO, (CK_CHAR_PTR)soPin, (CK_SIZE) strlen((char*)soPin));
	CHECK_RV_RET(FN "C_Login(SO) A", rv);
	rv = C_OpenSession(slotIDb, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSesB);
	CHECK_RV_RET(FN "C_OpenSession B", rv);
	rv = C_Login(hSesB, CKU_SO, (CK_CHAR_PTR)soPin, (CK_SIZE) strlen((char*)soPin));
	CHECK_RV_RET(FN "C_Login(SO) B", rv);
	rv = C_OpenSession(slotIDm, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSesM);
	CHECK_RV_RET(FN "C_OpenSession M", rv);
	rv = C_Login(hSesM, CKU_SO, (CK_CHAR_PTR)soPin, (CK_SIZE) strlen((char*)soPin));
	CHECK_RV_RET(FN "C_Login(SO) M", rv);

	/* certify all user keys */
	rv = Certify(slotIDc, hSesC, hPriC, slotIDa, hSesA, hCertReqEncA, &hCertEncA);
	CHECK_RV_RET(FN "Certify A enc", rv);
	if ( xflag ) {
		rv = Certify(slotIDc, hSesC, hPriC, slotIDa, hSesA, hCertReqSignA, &hCertSignA);
		CHECK_RV_RET(FN "Certify A sign", rv);
	}
	rv = Certify(slotIDc, hSesC, hPriC, slotIDb, hSesB, hCertReqEncB, &hCertEncB);
	CHECK_RV_RET(FN "Certify B enc", rv);
	if ( xflag ) {
		rv = Certify(slotIDc, hSesC, hPriC, slotIDb, hSesB, hCertReqSignA, &hCertSignB);
		CHECK_RV_RET(FN "Certify B sign", rv);
	}
	rv = Certify(slotIDc, hSesC, hPriC, slotIDm, hSesM, hCertReqEncM, &hCertEncM);
	CHECK_RV_RET(FN "Certify M enc", rv);
	if ( xflag ) {
		rv = Certify(slotIDc, hSesC, hPriC, slotIDm, hSesM, hCertReqSignM, &hCertSignM);
		CHECK_RV_RET(FN "Certify M sign", rv);
	}

	/* swap certificates */
	rv = TransferObject( hSesB, hSesA, hCertEncA, NULL, NULL, 0 );
	CHECK_RV_RET(FN "TransferObject Enc A to B", rv);
	if ( xflag ) {
		rv = TransferObject( hSesB, hSesA, hCertSignA, NULL, NULL, 0 );
		CHECK_RV_RET(FN "TransferObject Sign A to B", rv);
	}
	rv = TransferObject( hSesM, hSesA, hCertEncA, NULL, NULL, 0 );
	CHECK_RV_RET(FN "TransferObject Enc A to M", rv);
	if ( xflag ) {
		rv = TransferObject( hSesM, hSesA, hCertSignA, NULL, NULL, 0 );
		CHECK_RV_RET(FN "TransferObject Sign A to M", rv);
	}
	rv = TransferObject( hSesA, hSesB, hCertEncB, NULL, NULL, 0 );
	CHECK_RV_RET(FN "TransferObject Enc B to A", rv);
	if ( xflag ) {
		rv = TransferObject( hSesA, hSesB, hCertSignB, NULL, NULL, 0 );
		CHECK_RV_RET(FN "TransferObject Sign B to A", rv);
	}
	rv = TransferObject( hSesM, hSesB, hCertEncB, NULL, NULL, 0 );
	CHECK_RV_RET(FN "TransferObject Enc B to M", rv);
	if ( xflag ) {
		rv = TransferObject( hSesM, hSesB, hCertSignB, NULL, NULL, 0 );
		CHECK_RV_RET(FN "TransferObject Sign B to M", rv);
	}
	rv = TransferObject( hSesA, hSesM, hCertEncM, NULL, NULL, 0 );
	CHECK_RV_RET(FN "TransferObject Enc M to A", rv);
	if ( xflag ) {
		rv = TransferObject( hSesA, hSesM, hCertSignM, NULL, NULL, 0 );
		CHECK_RV_RET(FN "TransferObject Sign M to A", rv);
	}
	rv = TransferObject( hSesB, hSesM, hCertEncM, NULL, NULL, 0 );
	CHECK_RV_RET(FN "TransferObject Enc M to B", rv);
	if ( xflag ) {
		rv = TransferObject( hSesB, hSesM, hCertSignM, NULL, NULL, 0 );
		CHECK_RV_RET(FN "TransferObject Sign M to B", rv);
	}

	/* put CA public key certificate on other tokens */
	rv = TransferObject( hSesA, hSesC, hCertC, NULL, NULL, 0 );
	CHECK_RV_RET(FN "LoadCAcert CA to A", rv);
	rv = TransferObject( hSesB, hSesC, hCertC, NULL, NULL, 0 );
	CHECK_RV_RET(FN "LoadCAcert CA to B", rv);
	rv = TransferObject( hSesM, hSesC, hCertC, NULL, NULL, 0 );
	CHECK_RV_RET(FN "LoadCAcert CA to M", rv);

	/* clean up */
	rv = C_CloseSession(hSesA);
	CHECK_RV_RET(FN "C_CloseSession A", rv);
	rv = C_CloseSession(hSesB);
	CHECK_RV_RET(FN "C_CloseSession B", rv);
	rv = C_CloseSession(hSesM);
	CHECK_RV_RET(FN "C_CloseSession M", rv);
	rv = C_CloseSession(hSesC);
	CHECK_RV_RET(FN "C_CloseSession C", rv);

	return 0;
}

/*
**	Get user name and PIN from standard input.
**	Insert defaults where values are not supplied.
*/
int
getNamePin( char * txt, char ** nBuf, char * dName, char **pBuf, char * dPin )
{
	static char buf[100];
	if ( qflag ) {
		/* just use defaults */
		* nBuf = dName;
		* pBuf = dPin;
		return 0;
	}
	printf( "%s name [%s], pin [%s]: ", txt, dName, dPin );
	fgets( buf, 100, stdin );
	{
		char *c;
		if ((c = strchr(buf, '\n')) != NULL)
			*c = 0;
	}	

	if ( * buf == '\0' ) {
		* nBuf = dName;
		* pBuf = dPin;
	}
	else {
		* nBuf = buf;
		* pBuf = strchr(buf, ',');
		if ( (* pBuf) == NULL ) {
			* pBuf = dPin;
		}
		else {
			* pBuf = '\0';
			(* pBuf) ++;
		}
	}
	return 0;
}

int warning(CK_SLOT_ID slotID)
{
	char buf[128];
	int ch;

	printf( "\nWARNING\n\n" );
	printf( "Running this program will erase the contents of the token\n" );
	printf( "in slot %ld to %ld. Do you wish to proceed ? Press Y to proceed : ",
		slotID, slotID + 3);
	fgets(buf, 128, stdin);
	ch = buf[0];
	printf( "\n" );
	if ( ch == 'Y' || ch == 'y' )
		return 1;

	/* user has chickened out */
	exit(0);
}

/*
**	Do basic token initialization.
**	Set up token label and SO and user PINs.
*/
#undef FN
#define FN "InitPins:"

CK_RV
InitPins(CK_SLOT_ID slotID, char * label, char * soPin, char * uPin)
{
	CK_SESSION_HANDLE hSession;
	CK_CHAR lab[CK_TOKEN_LABEL_SIZE + 1];
	CK_RV rv;

	/* init slot 0 */
	memset(lab, ' ', sizeof(lab));
	memcpy(lab, label, strlen((char*)label));
	lab[CK_TOKEN_LABEL_SIZE] = '\0';
	rv = C_InitToken(slotID, (unsigned char*) soPin, (CK_SIZE) strlen(soPin), lab);
	if ( rv ) {
		CT_ErrorString(rv,ErrorString,sizeof(ErrorString));
		fprintf(stderr, "C_InitToken error %lx, %s\n", rv, ErrorString);
	}

	/* open up a session */
	rv = C_OpenSession(slotID, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSession);
	CHECK_RV_RET(FN "C_OpenSession", rv);

	/* login as security officer */
	if ( vflag ) printf( FN "Login as SO\n" );
	rv = C_Login(hSession, CKU_SO, (CK_CHAR_PTR)soPin, (CK_SIZE) strlen((char*)soPin));
	CHECK_RV_RET(FN "C_Login SO", rv);

	/* initialise the user's PIN */
	if ( vflag ) printf( FN "initialising user PIN\n" );
	rv = C_InitPIN(hSession, (CK_CHAR_PTR)uPin, (CK_SIZE) strlen((char*)uPin));
	CHECK_RV_RET(FN "C_InitPIN", rv);

	rv = C_CloseSession(hSession);
	CHECK_RV_RET(FN "C_CloseSession", rv);

	return 0;
}

/* trim trailing spaces from a attribute */

int TrimStrAttr( CK_ATTRIBUTE_TYPE atType, CK_ATTRIBUTE * attr, int count)
{
	CK_ATTRIBUTE * at;
	at = FindAttribute(atType, attr, (CK_COUNT) count);
	if ( at == NULL ) return -1;
	if ( atType == CKA_LABEL )
		at->valueLen = strlen((char*)at->pValue);
	else
		at->valueLen = strlen((char*)at->pValue)+1;
	return 0;
}

/*
**	Token initialisation.
**	Basic setup plus some basic keying information.
*/
#undef FN
#define FN "InitToken:"

CK_RV
InitToken(CK_SLOT_ID slotID, char * label, char * soPin, char * uPin, CK_SIZE keyBits,
		CK_OBJECT_HANDLE * phPubEnc, CK_OBJECT_HANDLE * phCertReqEnc,
		CK_OBJECT_HANDLE * phPubSign, CK_OBJECT_HANDLE * phCertReqSign )
{
	CK_SESSION_HANDLE hSession;
	CK_RV rv;
	CK_ATTRIBUTE * at;

	/* Basic initialisation */
	rv = InitPins(slotID, label, soPin, uPin);
	CHECK_RV_RET(FN "InitPins", rv);

	/* open up a session */
	rv = C_OpenSession(slotID, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSession);
	CHECK_RV_RET(FN "C_OpenSession", rv);

	/* login so that we can create user objects as well as public ones */
	rv = C_Login(hSession, CKU_USER, (CK_CHAR_PTR)uPin, (CK_SIZE) strlen((char*)uPin));
	CHECK_RV_RET(FN "C_Login", rv);

	/* make some DES keys */
	{
		char * des1 = "Data Encrypting Key";
		char * des3 = "Key Encrypting Key";
		CK_MECHANISM mech = { 0, NULL, 0 };
		CK_OBJECT_HANDLE hKey;
		CK_ATTRIBUTE keyTemplate[] = {
			{CKA_TOKEN, &True, 1},
			{CKA_PRIVATE, &isPri, 1},
			{CKA_WRAP, &False, 1},
			{CKA_UNWRAP, &True, 1},
			{CKA_EXTRACTABLE, &True, 1},
			{CKA_SENSITIVE, &True, 1},
			{CKA_LABEL, NULL, 0}
		};

		at = FindAttribute( CKA_LABEL,
				keyTemplate, (CK_COUNT)NUMITEMS(keyTemplate) );
		if ( at == NULL )
			return CKR_GENERAL_ERROR;

		/* a public single length DES key */
		at->pValue = des1;
		at->valueLen = strlen(des1);
		isPri = FALSE;
		mech.mechanism = CKM_DES_KEY_GEN;
		/* generate the key */
		rv = C_GenerateKey(hSession, &mech, keyTemplate, NUMITEMS(keyTemplate), &hKey);
		CHECK_RV_RET(FN "C_GenerateKey", rv);

		/* a private triple length DES key */
		at->pValue = des3;
		at->valueLen = strlen(des3);
		isPri = TRUE;
		mech.mechanism = CKM_DES3_KEY_GEN;
		/* generate the key */
		rv = C_GenerateKey(hSession, &mech, keyTemplate, NUMITEMS(keyTemplate), &hKey);
		CHECK_RV_RET(FN "C_GenerateKey", rv);
	}

	/* make some RSA keys */
	{
		CK_OBJECT_HANDLE hPrivateKey;
		CK_MECHANISM mechanism = { 0, NULL, 0 };
		CK_ATTRIBUTE publicKeyTemplate[] = {
			{CKA_TOKEN, &isTok, 1},
			{CKA_PRIVATE, &False, 1},
			{CKA_LABEL, pubLabel, sizeof(pubLabel)},
			{CKA_SUBJECT_STR, subject, sizeof(subject)},
			{CKA_MODULUS_BITS, &mBits, sizeof(mBits)},
			{CKA_ENCRYPT, &enc, 1},
			{CKA_VERIFY, &ver, 1},
			{CKA_WRAP, &wrap, 1},
			{CKA_DERIVE, &True, 1},
			{CKA_EXTRACTABLE, &True, 1},
			{CKA_EXPORTABLE, &True, 1}
		};
		CK_ATTRIBUTE privateKeyTemplate[] = {
			{CKA_TOKEN, &isTok, 1},
			{CKA_LABEL, priLabel, sizeof(priLabel)},
			{CKA_PRIVATE, &isPri, 1},
			{CKA_SUBJECT_STR, subject, sizeof(subject)},
			{CKA_ID, id, sizeof(id)},
			{CKA_SENSITIVE, &True, 1},
			{CKA_DECRYPT, &dec, 1},
			{CKA_SIGN, &sign, 1},
			{CKA_UNWRAP, &unwrap, 1},
			{CKA_WRAP, &wrap, 1},
			{CKA_EXTRACTABLE, &False, 1},
			{CKA_EXPORTABLE, &False, 1}
		};
		CK_ATTRIBUTE certTemplate[] = {
			{CKA_TOKEN, &isTok, 1},
			{CKA_PRIVATE, &False, 1},
			{CKA_LABEL, certLabel, sizeof(certLabel)},
			{CKA_SUBJECT_STR, subject, sizeof(subject)},
			{CKA_EXTRACTABLE, &True, 1},
			{CKA_EXPORTABLE, &True, 1},
			{CKA_DERIVE, &True, 1}
		};

		if ( phPubEnc != NULL ) {
			/* encryption key pair */
			isTok = TRUE;
			if ( xflag ) {
				sprintf( (char*)pubLabel, "%s - Encrypt", label);
				sprintf( (char*)priLabel, "%s - Decrypt", label);
				sprintf( (char*)certLabel, "%s - Encrypt", label);
			}
			else {
				sprintf( (char*)pubLabel, "%s", label);
				sprintf( (char*)priLabel, "%s", label);
				sprintf( (char*)certLabel, "%s", label);
			}
			sprintf( (char*)subject, "C=au,CN=%s", label);
			/* set up key usage permissions */
			wrap = FALSE;
			unwrap = enc = dec = TRUE;
			ver = (CK_BBOOL)(xflag ? FALSE : TRUE);
			sign = TRUE;	/* allow this so we can self sign cert requests */
			mBits = keyBits;
			isPri = TRUE;

			TrimStrAttr( CKA_LABEL,
				publicKeyTemplate, NUMITEMS(publicKeyTemplate));
			TrimStrAttr( CKA_LABEL,
				privateKeyTemplate, NUMITEMS(privateKeyTemplate));
			TrimStrAttr( CKA_LABEL,
				certTemplate, NUMITEMS(certTemplate));
			TrimStrAttr( CKA_SUBJECT_STR,
				publicKeyTemplate, NUMITEMS(publicKeyTemplate));
			TrimStrAttr( CKA_SUBJECT_STR,
				privateKeyTemplate, NUMITEMS(privateKeyTemplate));
			TrimStrAttr( CKA_SUBJECT_STR,
				certTemplate, NUMITEMS(certTemplate));
			TrimStrAttr( CKA_ID,
				privateKeyTemplate, NUMITEMS(privateKeyTemplate));

			/* Generate the key pair */
			mechanism.mechanism = CKM_RSA_PKCS_KEY_PAIR_GEN;
			rv = C_GenerateKeyPair(hSession, &mechanism,
				publicKeyTemplate, NUMITEMS(publicKeyTemplate),
				privateKeyTemplate, NUMITEMS(privateKeyTemplate),
#ifdef V1COMPLIANT
				&hPrivateKey, phPubEnc);
#else
				phPubEnc, &hPrivateKey);
#endif
			CHECK_RV_RET(FN "C_GenerateKeyPair (enc)", rv);

			/* Generate a certificate request */
			mechanism.mechanism = CKM_SHA1_RSA_PKCS;
			rv = C_SignInit(hSession, &mechanism, hPrivateKey);
			CHECK_RV_RET(FN "C_SignInit", rv);

			mechanism.mechanism = CKM_ENCODE_PKCS_10;
			rv = C_DeriveKey(hSession, &mechanism,
				*phPubEnc,
				certTemplate, NUMITEMS(certTemplate),
				phCertReqEnc);
			if ( rv == CKR_MECHANISM_INVALID ) {
				/* fall back to public key if we can not generate a cert */
				*phCertReqEnc = *phPubEnc;
				printf( FN "Using pub enc key as cert req\n" );
			}
			else {
				CHECK_RV_RET(FN "C_DeriveKey (cert req)", rv);
			}
		}

		if ( phPubSign != NULL && xflag ) {
			/* signature key pair */
			isTok = TRUE;
			sprintf( (char*)pubLabel, "%s - Verify", label);
			sprintf( (char*)priLabel, "%s - Sign", label);
			sprintf( (char*)certLabel, "%s - Verify", label);
			/* set up key usage permissions */
			wrap = FALSE;
			unwrap = enc = dec = FALSE;
			sign = ver = TRUE;
			mBits = keyBits;

			TrimStrAttr( CKA_LABEL,
				publicKeyTemplate, NUMITEMS(publicKeyTemplate));
			TrimStrAttr( CKA_LABEL,
				privateKeyTemplate, NUMITEMS(privateKeyTemplate));
			TrimStrAttr( CKA_SUBJECT_STR,
				privateKeyTemplate, NUMITEMS(privateKeyTemplate));
			TrimStrAttr( CKA_ID,
				privateKeyTemplate, NUMITEMS(privateKeyTemplate));
			TrimStrAttr( CKA_LABEL,
				certTemplate, NUMITEMS(certTemplate));
			TrimStrAttr( CKA_SUBJECT_STR,
				certTemplate, NUMITEMS(certTemplate));

			/* Generate the key pair */
			mechanism.mechanism = CKM_RSA_PKCS_KEY_PAIR_GEN;
			rv = C_GenerateKeyPair(hSession, &mechanism,
				publicKeyTemplate, NUMITEMS(publicKeyTemplate),
				privateKeyTemplate, NUMITEMS(privateKeyTemplate),
#ifdef V1COMPLIANT
				&hPrivateKey, phPubSign);
#else
				phPubSign, &hPrivateKey);
#endif
			CHECK_RV_RET(FN "C_GenerateKeyPair (sign)", rv);

			/* Generate a certificate request */
			mechanism.mechanism = CKM_SHA1_RSA_PKCS;
			rv = C_SignInit(hSession, &mechanism, hPrivateKey);
			CHECK_RV_RET(FN "C_SignInit", rv);

			mechanism.mechanism = CKM_ENCODE_PKCS_10;
			rv = C_DeriveKey(hSession, &mechanism,
				*phPubSign,
				certTemplate, NUMITEMS(certTemplate),
				phCertReqSign);
			if ( rv == CKR_MECHANISM_INVALID ) {
				/* fall back to public key if we can not generate a cert */
				*phCertReqSign = *phPubSign;
				printf( FN "Using pub sign key as cert req\n" );
			}
			else {
				CHECK_RV_RET(FN "C_DeriveKey (cert req)", rv);
			}
		}
	}

	rv = C_CloseSession(hSession);
	CHECK_RV_RET(FN "C_CloseSession", rv);

	return 0;
}

/*
**	CA Token initialisation.
**	Basic setup plus some keying information for the CA.
*/
#undef FN
#define FN "InitCA:"

CK_RV
InitCA(CK_SLOT_ID slotID, char * label, char * soPin, char * uPin, CK_SIZE keyBits,
		CK_OBJECT_HANDLE * phCert, CK_OBJECT_HANDLE * phPri )
{
	CK_SESSION_HANDLE hSession;
	CK_OBJECT_HANDLE hPublicKey;
	CK_RV rv;
	static CK_COUNT count = 1;

	/* Basic initialisation */
	rv = InitPins(slotID, label, soPin, uPin);
	CHECK_RV_RET(FN "InitPins", rv);

	/* open up a session */
	rv = C_OpenSession(slotID, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSession);
	CHECK_RV_RET(FN "C_OpenSession", rv);

	/* make some RSA keys */
	{
        static char edate[] = {'2','0','2','0','1','2','3','1'};
		CK_MECHANISM mechanism = { 0, NULL, 0 };
		CK_ATTRIBUTE certTemplate[] = {
			{CKA_TOKEN, &isTok, 1},
			{CKA_PRIVATE, &False, 1},
			{CKA_LABEL, certLabel, sizeof(certLabel)},
			{CKA_SUBJECT_STR, subject, sizeof(subject)},
			{CKA_ISSUER_STR, issuer, sizeof(issuer)},
			{CKA_END_DATE, edate, sizeof(edate)},
			{CKA_EXTRACTABLE, &True, 1},
			{CKA_EXPORTABLE, &True, 1}
		};
		CK_ATTRIBUTE trustTemplate[] = {
			{CKA_TRUSTED, &Trusted, sizeof(Trusted)}
		};
		CK_ATTRIBUTE publicKeyTemplate[] = {
			{CKA_TOKEN, &isTok, 1},
			{CKA_PRIVATE, &False, 1},
			{CKA_LABEL, pubLabel, sizeof(pubLabel)},
			{CKA_SUBJECT_STR, subject, sizeof(subject)},
			{CKA_MODULUS_BITS, &mBits, sizeof(mBits)},
			{CKA_ENCRYPT, &enc, 1},
			{CKA_VERIFY, &ver, 1},
			{CKA_WRAP, &wrap, 1},
			{CKA_DERIVE, &True, 1},
			{CKA_EXTRACTABLE, &True, 1},
			{CKA_EXPORTABLE, &True, 1}
		};
		CK_ATTRIBUTE privateKeyTemplate[] = {
			{CKA_TOKEN, &isTok, 1},
			{CKA_LABEL, priLabel, sizeof(priLabel)},
			{CKA_PRIVATE, &isPri, 1},
			{CKA_SUBJECT_STR, subject, sizeof(subject)},
			{CKA_ID, id, sizeof(id)},
			{CKA_SENSITIVE, &True, 1},
			{CKA_DECRYPT, &dec, 1},
			{CKA_SIGN, &sign, 1},
			{CKA_UNWRAP, &unwrap, 1},
			{CKA_WRAP, &wrap, 1},
			{CKA_EXTRACTABLE, &False, 1},
			{CKA_EXPORTABLE, &False, 1},
			{CKA_USAGE_COUNT, &count, sizeof(count)}
		};

		/* signature key pair */
		isTok = TRUE;
		sprintf( (char*)pubLabel, "%s - Verify", label);
		sprintf( (char*)priLabel, "%s - Sign", label);
		sprintf( (char*)subject, "C=au,O=Safenet,CN=%s", label);
		sprintf( (char*)issuer, "C=au,O=Safenet,CN=%s", label);
		sprintf( (char*)certLabel, "%s", label);
		/* set up key usage permissions */
		wrap = FALSE;
		unwrap = enc = dec = FALSE;
		sign = ver = TRUE;
		mBits = keyBits;

		TrimStrAttr( CKA_LABEL,
			publicKeyTemplate, NUMITEMS(publicKeyTemplate));
		TrimStrAttr( CKA_LABEL,
			privateKeyTemplate, NUMITEMS(privateKeyTemplate));
		TrimStrAttr( CKA_SUBJECT_STR,
			privateKeyTemplate, NUMITEMS(privateKeyTemplate));
		TrimStrAttr( CKA_ID,
			privateKeyTemplate, NUMITEMS(privateKeyTemplate));
		TrimStrAttr( CKA_LABEL,
			certTemplate, NUMITEMS(certTemplate));
		TrimStrAttr( CKA_SUBJECT_STR,
			certTemplate, NUMITEMS(certTemplate));
		TrimStrAttr( CKA_ISSUER_STR,
			certTemplate, NUMITEMS(certTemplate));

		/* private key needs user login */
		rv = C_Login(hSession, CKU_USER, (CK_CHAR_PTR)uPin, (CK_SIZE) strlen((char*)uPin));
		CHECK_RV_RET(FN "C_Login USER", rv);

		/* Generate the key pair */
		mechanism.mechanism = CKM_RSA_PKCS_KEY_PAIR_GEN;
		rv = C_GenerateKeyPair(hSession, &mechanism,
			publicKeyTemplate, NUMITEMS(publicKeyTemplate),
			privateKeyTemplate, NUMITEMS(privateKeyTemplate),
#ifdef V1COMPLIANT
				phPri, &hPublicKey);
#else
				&hPublicKey, phPri);
#endif
		CHECK_RV_RET(FN "C_GenerateKeyPair (sign)", rv);

		mechanism.mechanism = CKM_SHA1_RSA_PKCS;
		rv = C_SignInit(hSession, &mechanism, *phPri);
		CHECK_RV_RET(FN "C_SignInit", rv);

		/* Certify the key pair */
		mechanism.mechanism = CKM_ENCODE_X_509;
		rv = C_DeriveKey(hSession, &mechanism,
			hPublicKey,
			certTemplate, NUMITEMS(certTemplate),
			phCert);
		if ( rv == CKR_MECHANISM_INVALID ) {
			/* fall back to public key if we can not generate a cert */
			*phCert = hPublicKey;
			if ( vflag ) printf( FN "Using Pub key as cert req\n" );
		}
		else {
			CHECK_RV_RET(FN "C_GenerateKeyPair (sign)", rv);
		}

		rv = C_Logout(hSession);
		CHECK_RV_RET(FN "C_Logout User", rv);

		/* Setting CKA_TRUSTED requires SO login */
		rv = C_Login(hSession, CKU_SO, (CK_CHAR_PTR)soPin, (CK_SIZE) strlen((char*)soPin));
		CHECK_RV_RET(FN "C_Login SO", rv);

		Trusted = 1;
		rv = C_SetAttributeValue(hSession, *phCert, trustTemplate, NUMITEMS(trustTemplate));
		CHECK_RV_RET(FN "C_SetAttributeValue", rv);

		rv = C_Logout(hSession);
		CHECK_RV_RET(FN "C_Logout SO", rv);
	}

	rv = C_CloseSession(hSession);
	CHECK_RV_RET(FN "C_CloseSession", rv);

	return 0;
}

/*
**	Certify a public by converting a certificate request into an
**	X509 certificate.
*/
#undef FN
#define FN "Certify:"

CK_RV
Certify(
	CK_SLOT_ID slotIDC,
	CK_SESSION_HANDLE hSesC, CK_OBJECT_HANDLE hPriC,
	CK_SLOT_ID slotID,
	CK_SESSION_HANDLE hSession,
	CK_OBJECT_HANDLE hCertReq,
	CK_OBJECT_HANDLE * phCert)
{
	CK_RV rv;
	CK_ATTRIBUTE * at;
	CK_OBJECT_HANDLE hLocCertReq = 0;
	CK_OBJECT_HANDLE hLocCert = 0;
	CK_MECHANISM mechanism = { 0, NULL, 0 };
    static char edate[] = {'2','0','2','0','1','2','3','1'};
	CK_ATTRIBUTE certTemplate[] = {
		{CKA_TOKEN, &isTok, 1},
		{CKA_PRIVATE, &isPri, 1},
		{CKA_LABEL, certLabel, sizeof(certLabel)},
		{CKA_SUBJECT_STR, subject, sizeof(subject)},
		{CKA_ISSUER_STR, issuer, sizeof(issuer)},
		{CKA_END_DATE, edate, sizeof(edate)},
		{CKA_EXTRACTABLE, &extract, 1},
		{CKA_EXPORTABLE, &extract, 1},
		{CKA_ENCRYPT, &True, 1},
	};

    ARG_USED(slotIDC);
    ARG_USED(slotID);

	/* move certificate request over to CA token */
	rv = TransferObject( hSesC, hSession, hCertReq, &hLocCertReq, NULL, 0 );
	CHECK_RV_RET(FN "TransferObject (init)", rv);

	/* prepare for digest and sign operation */
	mechanism.mechanism = CKM_SHA1_RSA_PKCS;
	rv = C_SignInit(hSesC, &mechanism, hPriC);
	CHECK_RV_RET(FN "C_SignInit", rv);

	/* extract label and subject info from the cert request */
	at = FindAttribute(CKA_SUBJECT_STR, certTemplate, NUMITEMS(certTemplate));
	rv = C_GetAttributeValue(hSession, hCertReq, at, 1);
	if ( rv && rv != CKR_ATTRIBUTE_TYPE_INVALID )
		CHECK_RV_RET(FN "C_GetAttributeValue (cert req)", rv);
	at = FindAttribute(CKA_LABEL, certTemplate, NUMITEMS(certTemplate));
	rv = C_GetAttributeValue(hSession, hCertReq, at, 1);
	if ( rv && rv != CKR_ATTRIBUTE_TYPE_INVALID )
		CHECK_RV_RET(FN "C_GetAttributeValue (cert req)", rv);

	/* get the issuer from the subject of the private key */
	at = FindAttribute(CKA_ISSUER_STR, certTemplate, NUMITEMS(certTemplate));
	at->type = CKA_SUBJECT_STR;
	at->valueLen = sizeof(issuer);
	rv = C_GetAttributeValue(hSesC, hPriC, at, 1);
	CHECK_RV_RET(FN "C_GetAttributeValue (CA pri)", rv);
	at->type = CKA_ISSUER_STR;

	isPri = FALSE;
	extract = TRUE;

	/* make the X.509 certificate from the cert request */
	mechanism.mechanism = CKM_ENCODE_X_509;
	rv = C_DeriveKey(hSesC, &mechanism,
		hLocCertReq,
		certTemplate, NUMITEMS(certTemplate),
		&hLocCert);
	if ( rv == CKR_MECHANISM_INVALID ) {
		/* fall back to public key if we can not generate a cert */
		*phCert = hCertReq;
		if ( vflag ) printf( FN "Using Pub key as cert\n" );
	}
	else {
		CHECK_RV_RET(FN "C_DeriveKey", rv);

		/* move certificate over to user's token */
		rv = TransferObject( hSession, hSesC, hLocCert, phCert, NULL, 0 );
		CHECK_RV_RET(FN "TransferObject (return)", rv);
	}
	/*
	**	Pub key get used for encrypting symmetric keys
	**	so enable CKA_WRAP.
	**
	**	Note this is done seperately to avoid CKA_WRAP complications.
	*/
	{
		CK_ATTRIBUTE wrapTemplate[] = {
			{CKA_WRAP, &True, 1},
			{CKA_EXPORT, &True, 1}
		};
		rv = C_SetAttributeValue(hSession, *phCert, wrapTemplate, NUMITEMS(wrapTemplate));
		CHECK_RV_RET(FN "C_SetAttributeValue", rv);
	}

	rv = C_DestroyObject(hSesC, hLocCertReq);
	CHECK_RV_RET(FN "C_DestroyObject", rv);
	rv = C_DestroyObject(hSesC, hLocCert);

	return 0;
}
