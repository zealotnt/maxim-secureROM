/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: ListTokens.c
 * $Date: 2014/06/05 15:33:29EDT $
 */
/**
 * @file
 *     Sample program to demonstrate how to read and display various token
 *     details.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cryptoki.h"
#include "ctutil.h"

/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Display information on slots and tokens.
 *
 * @param bVerbose
 *  Flag indicating whether or not to display detailed information.
 */
static CK_RV displayInfo(CK_BBOOL bVerbose);

/**
 * Display information on a given slot.
 *
 * @param slotId
 *  Id of the slot to display information on.
 */
static CK_RV displaySlotInfo(CK_SLOT_ID slotId);

/**
 * Display information on a token in a given slot
 *
 * @param slotId
 *  Id of the slot which contains the token to display information on.
 */
static CK_RV displayTokenInfo(CK_SLOT_ID slotId);

static void usage(void)
{
    printf("\nlisttokens [-?] [-v]");
    printf("\n");
    printf("\n-?            help display");
    printf("\n-s            display additional information");
    printf("\n");
    exit(0);
}


/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/

int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;
    CK_BBOOL bVerbose = FALSE;

    char *pArg = NULL;
    int i = 0;

    /*
     * Process command line arguments
     */
    for (i = 1; i < argc; ++i)
    {
        if (argv[i][0] == '-')
        {
            pArg = &argv[i][1];

            switch (toupper((int)*pArg))
            {
                case '?':
                    usage();
                break;

                case 'V':
                    bVerbose = TRUE;
                break;
            }
        }
    }

    rv = C_Initialize(NULL);
    if (rv != CKR_OK) return rv;

    rv = displayInfo(bVerbose);
    if (rv != CKR_OK) goto end;

end:

    C_Finalize(NULL);

    return rv;
}

/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/

static CK_RV displayInfo(CK_BBOOL bVerbose)
{
    CK_RV rv = CKR_OK;

    CK_INFO ckInfo;

    CK_SLOT_ID* pSlotList = NULL;
    CK_COUNT slotCount = 0;

    CK_NUMERIC i = 0;

    /*
     * Get some general information on the host library.
     */
    rv = C_GetInfo(&ckInfo);
    if (rv != CKR_OK) return rv;

    /*
     * Both the manufacturerID and the libraryDescription are NOT null terminated
     * and padded with spaces, so remove them with the rmTrailSpace function
     * written in the ctutil library.
     */
    rmTrailSpace((char*)ckInfo.manufacturerID, sizeof(ckInfo.manufacturerID));
    rmTrailSpace((char*)ckInfo.libraryDescription, sizeof(ckInfo.libraryDescription));

    /*
     * Print host library info.
     */
    printf("\nPKCS#11 interface version : V%d.%d", 
           ckInfo.cryptokiVersion.major,
           ckInfo.cryptokiVersion.minor);
    printf("\nManfacturer ID            : %s", ckInfo.manufacturerID);
    printf("\nLibrary Description       : %s", ckInfo.libraryDescription);
    printf("\nCryptoki library version  : V%d.%d", 
           ckInfo.libraryVersion.major,
           ckInfo.libraryVersion.minor);

    /* 
     * Get the number of slots we can accurately allocate enough memory 
     * to hold them
     */
    rv = C_GetSlotList(FALSE, NULL, &slotCount);
    if (rv != CKR_OK) 
    {
        fprintf(stderr, "Could not get number of slots (0x%lx - %s)\n",
                rv, 
                strError(rv));

        return rv;
    }    
    
    pSlotList = (CK_SLOT_ID*) malloc(slotCount * sizeof(CK_SLOT_ID));
    if (pSlotList == NULL) return CKR_HOST_MEMORY;

    /*
     * Get the slot list.
     */
    rv = C_GetSlotList(FALSE, pSlotList, &slotCount);
    if (rv != CKR_OK) 
    {
        fprintf(stderr, 
                "Could not get slot list (0x%lx - %s)\n",
                rv,
                strError(rv));

        goto end;
    }

    /*
     * Display information on each slot.
     */
    for (i = 0; i < slotCount; i++)
    {
        /* print info on the current slot */

        rv = displaySlotInfo(pSlotList[i]);
        if (rv != CKR_OK) goto end;        

        if (bVerbose)
        {
            rv = displayTokenInfo(pSlotList[i]);
            if (rv != CKR_OK) goto end;
        }
    }

end:
    if (pSlotList == NULL)
    {
        free(pSlotList);
        pSlotList = NULL;
    }

    return rv;
}

static CK_RV displaySlotInfo(CK_SLOT_ID slotId)
{
    CK_RV rv = CKR_OK;

    CK_SLOT_INFO sInfo;

    char flagsStr[512];

    /*
     * Get the information to display.
     */
    rv = C_GetSlotInfo(slotId, &sInfo);
    if (rv != CKR_OK) return rv;

    /*
     * Both the slotDescription and the manufacturerID are NOT null terminated
     * and padded with spaces, so remove them with the rmTrailSpace function
     * written in the ctutil library.
     */
    rmTrailSpace((char*)sInfo.slotDescription, sizeof(sInfo.slotDescription));
    rmTrailSpace((char*)sInfo.manufacturerID, sizeof(sInfo.manufacturerID));

    /*
     * Prepare the string representation of the flags.
     */
    memset(flagsStr, '\0', sizeof(flagsStr));
    if (sInfo.flags & CKF_TOKEN_PRESENT)     strcat(flagsStr, " TOKEN_PRESENT");
    if (sInfo.flags & CKF_REMOVABLE_DEVICE)  strcat(flagsStr, " REMOVEBLE_DEVICE");
    if (sInfo.flags & CKF_HW_SLOT)           strcat(flagsStr, " HW_SLOT");

    /*
     * Print the slot info.
     */
    printf("\n\nInformation for slot %ld", slotId);

    printf("\n    Slot Description  : %s", sInfo.slotDescription);
    printf("\n    Manufacturer ID   : %s", sInfo.manufacturerID);
    printf("\n    Flags             : 0x%1lx -%s", sInfo.flags, flagsStr);
    printf("\n    Hardware version  : V%d.%d", 
           sInfo.hardwareVersion.major,
           sInfo.hardwareVersion.minor);
    printf("\n    Firmware version  : V%d.%d", 
           sInfo.firmwareVersion.major,
           sInfo.firmwareVersion.minor);


    return rv;
}

static CK_RV displayTokenInfo(CK_SLOT_ID slotId)
{
    CK_RV rv = CKR_OK;

    CK_TOKEN_INFO tInfo;

    char flagsStr[512];
    char timeStr[256];

    /*
     * Get the information to display.
     */
    rv = C_GetTokenInfo(slotId, &tInfo);
    if (rv != CKR_OK) return rv;

    /*
     * Remove the trailing spaces and null terminated all relevant fields in
     * the tInfo structure. These are label, manufacturerID, model and 
     * serialNumber.
     */
    rmTrailSpace((char*)tInfo.label, sizeof(tInfo.label));
    rmTrailSpace((char*)tInfo.manufacturerID, sizeof(tInfo.manufacturerID));
    rmTrailSpace((char*)tInfo.model, sizeof(tInfo.model));
    rmTrailSpace((char*)tInfo.serialNumber, sizeof(tInfo.serialNumber));

    /*
     * Prepare the string representation of the flags.
     */
    memset(flagsStr, '\0', sizeof(flagsStr));
    if (tInfo.flags & CKF_RNG)                    strcat(flagsStr, " RNG");
    if (tInfo.flags & CKF_WRITE_PROTECTED)        strcat(flagsStr, " WRITE_PROTECTED");
    if (tInfo.flags & CKF_LOGIN_REQUIRED)         strcat(flagsStr, " LOGIN_REQ");
    if (tInfo.flags & CKF_USER_PIN_INITIALIZED)   strcat(flagsStr, " USER_PIN_INIT");
    if (tInfo.flags & CKF_RESTORE_KEY_NOT_NEEDED) strcat(flagsStr, " RESTORE_KEY_NOT_NEEDED");
    if (tInfo.flags & CKF_CLOCK_ON_TOKEN)         strcat(flagsStr, " CLOCK");
    if (tInfo.flags & CKF_PROTECTED_AUTHENTICATION_PATH) strcat(flagsStr, " PROTECTED_AUTH_PATH");
    if (tInfo.flags & CKF_DUAL_CRYPTO_OPERATIONS) strcat(flagsStr, " DUAL_CRYPTO");
    if (tInfo.flags & CKF_TOKEN_INITIALIZED)      strcat(flagsStr, " TOKEN_INIT");
    if (tInfo.flags & CKF_SECONDARY_AUTHENTICATION) strcat(flagsStr, " SECONDARY_AUTH");
    if (tInfo.flags & CKF_USER_PIN_COUNT_LOW)     strcat(flagsStr, " USER_PIN_COUNT_LOW");
    if (tInfo.flags & CKF_USER_PIN_FINAL_TRY)     strcat(flagsStr, " USER_PIN_FINAL_TRY");
    if (tInfo.flags & CKF_USER_PIN_LOCKED)        strcat(flagsStr, " USER_PIN_LOCKED");
    if (tInfo.flags & CKF_USER_PIN_TO_BE_CHANGED) strcat(flagsStr, " USER_PIN_TO_BE_CHANGED");
    if (tInfo.flags & CKF_SO_PIN_COUNT_LOW)       strcat(flagsStr, " SO_PIN_COUNT_LOW");
    if (tInfo.flags & CKF_SO_PIN_FINAL_TRY)       strcat(flagsStr, " SO_PIN_FINAL_TRY");
    if (tInfo.flags & CKF_SO_PIN_LOCKED)          strcat(flagsStr, " SO_PIN_LOCKED");
    if (tInfo.flags & CKF_SO_PIN_TO_BE_CHANGED)   strcat(flagsStr, " SO_PIN_TO_BE_CHANGED");

    /*
     * Prepare date and time. Use the DataConvertCmtToLocal function written
     * in the ctutil library.
     */
    memset(timeStr, '\0', sizeof(timeStr));
    DateConvertGmtToLocal(timeStr, (char*)tInfo.utcTime);

    /*
     * Print the token info.
     */
    printf("\nInformation for token in Slot %ld", slotId);

    printf("\n    Label                : %s", tInfo.label);
    printf("\n    Manufacturer ID      : %s", tInfo.manufacturerID);
    printf("\n    Model                : %s", tInfo.model);
    printf("\n    Serial Number        : %s", tInfo.serialNumber);
    printf("\n    Flags                : 0x%1lx -%s", tInfo.flags, flagsStr);
    printf("\n    Max Sessions         : %ld", tInfo.ulMaxSessionCount);
    printf("\n    Max RW Sessions      : %ld", tInfo.ulMaxRwSessionCount);
    printf("\n    Session count        : %ld", tInfo.ulSessionCount);
    printf("\n    RW Session count     : %ld", tInfo.ulRwSessionCount);
    printf("\n    Max PIN length       : %ld", tInfo.ulMaxPinLen);
    printf("\n    Min PIN length       : %ld", tInfo.ulMinPinLen);
    printf("\n    Total Public Memory  : %ld", tInfo.ulTotalPublicMemory);
    printf("\n    Free Public Memory   : %ld", tInfo.ulFreePublicMemory);
    printf("\n    Total Private Memory : %ld", tInfo.ulTotalPrivateMemory);
    printf("\n    Free Private Memory  : %ld", tInfo.ulFreePrivateMemory);
    printf("\n    Hardware version     : V%d.%d", 
           tInfo.hardwareVersion.major,
           tInfo.hardwareVersion.minor);
    printf("\n    Firmware version     : V%d.%d", 
           tInfo.firmwareVersion.major,
           tInfo.firmwareVersion.minor);
    printf("\n    Time                 : %s", timeStr);

    return rv;    
}

