/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2000-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: bvalue.h
 * $Date: 2014/06/05 15:33:05EDT $
 */
#ifndef	BVALUE_INCLUDED
#define BVALUE_INCLUDED

#include "field.h"

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

/* 'Value's are binary objects with a variable size.  The Value 'class' 
   stores the data, and the size of the data, in the object.  The functions
   below are used to manipulate and access the Value fields.

   The Value structure must be allocated using the NewValue, ValueFromBuf, 
   ValueFromString, or CopyValue methods, and free'ed using the FreeValue 
   method.  

   Note that 'Value' has no knowledge of the internal structure of the data
   it is storing, and therefore all copy's and free's are necessarily
   shallow.
*/

struct Value {
	/* Pointer to the data */
	unsigned char * value;

	/* The size of the data */
	size_t size;
};
typedef struct Value Value;

/* Return a pointer to a newly allocated Value, initialised to zero size */
Value * NewValue(void);

/* Return a pointer to a newly allocated value, initialised to size 'len', with
   a shallow copy of the data stored in the Value's 'value' field.
   Note that the data supplied in 'buf' is memcpy'ed to the 'value' field

   If 'buf' is NULL, then a Value is constructed with a 'value' field of the
   requested length, but with undefined data within it.
*/
Value * ValueFromBuf(const void * buf, size_t len);

/* Return a pointer to a newly allocated value, initialised to be the size 
   of the 'str', with a copy of the 'str' stored in the Value's 'value' field.
*/
Value * ValueFromString(const char * str);

/* Return a pointer to a newly allocated value, initialised to be a shallow 
   copy of the supplied 'vsrc'.
*/
Value * CopyValue(const Value * vsrc);

/* Free the 'v' object, and its 'value' field (if any) */
void FreeValue(Value * v);

/* Perform ASN1 (?) encoding of 'f' into the Value */
int EncodeValue(Field * f, int vtype, const Value * v);

/* Return the size of the supplied 'v' +10. ????? (ie v->size + 10) !!??? */
size_t SizeValue(const Value * v);

#ifdef __cplusplus
}
#endif

#endif	/*BVALUE_INCLUDED*/
