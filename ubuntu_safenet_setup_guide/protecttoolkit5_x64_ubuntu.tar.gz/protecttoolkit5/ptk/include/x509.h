/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1997-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: x509.h
 * $Date: 2014/06/05 15:33:43EDT $
 */
#ifndef X509_H
#define X509_H

#ifndef NOIDENT
#pragma ident "@(#)RELEASE VERSION $Name:  $ SafeNet Inc"
#endif
#include "asn1.h"
#include "ber.h"
#include "x962.h"

struct ArrayList {
	void	** algId;		/* array of pointers to things */
	unsigned int count;		/* number of items in the list */
	unsigned int type;		/* type of things in this list */
};
typedef struct ArrayList ArrayList;

typedef unsigned long Version;
typedef unsigned long SerialNumber;

struct OidAndValue {
	Oid  * oid;			/* see OBJID.C for tree */
	Value  * v;			/* value */
};
typedef struct OidAndValue OidAndValue;

struct AlgId {
	Oid	* alg;			/* algorithm */
	Value	* param;	/* parameters */
};
typedef struct AlgId AlgId;

#define X509_BIT_STRING			0
#define X509_RSA_PUBLIC_KEY		1
#define X509_RSA_PRIVATE_KEY	2
#define X509_DSA_PUBLIC_KEY		3
#define X509_DSA_PRIVATE_KEY	4
#define X509_DH_PUBLIC_KEY		5
#define X509_DH_PRIVATE_KEY		6
#define X509_EC_PUBLIC_KEY		7
#define X509_EC_PRIVATE_KEY		8

struct AlgIdAndValue {
	AlgId * algId;		/* algorithm */
	Value  * v;
};
typedef struct AlgIdAndValue AlgIdAndValue;

typedef unsigned char UTCTime;

struct Validity {
	Value	* notBefore;
	Value	* notAfter;
};
typedef struct Validity Validity;

struct Sequence {
	void	** items;
	unsigned int count;
};
typedef struct Sequence Sequence;

struct Set {
	void	** items;
	unsigned int count;
};
typedef struct Set Set;

/* AttributeTypeAndDistinguishedValue: Also known as AttributeValueAssertions
 * (from X.501 1988 edition).
 */
struct AttrTypeAndDistVal {
	Oid *oid;
	union {
		/* If OID is supported */
		Value *v;
		/* If OID is not supported */
		Value *enc;
	} o;
	/* Help the supported types remember their original tag. */
	TagInfo tagInfo;
};
typedef struct AttrTypeAndDistVal AttrTypeAndDistVal;

/* Relative Distinguished Name. The Set items point to AttrTypeAndDistVal
 * structures. */
typedef Set RDN;

struct DistName {
	/* sequence of names */
	RDN	** names;
	unsigned int count;
};
typedef struct DistName DistName;

typedef AlgIdAndValue Signature;

struct RSAPublicKey {
	Value * m;	/* modulas */
	Value * e;	/* exponent */
};
typedef struct RSAPublicKey RSAPublicKey;

struct RSAPrivateKey {
	Version version;
	Value * m;	/* modulas */
	Value * e;	/* public exponent */
	Value * d;	/* private exponent */
	Value * p;	/* prime 1 */
	Value * q;	/* prime 2 */
	Value * e1;	/* exponent 1 (d mod (p-1) */
	Value * e2;	/* exponent 2 (d mod (q-1) */
	Value * c;	/* CRT coefficient */
};
typedef struct RSAPrivateKey RSAPrivateKey;

struct DSAParameters {
	Value * p;	/* prime */
	Value * q;	/* subprime */
	Value * g;	/* base */
};
typedef struct DSAParameters DSAParameters;

struct DSAPublicKey {
	DSAParameters *params;
	Value *y;
};
typedef struct DSAPublicKey DSAPublicKey;

struct DSAPrivateKey {
	DSAParameters *params;
	Value *x;
};
typedef struct DSAPrivateKey DSAPrivateKey;

/* Diffie-Hellman keys */
struct DHParameters {
	Value * p;
	Value * g;
	Value * l;	/* optional */
};
typedef struct DHParameters DHParameters;

struct DHPublicKey {
	DHParameters *params;
	Value *y;
};
typedef struct DHPublicKey DHPublicKey;

struct DHPrivateKey {
	DHParameters *params;
	Value *x;
};
typedef struct DHPrivateKey DHPrivateKey;

typedef struct PublicKey {
	AlgId * algId;		/* algorithm */
	unsigned int vFormat;	/* defines the type of public Key eg RSA */
	union {
		Value  * unknown;
		RSAPublicKey * rsaPublicKey;
		DSAPublicKey * dsaPublicKey;
		DHPublicKey * dhPublicKey;
		ECPublicKey * ecPublicKey;
	} key;
} PublicKey;

typedef struct PrivateKey {
	AlgId * algId;		/* algorithm */
	unsigned int vFormat;	/* defines the type of public Key eg RSA */
	union {
		Value  * unknown;
		RSAPrivateKey * rsaPrivateKey;
		DSAPrivateKey * dsaPrivateKey;
		DHPrivateKey * dhPrivateKey;
		ECPrivateKey * ecPrivateKey;
	} key;
} PrivateKey;


struct Extension {
	Oid		*extnid;   /* attribute array */
	unsigned long		critical;
	void	*extnValue;	/* ANY - defined by extnid */
};
typedef struct Extension Extension;
/* AttrList (ref. X.501) */
struct AttrList {
	OidAndValue ** attr;   /* attribute array */
	unsigned int count;	/* number of attributes */
};
typedef struct AttrList AttrList;

/* ExtList */
struct ExtList {
	Extension **ext;   /* Extensions array */
	unsigned int count;	/* number of extensions */
};
typedef struct ExtList ExtList;

/* X.509 certificate */
struct X509 {
	Version version;
	Value	 * sno;	/* certificate serial number */
	AlgId	 * algId;
	DistName * issuer;
	Validity * validity;
	DistName * subject;
	PublicKey * subjectPublicKey;
	ExtList * extensions;	/* V3 and onward */
};
typedef struct X509 X509;

/* Signed Value */
struct SValue {
	Value * data;		/* binary data which has been signed */
	Signature * sig;
};
typedef struct SValue SValue;

/* Signed X.509 certificate */
struct SX509 {
	X509 * x509;
	Signature * sig;
};
typedef struct SX509 SX509;

/*** X509 Attribute Certificate */

struct ObjectDigestInfo{
     unsigned long digestedObjectType; /* should be 2 for SET ATTR ticket */
/*           publicKey            (0),
 *           publicKeyCert        (1),
 *           otherObjectTypes     (2)
 */
     Oid * otherObjectTypeID;   /* NULL unless digestedObjectType == 2 */
     AlgId * digestAlgorithm;
     Value * objectDigest;
};
typedef struct ObjectDigestInfo ObjectDigestInfo;

struct IssuerSerial {
     DistName * issuer;
     SerialNumber serial;
     Value * issuerUID;  /* OPTIONAL */
};
typedef struct IssuerSerial IssuerSerial;

/* this structure holds three pointers - only one should not be NULL 
 * NOTE - For CKM_SET_ATTRIBUTES tickets only issuerName is used.
 */
struct V2Form {
     DistName           * issuerName;       /* OPTIONAL - */
     IssuerSerial       * baseCertificateID;/* [0]   OPTIONAL - not used in X509AC */
     ObjectDigestInfo   * objectDigestInfo; /* [1] OPTIONAL - not used in X509AC */
};
typedef struct V2Form V2Form;

/* this structure holds two pointers - only one should not be NULL 
 * NOTE - For CKM_SET_ATTRIBUTES tickets only V1Form is used.
 */
struct AttCertIssuer{
     DistName * v1Form;
     V2Form * v2Form; /* [0] */
};
typedef struct AttCertIssuer AttCertIssuer;

struct AttCertValidityPeriod {
    Value * notBeforeTime;   /* GeneralizedTime YYYYMMDDHHMMSSZ */
    Value * notAfterTime;    /* GeneralizedTime YYYYMMDDHHMMSSZ */
};
typedef struct AttCertValidityPeriod AttCertValidityPeriod;

/* this structure hold three pointers - only one should not be NULL 
 * NOTE - For CKM_SET_ATTRIBUTES tickets only objectDigestInfo is used.
 */
struct Holder {
    IssuerSerial     * baseCertificateID; /* [0] OPTIONAL */
    DistName         * entityName;        /* [1] OPTIONAL */
    ObjectDigestInfo * objectDigestInfo;  /* [2] OPTIONAL */
};
typedef struct Holder Holder;

/* attribute for an attribute cert */
struct AttCertAttribute {
    Oid * type;
    Value * value;
};
typedef struct AttCertAttribute AttCertAttribute;

/* AttCertAttributes are a Set where the items point to a AttCertAttribute */
typedef Set AttCertAttributes;

/* X.509AC attribute certificate info */
struct X509AC {
	Version version;
	Holder	 * holder;
    AttCertIssuer * issuer;
	AlgId	 * signature;
	SerialNumber serialNumber;
    AttCertValidityPeriod * attrCertValidityPeriod;
	Set * attributes;  /* set of AttCertAttribute */
    Value * issuerUniqueID;  /* BIT STRING OPTIONAL - unused */
	/* extensions not used */
};
typedef struct X509AC X509AC;

/* Signed X.509CA attribute certificate */
struct SX509AC {
	X509AC * x509AC;
	Signature * sig;
};
typedef struct SX509AC SX509AC;

/******* PKCS 8 private key */
struct PKCS8PrivateKey {
	Version version;			/* must be 0 */
	PrivateKey * privateKey;	/* AlgId and value */
	AttrList * attributes;
};
typedef struct PKCS8PrivateKey PKCS8PrivateKey;

/* PKCS 10 certificate request */
struct PKCS10 {
	Version version;
	DistName  * subject;
	PublicKey * subjectPublicKey;
	AttrList * attributes;
};
typedef struct PKCS10 PKCS10;

/* Signed PKCS 10 certificate request */
struct SPKCS10 {
	PKCS10 * pkcs10;
	Signature * sig;
};
typedef struct SPKCS10 SPKCS10;

/* certificate revocation list (CRL) */

struct RevokedCert {
	Value *sno;	/* certificate serial number */
	Value * revocationDate;
	AttrList * extensions;
};
typedef struct RevokedCert RevokedCert;

struct RevCertList {
	RevokedCert ** rCert;
	unsigned int count;	/* number of revoked certificates in 'attr' */
	unsigned int flags;
};
typedef struct RevCertList RevCertList;

struct Crl {
	Version version;
	AlgId	 * algId;		/* signing algorithm */
	DistName * issuer;		/* The name of the CA */
	Value * thisUpdate;		/* time stamp for this CRL */
	Value * nextUpdate;		/* optional time for next update */
	RevCertList * rCertList;/* the list of revoked certificates */
	AttrList * extensions;	/* extensions */
};
typedef struct Crl Crl;

struct SCrl {
	Crl * crl;
	Signature * sig;
};
typedef struct SCrl SCrl;

/* PKCS # 7 */

struct AlgIdList {
	AlgId	** algId;			/* set of algorithms */
	unsigned int count;
	unsigned int flags;
};
typedef struct AlgIdList AlgIdList;

struct CertList {
	union {
		SX509	** p;		/* set of certificates */
		Value ** v;
	} cert;
	unsigned int count;
	unsigned int flags;
};
typedef struct CertList CertList;

struct CrlList {
	union {
		SCrl	** p;					/* set of CRLs */
		Value ** v;
	} crl;
	unsigned int count;
	unsigned int flags;
};
typedef struct CrlList CrlList;

struct ContentInfo {
	Oid * contentType;
	void * content;		/* defined by contentType */
};
typedef struct ContentInfo ContentInfo;

struct EncryptedContentInfo {
	Oid *contentType;
	AlgId *contentEncryptionAlgorithm;
	Value *encryptedContent;	
};
typedef struct EncryptedContentInfo EncryptedContentInfo;

struct EncryptedData {
	unsigned long version;
	EncryptedContentInfo *encryptedContentInfo;
};
typedef struct EncryptedData EncryptedData;

struct SContentInfo {
	ContentInfo * contentInfo;	/* only the content is signed, not the type */
	Signature * sig;
};
typedef struct SContentInfo SContentInfo;

struct IssuerAndSerialNumber {
	DistName * name;	/* distinguised name of certificate issuer */
	Value *sno;	/* certificate serial number */
};
typedef struct IssuerAndSerialNumber IssuerAndSerialNumber;

struct SignerInfo {
	Version version;	/* 0 - Obsolete (PEM) 1 - OK */
	IssuerAndSerialNumber * issuerAndSno;
	AttrList * authenticatedAttributes;
	AlgId * digestAlgorithm;	/* digests content and auth attrs */
	AlgId * digestEncryptionAlgorithm;
	Value * encryptedDigest;
	AttrList * unauthenticatedAttributes;
};
typedef struct SignerInfo SignerInfo;

struct SignerInfoList {
	SignerInfo	** signerInfo;					/* set of CRLs */
	unsigned int count;
	unsigned int flags;
};
typedef struct SignerInfoList SignerInfoList;

struct Pkcs7SignedData {
	Version version;
	AlgIdList	* digestAlgorithms;
	ContentInfo *contentInfo;
	CertList * certificates;
	CrlList	* crls;
	SignerInfoList * signerInfos;
};
typedef struct Pkcs7SignedData Pkcs7SignedData;

/*
struct Pkcs7 {
	Oid * contentType;
	Value * content;
};
typedef struct Pkcs7 Pkcs7;
*/
typedef ContentInfo Pkcs7;
typedef Value Pkcs7Data;

/* Function Prototypes for encoders and decoders */

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

int EncodePositiveInteger(Field * f, const Value * v);
int DecodePositiveInteger(Field * field, Value ** v);
int EncodePEM(Io *iobuf, char * str, unsigned char * value, unsigned int len);
int DecodePEM(Io *iobuf, char * str, unsigned char ** pvalue, unsigned int * plen);

struct Field;	/* forward declare */

RSAPrivateKey * NewRSAPrivateKey(void);
RSAPrivateKey * CopyRSAPrivateKey(const RSAPrivateKey * src);
int DecodeRSAPrivateKey(struct Field * f, RSAPrivateKey ** ppk );
int EncodeRSAPrivateKey(struct Field * f, const RSAPrivateKey * pk);
void FreeRSAPrivateKey(RSAPrivateKey * pk );
void DumpRSAPrivateKey(const RSAPrivateKey * pk, unsigned int depth);
unsigned int SizeRSAPrivateKey(const RSAPrivateKey * pk);

RSAPublicKey * NewRSAPublicKey(void);
RSAPublicKey * CopyRSAPublicKey(const RSAPublicKey * src);
int DecodeRSAPublicKey(struct Field * f, RSAPublicKey ** ppk );
int EncodeRSAPublicKey(struct Field * f, const RSAPublicKey * pk);
void FreeRSAPublicKey(RSAPublicKey * pk );
void DumpRSAPublicKey(const RSAPublicKey * pk, unsigned int depth);
unsigned int SizeRSAPublicKey(const RSAPublicKey * pk);
int EncodePEM_RSAPublicKey(Io *iobuf, RSAPublicKey * pk);
int DecodePEM_RSAPublicKey(Io *iobuf, RSAPublicKey ** ppk);

DSAParameters * NewDSAParameters(void);
DSAParameters * CopyDSAParameters(const DSAParameters * src);
int DecodeDSAParameters(struct Field * f, DSAParameters ** ppk );
int EncodeDSAParameters(struct Field * f, const DSAParameters * pk);
void FreeDSAParameters(DSAParameters * pk );
void DumpDSAParameters(const DSAParameters * pk, unsigned int depth);
unsigned int SizeDSAParameters(const DSAParameters * pk);
Value *DSAParametersToValue(const DSAParameters * pk);

DSAPrivateKey * NewDSAPrivateKey(void);
DSAPrivateKey * CopyDSAPrivateKey(const DSAPrivateKey * src);
int DecodeDSAPrivateKey(struct Field * f, DSAPrivateKey ** ppk );
int EncodeDSAPrivateKey(struct Field * f, const DSAPrivateKey * pk);
void FreeDSAPrivateKey(DSAPrivateKey * pk );
void DumpDSAPrivateKey(const DSAPrivateKey * pk, unsigned int depth);
unsigned int SizeDSAPrivateKey(const DSAPrivateKey * pk);

DSAPublicKey * NewDSAPublicKey(void);
DSAPublicKey * CopyDSAPublicKey(const DSAPublicKey * src);
int DecodeDSAPublicKey(struct Field * f, DSAPublicKey ** ppk );
int EncodeDSAPublicKey(struct Field * f, const DSAPublicKey * pk);
void FreeDSAPublicKey(DSAPublicKey * pk );
void DumpDSAPublicKey(const DSAPublicKey * pk, unsigned int depth);
unsigned int SizeDSAPublicKey(const DSAPublicKey * pk);

DHParameters * NewDHParameters(void);
DHParameters * CopyDHParameters(const DHParameters * src);
int DecodeDHParameters(struct Field * f, DHParameters ** ppk );
int EncodeDHParameters(struct Field * f, const DHParameters * pk);
void FreeDHParameters(DHParameters * pk );
void DumpDHParameters(const DHParameters * pk, unsigned int depth);
unsigned int SizeDHParameters(const DHParameters * pk);
Value *DHParametersToValue(const DHParameters * pk);

DHPrivateKey * NewDHPrivateKey(void);
DHPrivateKey * CopyDHPrivateKey(const DHPrivateKey * src);
int DecodeDHPrivateKey(struct Field * f, DHPrivateKey ** ppk );
int EncodeDHPrivateKey(struct Field * f, const DHPrivateKey * pk);
void FreeDHPrivateKey(DHPrivateKey * pk );
void DumpDHPrivateKey(const DHPrivateKey * pk, unsigned int depth);
unsigned int SizeDHPrivateKey(const DHPrivateKey * pk);

DHPublicKey * NewDHPublicKey(void);
DHPublicKey * CopyDHPublicKey(const DHPublicKey * src);
int DecodeDHPublicKey(struct Field * f, DHPublicKey ** ppk );
int EncodeDHPublicKey(struct Field * f, const DHPublicKey * pk);
void FreeDHPublicKey(DHPublicKey * pk );
void DumpDHPublicKey(const DHPublicKey * pk, unsigned int depth);
unsigned int SizeDHPublicKey(const DHPublicKey * pk);

SX509 * NewSignedX509(void);
SX509 * CopySignedX509(const SX509 * sx509src);
int DecodeSignedX509(struct Field * f, SX509 ** psx509);
int _DecodeSignedX509(struct Field * field, SX509 ** psx509);
int EncodeSignedX509(struct Field * f, const SX509 * sx509);
void FreeSignedX509(SX509 * sx509);
void DumpSignedX509(const SX509 * sx509, unsigned int depth );
unsigned int SizeSignedX509(const SX509 * sx509);

X509 * NewX509(void);
X509 * NewX509FromParts(
	const Value *sno,
	const DistName * issuer,
	const DistName * subject,
	const Validity * val,
	const PublicKey * pk,
	int signatureAlg
	);
X509 * CopyX509(const X509 * x509src);
int DecodeX509(struct Field * f, X509 ** px509);
int EncodeX509(struct Field * f, const X509 * x509);
void FreeX509(X509 * x509);
void DumpX509(const X509 * x509, unsigned int depth);
unsigned int SizeX509(const X509 * x509);

X509AC * NewX509AC(void);
int
New_SET_ATTRIBUTES_TicketInfo_FromParts(
            int objectDigestAlg,    /* OID_ALGID digest alg */
            unsigned char * objectDigest, 
            unsigned int objectDigestLen,
            char * issuerRDN,       /* may be NULL or 
                                     * DER of DistName or 
                                     * Common Name string or
                                     * RDN Seq string (CN=Fred+C=USA) */
            unsigned long issuerRDNLen,
            int signatureAlg,       /* OID_ALGID value of signature alg */
            unsigned long sno,      /* Attrib Cert serial number */
            char * notBefore,       /* YYYYMMDD string */
            char * notAfter,        /* YYYYMMDD string */

            unsigned long * limit,  /* NULL if no CKA_USAGE_LIMIT */
            char * start,           /* NULL if no CKA_START_DATE */
            char * end,             /* NULL if no CKA_END_DATE */
            char * cert,            /* NULL if no CKA_ADMIN_CERT */
            unsigned int certLen,

            X509AC ** ppTicket      /* new ticket returned here */
);

int DecodeX509AC(struct Field * f, X509AC ** px509AC);
int EncodeX509AC(struct Field * f, const X509AC * x509AC);
void FreeX509AC(X509AC * x509AC);
void DumpX509AC(const X509AC * x509AC, unsigned int depth );
unsigned int SizeX509AC(const X509AC * x509AC);
void FreeAttCertAttributes(AttCertAttributes *);
void FreeAttCertAttribute(AttCertAttribute * at);
void FreeAttCertValidityPeriod(AttCertValidityPeriod * acvp);
void FreeAttCertIssuer( AttCertIssuer * aci);
void FreeHolder(Holder * hld);
void FreeObjectDigestInfo(ObjectDigestInfo * odi);
IssuerSerial * NewIssuerSerial( void );
void FreeIssuerSerial( IssuerSerial * is);
ObjectDigestInfo * NewObjectDigestInfo( void );
void FreeObjectDigestInfo(ObjectDigestInfo * odi);
Holder * NewHolder( void );
void FreeHolder(Holder * hld);
V2Form * NewV2Form( void );
void FreeV2Form (V2Form * vf);
AttCertIssuer * NewAttCertIssuer( void );
AttCertValidityPeriod * NewAttCertValidityPeriod( void );
AttCertAttribute * NewAttCertAttribute( void );
AttCertAttributes * NewAttCertAttributes( void );

Validity * NewValidity(void);
Validity * CopyValidity(const Validity * src);
int EncodeValidity(Field * fld, const Validity * ptgt);
int DecodeValidity(Field * fld, Validity ** ptgt);
void FreeValidity(Validity * validity);
void DumpValidity( Validity * validity, unsigned int depth );
unsigned int SizeValidity(const Validity * validity);

DistName * NewDistName(void);
DistName * CopyDistName(const DistName * namesrc);
int EncodeDistName(Field * fld, const DistName * name);
int DecodeDistName(Field * fld, DistName ** pname);
void FreeDistName(DistName * name);
void DumpDistName(const DistName * name, unsigned int depth );
unsigned int SizeDistName(const DistName * name);

AttrTypeAndDistVal * NewAttrTypeAndDistVal(void);
AttrTypeAndDistVal * CopyAttrTypeAndDistVal(const AttrTypeAndDistVal * namesrc);
int EncodeAttrTypeAndDistVal(Field * fld, const AttrTypeAndDistVal * name);
int DecodeAttrTypeAndDistVal(Field * fld, AttrTypeAndDistVal ** pname);
void FreeAttrTypeAndDistVal(AttrTypeAndDistVal * name);
void DumpAttrTypeAndDistVal(const AttrTypeAndDistVal * name, unsigned int depth );
unsigned int SizeAttrTypeAndDistVal(const AttrTypeAndDistVal * name);
int DecodeDistNameBody(Field * f, DistName ** pname);


RDN * NewRDN(void);
RDN * CopyRDN(const RDN * namesrc);
int EncodeRDN(Field * fld, const RDN * name);
int DecodeRDN(Field * fld, RDN ** pname);
void FreeRDN(RDN * name);
void DumpRDN(const RDN * name, unsigned int depth );
unsigned int SizeRDN(const RDN * name);

AttrList * NewAttrList(void);
AttrList * CopyAttrList(const AttrList * attrsrc);
int EncodeAttrList(Field * fld, const AttrList * attr);
int DecodeAttrList(Field * fld, AttrList ** pattr);
void FreeAttrList(AttrList * attr);
void DumpAttrList(const AttrList * attributes, unsigned int depth );
unsigned int SizeAttrList(const AttrList * alg);

ExtList * NewExtList(void);
ExtList * CopyExtList(const ExtList * attrsrc);
int EncodeExtList(Field * fld, const ExtList * attr);
int DecodeExtList(Field * f, ExtList ** pattr);
void FreeExtList(ExtList * attr);
void DumpExtList(const ExtList * attributes, unsigned int depth );
unsigned int SizeExtList(const ExtList * alg);

AlgIdAndValue * NewAlgIdAndValue(void);
AlgIdAndValue * CopyAlgIdAndValue(const AlgIdAndValue * palg);
int EncodeAlgIdAndValue(Field * fld, const AlgIdAndValue * alg);
int DecodeAlgIdAndValue(Field * fld, AlgIdAndValue ** alg);
void FreeAlgIdAndValue(AlgIdAndValue * alg);
void DumpAlgIdAndValue(const AlgIdAndValue * alg);
unsigned int SizeAlgIdAndValue(const AlgIdAndValue * alg);

int EncodeOIDValue(Field * f, int tagType, int type, Value * v);

OidAndValue * NewOidAndValue(void);
OidAndValue * CopyOidAndValue(const OidAndValue * palg);
int EncodeOidAndValue(Field * f, int tagType, const OidAndValue * alg);
int DecodeOidAndValue(Field * f, OidAndValue ** palg);
void FreeOidAndValue(OidAndValue * alg);
void DumpOidAndValue(const OidAndValue * alg);
unsigned int SizeOidAndValue(const OidAndValue * alg);

int EncodeSignature(Field * f, const Signature * alg);
unsigned int SizeSignature(const Signature * alg);

PublicKey * NewPublicKey(void);
PublicKey * CopyPublicKey(const PublicKey * palg);
int EncodePublicKey(Field * f, const PublicKey * alg);
int DecodePublicKey(Field * f, PublicKey ** palg);
void FreePublicKey(PublicKey * alg);
void DumpPublicKey(const PublicKey * pk, unsigned int depth );
unsigned int SizePublicKey(const PublicKey * alg);
int EncodePEM_PublicKey(Io *iobuf, PublicKey * pk);
int DecodePEM_PublicKey(Io *iobuf, PublicKey ** ppk);

AlgId * NewAlgId(void);
AlgId * CopyAlgId(const AlgId * algsrc);
int EncodeAlgId(Field * f, const AlgId * alg);
int DecodeAlgId(Field * f, AlgId ** palg);
int DecodeAlgIdField(Field * f, AlgId ** palg);
void FreeAlgId(AlgId * alg);
void DumpAlgId(const AlgId * alg);
unsigned int SizeAlgId(const AlgId * alg);

SPKCS10 * NewSignedPKCS10(void);
SPKCS10 * CopySignedPKCS10(const SPKCS10 * spkcs10src);
int EncodeSignedPKCS10(Field * f, const SPKCS10 * spkcs10);
int DecodeSignedPKCS10(Field * field, SPKCS10 ** pspkcs10);
void FreeSignedPKCS10(SPKCS10 * spkcs10);
void DumpSignedPKCS10(const SPKCS10 * spkcs10, unsigned int depth);
unsigned int SizeSignedPKCS10(const SPKCS10 * pkcs10);

PKCS8PrivateKey * NewPKCS8PrivateKey(void);
PKCS8PrivateKey * CopyPKCS8PrivateKey(const PKCS8PrivateKey * pksrc);
int EncodePKCS8PrivateKey(Field * f, const PKCS8PrivateKey * pk);
int DecodePKCS8PrivateKey(Field * field, PKCS8PrivateKey ** ppk);
void FreePKCS8PrivateKey(PKCS8PrivateKey * pk);
void DumpPKCS8PrivateKey(const PKCS8PrivateKey * pk, unsigned int depth);
unsigned int SizePKCS8PrivateKey(const PKCS8PrivateKey * pk);

int EncodePrivateKey(Field * f, const PrivateKey * alg);

int PKCS8FromRSAPrivateKey( RSAPrivateKey * rpk, PKCS8PrivateKey ** ppk );
int PKCS8FromDSAPrivateKey( DSAPrivateKey * dpk, PKCS8PrivateKey ** ppk );
int PKCS8FromDHPrivateKey( DHPrivateKey * dpk, PKCS8PrivateKey ** ppk );
int PKCS8PrivateKeyFromECPrivateKey(ECPrivateKey *dpk, PKCS8PrivateKey **ppk);

PKCS10 * NewPKCS10(void);
PKCS10 * CopyPKCS10(const PKCS10 * pkcs10src);
int EncodePKCS10(Field * f, const PKCS10 * pkcs10);
int DecodePKCS10(Field * field, PKCS10 ** ppkcs10);
void FreePKCS10(PKCS10 * pkcs10);
void DumpPKCS10(const PKCS10 * pkcs10, unsigned int depth);
unsigned int SizePKCS10(const PKCS10 * pkcs10);

Pkcs7 * NewPkcs7(void);
Pkcs7 * CopyPkcs7(const Pkcs7 * src);
int EncodePkcs7( Field * f, const Pkcs7 * pk );
int DecodePkcs7( Field * f, Pkcs7 ** ppk );
void FreePkcs7( Pkcs7 * pk );

Pkcs7SignedData * NewPkcs7SignedData(void);
Pkcs7SignedData * CopyPkcs7SignedData(const Pkcs7SignedData * src);
int EncodePkcs7SignedData( Field * f, const Pkcs7SignedData * pk );
int DecodePkcs7SignedData( Field * f, Pkcs7SignedData ** ppk );
void FreePkcs7SignedData( Pkcs7SignedData * pk );

int EncodeContentInfo( Field * f, ContentInfo *ci );
int DecodeContentInfo( Field * f, ContentInfo **contentInf );
int DecodeRevCertList( Field * f, RevCertList **revCertList );

SValue * NewSignedValue(void);
SValue * CopySignedValue(const SValue * sValuesrc);
int
EncodeSignedValue(
    unsigned char ** pbuf,      /* OUT - pointer to malloced encoding */
    unsigned int * plen,        /* OUT - length of *pbuf */
    const unsigned char * data, /* IN - data to be signed */
    unsigned int dlen,          /* IN - length of data to be signed */
    int signatureAlg,           /* IN - signature algorithm OID_ALGID_.. */
    unsigned char * signature,  /* IN - signature vlue */
    int slen                    /* IN - length of signature */
    );
int DecodeSignedValue(Field * f, SValue ** psValue);
void FreeSignedValue(SValue * sValue);
void DumpSValue(const SValue * src, unsigned int depth);
unsigned int SizeSValue(const SValue * src);

Extension *NewExtension( void );
void FreeExtension(Extension *ext);
int DecodeExtension( Field *f, Extension **e );
Extension *CopyExtension(const Extension *ext);
unsigned int SizeExtension(const Extension* ext);


#ifdef __cplusplus
}
#endif

#endif /*X509_H*/
