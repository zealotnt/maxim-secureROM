/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2000-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: cprovver.h
 * $Date: 2015/12/10 13:58:42EST $
 */

#ifndef INC_CPROVVER_H
#define INC_CPROVVER_H

/* NOTE: The way the constants are defined determines how the string
   CPROV_VERSION_STR is formed. If we define major as 0x2 and minor as 0x001uL,
   the string becomes "0x2.00x001uL". 

   These values are the library version number
*/
#ifdef DEMO
	#define CPROV_VER_MAJOR 1
	#define CPROV_VER_MINOR 0
	#define CPROV_VER_PATCH 0
#else
	#define CPROV_VER_MAJOR 5
	#define CPROV_VER_MINOR 2
	#define CPROV_VER_PATCH 0
#endif

#define TOSTR1(X) #X
#define TOSTR(X) TOSTR1(X)

#define CPROV_VERSION_STR TOSTR(CPROV_VER_MAJOR) "." TOSTR(CPROV_VER_MINOR) "." TOSTR(CPROV_VER_PATCH)

#define CPROV_COPYRIGHT_STR "Copyright (c) Safenet, Inc. 2009-2016"
#define CPROV_COPYRIGHT_STR2 "Copyright (c) Safenet, Inc. %s-2016"

/* Global Variables used to hold FW version numbers */
extern unsigned int CprovVersion, CprovRelease;

extern unsigned char FW_VersionMajor;
extern unsigned char FW_VersionMinor;
extern unsigned char FW_VersionPatch;
extern char *FW_VersionPostfix;

#endif /* INC_CPROVVER_H */
