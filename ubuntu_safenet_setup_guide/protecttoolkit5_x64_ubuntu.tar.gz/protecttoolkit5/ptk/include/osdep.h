/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1994-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: osdep.h
 * $Date: 2014/06/05 15:33:20EDT $
 */
#ifndef OSDEP_INCLUDED
#define OSDEP_INCLUDED

/**
    @file
        Include file for Operating System Dependencies
*/


#ifdef __arm
#define EXPENTRY
#endif

#if defined(_NTWIN) || defined(WIN32) || defined(BITS32) || defined(unix) || defined(__arm)
/* some alias definitions */
	#undef far
	#define far
	#undef FAR
	#define FAR
	#undef _far
	#define _far
	#undef near
	#define near
#ifndef EXPENTRY
	#define EXPENTRY
#endif
#elif defined(SDK_ZTC)
	#undef far
	#define far _far
	#undef near
	#define near _near
	#undef pascal
	#define pascal _pascal
	#include <os2def.h>
/* some alias definitions */
#ifndef EXPENTRY
	#define EXPENTRY _pascal far _loadds
#endif
#elif defined(OS2)
	#include <os2.h>
#elif defined(BITS16)
	#include <os2def.h>
/* some alias definitions */
#else
/* unix */
	#define WINAPI _cdecl

#ifndef EXPENTRY
#define EXPENTRY _cdecl
#endif

#endif

#ifndef NULL
#define NULL ((void*)0)
#endif

#ifdef _MSC_VER

#if _MSC_VER > 600
#ifdef _INC_STRING
#pragma intrinsic(memset, memcpy, memcmp)
#pragma intrinsic(strcpy, strlen, strcmp, strcat)
#endif /* _INC_STRING */

#if defined(BITS16) && defined(_INC_STRING)
#pragma intrinsic(_fmemset, _fmemcpy, _fmemcmp)
#pragma intrinsic(_fstrcpy, _fstrlen, _fstrcmp, _fstrcat)
#endif

#endif /* _MSC_VER > 600 */

#ifdef BITS16

#define memchr   _fmemchr
#define memcmp   _fmemcmp
#define memcpy   _fmemcpy
#define memmove  _fmemmove
#define memset   _fmemset
#define strcat   _fstrcat
#define strchr   _fstrchr
#define strcmp   _fstrcmp
#define strerror _fstrerror
#define strcpy   _fstrcpy
#define strcspn  _fstrcspn
#define strlen   _fstrlen
#define strncat  _fstrncat
#define strncmp  _fstrncmp
#define strncpy  _fstrncpy
#define strpbrk  _fstrpbrk
#define strrchr  _fstrrchr
#define strspn   _fstrspn
#define strstr   _fstrstr
#define strtok   _fstrtok
#define strxfrm  _fstrxfrm

#endif /* BITS16 */

#endif /* _MSC_VER */

#ifndef BOOL
	#define BOOL int
#endif

#ifndef UCHAR
	#define UCHAR unsigned char
#endif

#ifndef PUCHAR
	#define PUCHAR UCHAR FAR *
#endif

#ifndef CHAR
	#define CHAR char
#endif

#ifndef PCHAR
	#define PCHAR CHAR FAR *
#endif

#ifndef PBOOL
	#define PBOOL int FAR *
#endif

#ifndef USHORT
	#define USHORT unsigned short
#endif

#ifndef SHORT
	#define SHORT short
#endif

#ifndef PUSHORT
	#define PUSHORT unsigned short FAR *
#endif

#ifndef ULONG
	#define ULONG unsigned long
#endif

#ifndef PULONG
	#define PULONG unsigned long FAR *
#endif

#ifndef PVOID
	#define PVOID void FAR *
#endif

#ifndef PSZ
	#define PSZ unsigned char far *
#endif

#endif
