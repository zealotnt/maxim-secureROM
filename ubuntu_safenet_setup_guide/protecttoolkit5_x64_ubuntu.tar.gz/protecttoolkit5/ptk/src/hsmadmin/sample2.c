/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: hsmadmin/sample2.c
 * $Date: 2014/06/05 15:33:13EDT $
 */
/**
 * @file
 *     Illustrates the use of HSMADM_AdjustTime function. Furthermore,
 *     it also describe how the RTC control access rule affects the adjust
 *     time function.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cryptoki.h"
#include "hsmadmin.h"
#include "genmacro.h"


#define HSM_INDEX     0

int main(int argc, char *argv[])
{    
	HSMADM_TimeVal_t  myDelta;
	CK_RV             rv        = CKR_OK;
	HSMADM_RV         hsm_rv    = HSMADM_OK;
    long              d_time    = 0;

    ARG_USED(argc);
    ARG_USED(argv);
    
	myDelta.tv_sec   = 2;  /** Adjust by 2 sec */
	myDelta.tv_usec  = 0; 
	
    /** Initialize Cryptoki library */
	rv = C_Initialize(NULL);
	if (rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_Initialize failed: 0x%lx ", rv);
		return -1;
    }
    
    /** 
     * Check how much RTC has been adjusted. The adjustments is governed  by
     * the rule specified by ctconf --rtc-access-ctrl-rule. If the adjustment
     * values violates the rule, an error code will be returned.
     *
     * For example:
     *
     *     ctconf --rtc-access-control-rule=1:: --rtc-access-control=1
     *
     * If delta.tv_sec is set to 2, error code 0x2 (HSMADM_ADJ_TIME_LIMIT) will
     * be returned.
     */
	hsm_rv = HSMADM_AdjustTime(HSM_INDEX,
                               &myDelta,
                               NULL);
	if(hsm_rv != HSMADM_OK) 
    {    
		fprintf(stderr, "\nHSMADM_AdjustTime failed: 0x%lx ", (unsigned long) hsm_rv);
		return -1;
    }	         


    /** Report how much has been adjusted */
    hsm_rv = HSMADM_GetRtcAdjustAmount(HSM_INDEX,
                                      &d_time);   
    if(hsm_rv != HSMADM_OK) 
    {    
		fprintf(stderr, "\nHSMADM_GetRtcAdjustAmount failed: 0x%lx ", (unsigned long) hsm_rv);
		return -1;
    }	         
                                      
    fprintf(stdout,"\nAmount changed %lu (ms) since first adjustment", d_time);

    /** Finalize cryptoki library */
	rv = C_Finalize(NULL);
    if (rv != CKR_OK) 
    {    
		fprintf(stderr, "\nC_Finalize failed: 0x%lx ", rv);
		return -1;
    }        

    return 0;
}

