/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: CreateSlots.c
 * $Date: 2014/06/05 15:32:53EDT $
 */
/**
 * @file
 *      Sample program to demonstrate the creation of user slots.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cryptoki.h"
#include "ctutil.h"
#include "ctvdef.h"


/**
 * Create the specified number of slots on the specified device.
 *
 * @param deviceNum
 *  Zero-based index of the device to create the new slots on.
 *
 * @param numSlots
 *  Number of new slots to create.
 *
 * @param pAdminPIN
 *  Current Admin Token USER PIN
 */
static CK_RV createUserSlots(unsigned int deviceNum,
                             unsigned int numSlots,
                             CK_CHAR* pAdminPIN);

/**
 * Return the admin slot id of the specified device.
 *
 * @param deviceNum
 *  The zero-based number of the device on which to find the Admin Slot.
 *
 * @param pAdminSlotId
 *  Location to store the Slot ID of the specified device's Admin Slot.
 */
static CK_RV findAdminSlotFromDeviceNum(int deviceNum,
                                       CK_SLOT_ID* pAdminSlotId);
                                       
/**
 * Create a CKO_SLOT object on the token associated with the specified 
 * session.
 *
 * @param hSession
 *  Handle to an open session.
 */
static CK_RV createSlot(CK_SESSION_HANDLE hSession);

static void usage(void)
{
    printf("\ncreateuserslots -? -c<NumSlots> -u<AdminPin> [-d<DeviceNum>]");
    printf("\n");
    printf("\n-?            help display");
    printf("\n-c            number slots to create");
    printf("\n-u            administrator PIN");
    printf("\n-d            device number to create slots on. Default = 0");
    printf("\n");
    exit(0);
}


int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    char* pArg = NULL;
    char* pValue = NULL;

    CK_CHAR* pAdminPIN = NULL;
    unsigned int deviceNum = 0;
    unsigned int numSlots = 0;

    int i = 0;

    /*
     * Process commandline arguments
     */
#define GET_VALUE                       \
            if (pArg[1] == '\0')        \
            {                           \
                if (++i < argc)         \
                {                       \
                    pValue = argv[i];   \
                }                       \
                else                    \
                {                       \
                    usage();            \
                }                       \
            }                           \
            else                        \
            {                           \
                pValue = pArg+1;        \
            }

    for(i = 1; i < argc; ++i)
    {
        if (argv[i][0] == '-')
        {
            pArg = &argv[i][1];

            switch (toupper((int)*pArg))
            {
                case '?':
                    usage();
                break;

                case 'D':
                    GET_VALUE;
                    deviceNum = atoi(pValue);
                break;

                case 'C':
                    GET_VALUE;
                    numSlots = atoi(pValue);
                break;

                case 'U':
                    GET_VALUE;
                    pAdminPIN = (CK_CHAR*)pValue;
                break;
            }
        }
        else
        {
            usage();
        }
    }

    /* 
     * User input sanity check.
     */
    if (numSlots == 0)
    {
        fprintf(stderr, "\nNumber of slots not specified.\n");
        usage();
    }

    if (pAdminPIN == NULL)
    {
        fprintf(stderr, "\nAdministrator PIN not specified.\n");
        usage();
    }

    rv = createUserSlots(deviceNum, numSlots, pAdminPIN);
    if (rv == CKR_OK)
    {
        printf("\nUser slots created.\n");
    }
    else
    {
        printf("\nSome user slots could not be created.\n");
    }

    return rv;
}

static CK_RV createUserSlots(unsigned int deviceNum,
                             unsigned int numSlots,
                             CK_CHAR* pAdminPIN)
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;   
    CK_COUNT adminPINLen = 0;
    CK_SLOT_ID adminSlotId;

    unsigned int i = 0;

    /* Start cryptoki */
    rv = C_Initialize(NULL);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not initialise cryptoki - 0x%lx (%s)",
                rv,
                strError(rv));

        return rv;
    }

    /* Determine the admin slot to work on. */
    rv = findAdminSlotFromDeviceNum(deviceNum, &adminSlotId);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not find admin slot on device %d - 0x%lx (%s)",
                deviceNum,
                rv,
                strError(rv));

        goto end;
    }

    /* 
     * Open a read/write user session on the admin token. Essentially, we
     * are logging in the Administrator of the specified device.
     */ 
    rv = C_OpenSession(adminSlotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not open a session on slot %ld - 0x%lx (%s)",
                adminSlotId,
                rv,
                strError(rv));

        goto end;
    }

    adminPINLen = (CK_COUNT)strlen((char*)pAdminPIN);

    rv = C_Login(hSession,
                 CKU_USER,
                 pAdminPIN,
                 adminPINLen);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not login user on Admin Slot %ld - 0x%lx (%s)",
                adminSlotId,
                rv,
                strError(rv));

        goto end;
    }

    /*
     * Create the specified number of user slots.
     */
    for (i = 0; i < numSlots; i++)
    {
        rv = createSlot(hSession);
        if (rv != CKR_OK)
        {
            fprintf(stderr,
                    "Could not create slot %d - 0x%lx (%s)",
                    i,
                    rv,
                    strError(rv));

            goto end;
        }
    }

end:
    /*
     * Clean Up...
     */

    if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

    C_Finalize(NULL);

    return rv;
}

static CK_RV findAdminSlotFromDeviceNum(int deviceNum,
                                        CK_SLOT_ID* pAdminSlotId)
{
    CK_RV rv = CKR_OK;

    CK_SLOT_ID* pSlots = NULL;
    
    CK_NUMERIC count = 0;
    CK_NUMERIC i = 0;

    int adminSlotCount = 0;

    /* 
     * Get the entire slot list.
     */
    rv = C_GetSlotList(FALSE, NULL, &count);
    pSlots = (CK_SLOT_ID_PTR)malloc(sizeof(CK_SLOT_ID) * count);
    if (pSlots == NULL) return CKR_HOST_MEMORY;

    rv = C_GetSlotList(FALSE, pSlots, &count);
    if (rv != CKR_OK) return rv;

    /* 
     * Loop until the correct admin slot is found.
     */
    for (i = 0; i < count; i++)
    {
        CK_SLOT_INFO slotInfo;

        /* Get information on the current slot */
		rv = C_GetSlotInfo(pSlots[i], &slotInfo);
		if (rv != CKR_OK) goto end;

        /* The admin slot cannot be a removable device. */
		if ((slotInfo.flags & CKF_REMOVABLE_DEVICE) == 0)
        {
			CK_TOKEN_INFO tokenInfo;

			rv = C_GetTokenInfo(pSlots[i], &tokenInfo);
			if (rv != CKR_OK) goto end;

			if (tokenInfo.flags & CKF_ADMIN_TOKEN)
            {
                ++adminSlotCount;

                if ((adminSlotCount-1) == deviceNum)
                {
				    *pAdminSlotId = pSlots[i];

				    free(pSlots);
                    pSlots = NULL;
				    
                    rv = CKR_OK;
                    break;
                }
			}
		}
    }

end:
    if (pSlots != NULL)
    {
        free(pSlots);
        pSlots = NULL;
    }

    return rv;
}

static CK_RV createSlot(CK_SESSION_HANDLE hSession)
{
    CK_RV rv = CKR_OK;
    CK_OBJECT_HANDLE hObject = CK_INVALID_HANDLE;

    /*
     * A slot is represented by a CKO_SLOT object on the admin token.
     */
    static CK_OBJECT_CLASS objClass = CKO_SLOT;
    static CK_BBOOL bTrue = TRUE;
    CK_ATTRIBUTE slotTpl[] =
    {
        {CKA_CLASS, &objClass,  sizeof(CK_OBJECT_CLASS)},
        {CKA_TOKEN, &bTrue,     sizeof(CK_BBOOL)},
    };
    CK_COUNT slotTplSize = sizeof(slotTpl)/sizeof(CK_ATTRIBUTE);

    rv = C_CreateObject(hSession, slotTpl, slotTplSize, &hObject);
    return rv;
}


