/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: GenKeyPair.c
 * $Date: 2014/06/05 15:33:23EDT $
 */
/**
 * @file
 *     Sample program to demonstrate the generation of an asymmetric key pair.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cryptoki.h"
#include "ctvdef.h"
#include "ctutil.h"
#include "genmacro.h"

/** 
 * This macro is used to check the return value of a function and print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr,                                     \
                "%s - 0x%lx (%s)\n",                         \
                 string,                                    \
                 rv,                                        \
                 strError(rv));                             \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Generate a 1024 bit RSA key pair.
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param phPublicKey
 *  Location to store the handle of the new public key.
 * 
 * @param phPrivateKey
 *  Location to store the handle of the new private key.
 */
static CK_RV generateKeyPair(CK_SESSION_HANDLE hSession,
                             CK_OBJECT_HANDLE* phPublicKey,
                             CK_OBJECT_HANDLE* phPrivateKey);

/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;

    CK_OBJECT_HANDLE hPublicKey = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hPrivateKey = CK_INVALID_HANDLE;

    CK_SLOT_ID slotId = 0;  /* we'll just use slot 0 for this demo */

    ARG_USED(argc);
    ARG_USED(argv);

    /*
     * Start cryptoki.
     */
    rv = C_Initialize(NULL);
    CHECK_CK_RV_GOTO(rv, "Could not initialize cryptoki", end);

    rv = C_OpenSession(slotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    CHECK_CK_RV_GOTO(rv, "Could not open session", end);

    rv = generateKeyPair(hSession, &hPublicKey, &hPrivateKey);
    if (rv == CKR_OK) 
    {
        printf("\nKey pair was successfully generated\n");
    }
    else
    {
        printf("\nKey pair was successfully generated\n");
        goto end;
    }

    rv = C_CloseSession(hSession);
    CHECK_CK_RV_GOTO(rv, "Could not close session", end);


    rv = C_Finalize(NULL);
    CHECK_CK_RV_GOTO(rv, "Could not finalise cryptoki", end);

    return rv;

end:
    /*
     * Error handling code... clean up.
     */
    if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

    C_Finalize(NULL);

    return rv;
}


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
void sum_print(char *string, CK_BYTE *array, unsigned int len)
{
    unsigned int i;
    unsigned int sum = 0;
    for (i = 0; i < len; i++)
    {
        sum += array[i];
    }
    printf("%s=%d\r\n", string, sum);
}

static CK_RV generateKeyPair(CK_SESSION_HANDLE hSession,
                             CK_OBJECT_HANDLE* phPublicKey,
                             CK_OBJECT_HANDLE* phPrivateKey)
{
    CK_RV rv = CKR_OK;

    CK_OBJECT_HANDLE hPublicKey = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hPrivateKey = CK_INVALID_HANDLE;

    CK_MECHANISM mech = {CKM_RSA_PKCS_KEY_PAIR_GEN, NULL, 0};

    /*
     * Attribute values
     */
    static CK_BBOOL bTrue = TRUE;
    static CK_BBOOL bFalse = FALSE;
    static CK_BYTE subject[512] = {0};
    static CK_BYTE modulus[512] = {0};
    static CK_BYTE exponent[4096] = {1, 2, 3, 4, 5, 6, 7 , 8, 9 ,10};
    static CK_CHAR pubLabel[] = "pubkey_example";
    static CK_CHAR priLabel[] = "prikey_example";
    static CK_ULONG keySize = 1024;

    CK_OBJECT_CLASS class = CKO_PUBLIC_KEY;
    /*
     * Attribute template for the public key.
     */
    CK_ATTRIBUTE publicKeyTpl[] = 
    {
        {CKA_CLASS, &class, sizeof(class)},
        {CKA_TOKEN,             &bTrue,    sizeof(CK_BBOOL)},
        {CKA_PRIVATE,           &bFalse,   sizeof(CK_BBOOL)},
        {CKA_LABEL,             NULL,      0},
        {CKA_ENCRYPT,           &bTrue,    sizeof(CK_BBOOL)},
        {CKA_VERIFY,            &bTrue,    sizeof(CK_BBOOL)},
        {CKA_WRAP,              &bTrue,    sizeof(CK_BBOOL)},
        {CKA_MODIFIABLE,        &bTrue,    sizeof(CK_BBOOL)},
        {CKA_DERIVE,            &bTrue,    sizeof(CK_BBOOL)},
        {CKA_PRIME_BITS,        &keySize,  sizeof(CK_ULONG)},
        // {CKA_SUBJECT, subject, sizeof(subject)},
        // {CKA_MODULUS, modulus, sizeof(modulus)},
        {CKA_PUBLIC_EXPONENT, NULL, 0},
    };
    CK_COUNT publicKeyTplSize = sizeof(publicKeyTpl)/sizeof(CK_ATTRIBUTE);

    /*
     * Attribute template for the private key.
     */
    CK_ATTRIBUTE privateKeyTpl[] = 
    {
        {CKA_TOKEN,             &bTrue,    sizeof(CK_BBOOL)},
        {CKA_PRIVATE,           &bFalse,   sizeof(CK_BBOOL)},
        {CKA_LABEL,             NULL,      0},
        {CKA_SENSITIVE,         &bTrue,    sizeof(CK_BBOOL)},
        {CKA_DECRYPT,           &bTrue,    sizeof(CK_BBOOL)},
        {CKA_SIGN,              &bTrue,    sizeof(CK_BBOOL)},
        {CKA_IMPORT,            &bFalse,   sizeof(CK_BBOOL)},
        {CKA_UNWRAP,            &bTrue,    sizeof(CK_BBOOL)},
        {CKA_MODIFIABLE,        &bTrue,    sizeof(CK_BBOOL)},
        {CKA_EXTRACTABLE,       &bTrue,    sizeof(CK_BBOOL)},
        {CKA_DERIVE,            &bTrue,    sizeof(CK_BBOOL)},
        {CKA_EXPORTABLE,        &bTrue,    sizeof(CK_BBOOL)},
        {CKA_SIGN_LOCAL_CERT,   &bTrue,    sizeof(CK_BBOOL)},
    };
    CK_COUNT privateKeyTplSize = sizeof(privateKeyTpl)/sizeof(CK_ATTRIBUTE);

    CK_ATTRIBUTE* pAttr = NULL;

    pAttr = FindAttribute(CKA_PUBLIC_EXPONENT, publicKeyTpl, publicKeyTplSize);
    pAttr->pValue = exponent;
    pAttr->ulValueLen = (CK_ULONG)sizeof(exponent);

    /* Fill in the public key label */
    pAttr = FindAttribute(CKA_LABEL, publicKeyTpl, publicKeyTplSize);
    pAttr->pValue = pubLabel;
    pAttr->ulValueLen = (CK_ULONG)strlen((char*)pubLabel);

    /* Fill in the private key label */
    pAttr = FindAttribute(CKA_LABEL, privateKeyTpl, privateKeyTplSize);
    pAttr->pValue = priLabel;
    pAttr->ulValueLen = (CK_ULONG)strlen((char*)priLabel);

    /*
     * Generate the key pair.
     */
    // sum_print("subject_bf: ", subject, sizeof(subject));
    // sum_print("modulus_bf: ", modulus, sizeof(modulus));
    // sum_print("exponent_bf: ", exponent, sizeof(exponent));
    printf("cryptoki entry\r\n");
    rv = C_GenerateKeyPair(hSession,
                           &mech,
                           publicKeyTpl,
                           publicKeyTplSize,
                           privateKeyTpl,
                           privateKeyTplSize,
                           &hPublicKey,
                           &hPrivateKey);
    printf("cryptoki end\r\n");
    // sum_print("subject_af: ", subject, sizeof(subject));
    // sum_print("modulus_af: ", modulus, sizeof(modulus));
    // sum_print("exponent_af: ", exponent, sizeof(exponent));

    if (rv == CKR_OK)
    {
        *phPublicKey = hPublicKey;
        *phPrivateKey = hPrivateKey;
    }
    else
    {
        fprintf(stderr,
                "Could not generate key pair - 0x%lx (%s)",
                rv,
                strError(rv));
    }

    return rv;
}

