/******************************************************************************
 *
 *  Copyright (C) 2009 Safenet.
 *  All Rights Reserved 
 *
 *  Use of this file for any purpose whatsoever is prohibited without the
 *  prior written consent of Safenet
 *
 *  $Source: prod/cprov/util/limits/limits.c $
 *  $Revision: 1.5.2.5 $
 *  $Date: 2012/01/18 11:12:18EST $
 *  $Author: Young, Shawn (syoung) $
 *
 *//**
 *  
 *  @file   limits.c
 *  @brief  Main source file for the ctlimit application, which provides users
 *          with functionality to manage key usage limits.
 *
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <assert.h>
#include <signal.h>

#include "certlib.h"
#include "getOption.h"
#include "cryptoki.h"
#include "ctextra.h"
#include "ctfext.h"
#include "ctutil.h"
#include "ctvdef.h"
#include "genmacro.h"
#include "input.h"
#include "ber.h"
#include "b64.h"
#include "x509.h"
#include "dnstr.h"
#include "logerr.h"
#include "hex2bin.h"
#include "cprovver.h"

#include "cert.h"

#ifndef unix
#define stricmp _stricmp
#else
#define stricmp strcasecmp
#endif

/* Local Structures */

/* list of objects */
struct ObjList
{
    CK_SIZE            num;     /* length of obj array */
    CK_OBJECT_HANDLE * objs;    /* array of objs */
};
typedef struct ObjList ObjList;

/* Construct an ObjList */
ObjList * NewObjList(void)
{
    ObjList * o = (ObjList *)malloc(sizeof(ObjList));
    if (o)
    {
        o->num = 0;
        o->objs = (CK_OBJECT_HANDLE *)malloc(sizeof(CK_OBJECT_HANDLE *));
        if ( o->objs == NULL )
        {
            free(o);
            return NULL;
        }
    }
    return o;
}

/* Free an ObjList */
void FreeObjList(ObjList *o)
{
    if (o)
    {
        if ( o->objs ) free(o->objs);
        free(o);
    }
}

/* add an Obj to an ObjList 
 * Return: zero if memory failure
*/
int ObjListAdd(ObjList *o, CK_OBJECT_HANDLE obj)
{
    o->num++;
    o->objs = (CK_OBJECT_HANDLE *)realloc(o->objs, sizeof(CK_OBJECT_HANDLE *)*o->num);
    if ( o->objs == NULL ) return 0;
    o->objs[o->num-1] = obj;

    return 1;
}

/* Global variables */
char *ProgName;
static char ErrorString[100];	/* used to store error strings for printing */

/*
** Flags to indicate command being run 
*/
static CK_BBOOL cmd_ct = 0; /* Create ticket from offline specification */
static CK_BBOOL cmd_pt = 0; /* Present ticket when online */
static CK_BBOOL cmd_up = 0; /* Apply limit attributes to online token */
static CK_BBOOL cmd_vk = 0; /* View online key attributes */

/*
** Parameters both raw and cooked
*/

/* type of user to who is signing ticket */
char * str_usertype;
CK_USER_TYPE usertype = CKU_USER;

/* pin of user signing ticket */
char *pin;

/* specifier of signing key - TokenLabel/KeyLabel */
char * keyspec;

/* algorithm used to sign the ticket */
char * str_signalg;
CK_MECHANISM_TYPE signalg;

/* optional message */
char * message;

/* target token label */
char * token_label;

/* target Token seral number */
char * token_sno;

/* ticket file name */
char * filename;

/* target object label */
char * target_label;

/* target object CKA_ID */
char * str_target_key_id;

unsigned char target_key_id[256];
int target_key_id_len;

/* optional search attribute array */
char * target_attr;

/* new target usage limit */
char * str_usage_limit;
CK_ULONG usage_limit;

/* new target usage count */
char * str_usage_count;
CK_ULONG usage_count;

/* new target start date */
char * start_date;

/* new target end date */
char * end_date;

/* optional new attribute array */
char * new_attr;

/* Public Key certificate file name */
char * cert_file_name;

/* Amoured Attribute certificate file name */
char * filename;

/* Target object type */
CK_OBJECT_CLASS objtype = CKO_PRIVATE_KEY;

char * str_objtype;

/* certificate duration */
char * str_duration;

char cert_start_date[] = "YYYYMMDD";
char cert_end_date[]   = "YYYYMMDD";


/* called by getOption: */
void printArgsAndShortDescription(char *progName) {
    ARG_USED(progName);

    printf("ct | pt| up | vk\n\n");
}

/* called by getOption: */
void printExtraHelp(char *progName)
{
    ARG_USED(progName);

    printf("\n");
	printf("ctlimits ct\t[-U<usertype>] -k<keyspec> [-m<message>]\n");
	printf("\t\t-S<serial_no> -t<tok_label> -l<target_label> -i<key_id>\n");
	printf("\t\t[-d<days>] [-L<limit>] [-s<date>] [-e<date>]\n");
	printf("\t\t[-c<cert_file_name>] filename\n");
	printf("\n");
	printf("ctlimits pt	[-U<usertype>] [-O<objtype>] -k<key_spec>\n");
	printf("\t\t[-i<key_id>] filename\n");
	printf("\n");
	printf("ctlimits up	[-U<usertype>] [-O<objtype>]\n");
	printf("\t\t-k<key_spec> [-i<key_id>] filename\n");
	printf("\t\t[-L<limit>] [-C<count>] [-s<time>] [-e<time>]\n");
	printf("\t\t[-c<cert_file_name>]\n");
	printf("\n");
	printf("ctlimits vk	[-U<usertype>] [-O<objtype>] -k<key_spec> [-i<key_id>]\n");
    printf("\n");
}


#if 0    //////////// not used ////////////////

/**
 * @brief       Displays a list of valid elliptic curve name to stderr.
 *
 * @pre         Wrong input from user.
 * @post        List of valid hash names is displayed on stderr.
 */
static void printValidHashNames()
{
    fprintf(stdout,
            "Allowed hash names (-S) are sha1, sha224, sha256, sha384, sha512.\n");
}

static char *pszSignHashMech = NULL;

/**
 * @brief        Map a string to a SHA signature hashing algorithm.
 *
 * @pre
 * @post
 */
static CERT_SignHash_t GetSignHashType()
{
    if (pszSignHashMech == NULL)
    {
        return CERT_SHA_1;
    }
    else
    {
        /* use the gobal pszSignHash */
        if (strcasecmp(pszSignHashMech, "sha1") == 0)
        {
            return CERT_SHA_1;
        }
        else if (strcasecmp(pszSignHashMech, "sha224") == 0)
        {
            return CERT_SHA_224;
        }
        else if (strcasecmp(pszSignHashMech, "sha256") == 0)
        {
            return CERT_SHA_256;
        }
        else if (strcasecmp(pszSignHashMech, "sha384") == 0)
        {
            return CERT_SHA_384;
        }
        else if (strcasecmp(pszSignHashMech, "sha512") == 0)
        {
            return CERT_SHA_512;
        }
        else
        {
            /* this will never occur but is here for the compiler */
            return -1;
        }
    }
}

static CK_RV
PinPrompt(CK_SLOT_ID slot, char * pin, int pinLen)
{
    CK_TOKEN_INFO info;
    CK_RV rv;

    rv = C_GetTokenInfo(slot, &info);
    if ( rv ) return rv;

    rmTrailSpace((char *)info.label, CK_TOKEN_LABEL_SIZE);
    fprintf(stderr, "Enter user PIN for <Slot %ld> %s: ", slot, info.label);
    fflush(stderr);

    enteringPIN = TRUE;
    if ( CON_GetSecret((char *)pin, pinLen) ) {
        return CKR_CANCEL;
    }
    enteringPIN = FALSE;

    return 0;
}

static CK_RV
SOPinPrompt(CK_SLOT_ID slot, char * pin, int pinLen)
{
    CK_TOKEN_INFO info;
    CK_RV rv;

    rv = C_GetTokenInfo(slot, &info);
    if ( rv ) return rv;

    rmTrailSpace((char *)info.label, CK_TOKEN_LABEL_SIZE);
    fprintf(stderr, "Enter SO PIN for <Slot %ld> %s: ", slot, info.label);
    fflush(stderr);

    enteringPIN = TRUE;
    if ( CON_GetSecret((char *)pin, pinLen) ) {
        return CKR_CANCEL;
    }
    enteringPIN = FALSE;

    return 0;
}

#endif //////////////////////


static CK_RV
DoLogin(CK_SESSION_HANDLE hSession, unsigned int retry)
{
	CK_RV rv = CKR_OK;

	while (retry != 0) {
		char pin[128];
		unsigned int pinLen;

		printf("Please Enter the PIN: ");
		pinLen = CON_GetSecret(pin, sizeof(pin));
		printf("\n");

		rv = C_Login(hSession, usertype, (CK_CHAR_PTR)pin, strlen(pin));
		if (rv != CKR_PIN_INCORRECT) {
			break;
		}
		fprintf(stderr, "Pin incorrect.\n");
		retry -= 1;
	}
	return rv;
}

/* search for a list of matching objects 
 * Return: non zero if a procesing error
 * Return: zero - objList returned (it maybe empty)
 */
CK_RV
FindObject(
	CK_SESSION_HANDLE hSession,
	CK_BYTE_PTR id,             /* CKA_ID may be NULL */
    CK_SIZE     idLen,
	char * name,                /* CKA_LABEL */
	ObjList ** ppobjList          /* OUT */
	)
{
	CK_RV rv;
	CK_ATTRIBUTE * cka;
	CK_COUNT objectCount = 0;
    CK_OBJECT_HANDLE hObj;
    ObjList * pobjList = NULL;

	CK_ATTRIBUTE tplate[] = {
		{CKA_LABEL, NULL, 0},
		{CKA_CLASS, NULL, 0},
		{CKA_ID,    NULL, 0}
	};
    CK_COUNT        tplateLen = NUMITEMS(tplate);

    pobjList = NewObjList();
    if (pobjList==NULL) return CKR_HOST_MEMORY;

    /* plug in label into search template */
	cka = FindAttribute(CKA_LABEL, tplate, NUMITEMS(tplate));
	cka->pValue = name;
	cka->valueLen = (CK_SIZE) strlen(name);

    /* plug in class into search template */
	cka = FindAttribute(CKA_CLASS, tplate, NUMITEMS(tplate));
	cka->pValue = &objtype;
	cka->valueLen = sizeof(objtype);

    /* if ID is provided then add this to the search template */
    if ( id )
    {
	    cka = FindAttribute(CKA_ID, tplate, NUMITEMS(tplate));
	    cka->pValue = id;
	    cka->valueLen = idLen;
    } else
        --tplateLen;

    /* start search */
	rv = C_FindObjectsInit(hSession, tplate, tplateLen);
	if ( rv ) goto error;

    /* scan for all matching objects */
    do 
    {
	    rv = C_FindObjects(hSession, &hObj, 1, &objectCount);
	    if ( rv ) goto error;

        if ( objectCount )
        {
            if ( !ObjListAdd(pobjList, hObj) )
            {
                rv = CKR_HOST_MEMORY;
                goto error;
            }
        }

    } while (objectCount != 0);

	rv = C_FindObjectsFinal(hSession);
	if ( rv ) goto error;

    *ppobjList = pobjList;

error:
    if (rv) FreeObjList(pobjList);

	return rv;
}



#define SLOTIDKEYWORD "SLOTID="
#define Slotidkeyword "slotid="

CK_RV FindKeyFromSpecAndId( char * keyspec,             /*IN */
	                        CK_BYTE_PTR id,             /* IN CKA_ID may be NULL */
                            CK_SIZE     idLen,          /* IN */
                            CK_SESSION_HANDLE * phSession, /* OUT */
                            ObjList ** ppObjList )      /* OUT */
{
	CK_RV rv;
	/* signkey slot key session handles */
	CK_SLOT_ID hsSlot;
	CK_SESSION_HANDLE hsSession;

	char *pin = NULL;
	char *ptr = 0;
	char *label = 0;
	CK_BBOOL hasPin = FALSE;
    ObjList * pObjList = NULL;

	/* set ptr to point to character following the token label */
	ptr = strchr(keyspec, '(');
	if(ptr != NULL && strchr(keyspec, '/')>ptr)
		hasPin = TRUE;
	else if ((ptr = strchr(keyspec, '/')) == NULL) {
		fprintf(stderr, "Invalid Signing Key Format\n");
		return CKR_ARGUMENTS_BAD;
	}

	/* keyspec has the format <token name>(pin)/<signing key> or
	   <token name>/<signing key>. We null terminate the <token name>
	   part of the string so that we can find out which slot it is in.
	*/
	*ptr = '\0';
	if ( memcmp(keyspec, SLOTIDKEYWORD, strlen(SLOTIDKEYWORD)) == 0 ||
	     memcmp(keyspec, Slotidkeyword, strlen(Slotidkeyword)) == 0 )
		hsSlot = atoi(keyspec + strlen(SLOTIDKEYWORD));
	else
	{
		if ((rv = FindTokenFromName(keyspec, &hsSlot)) != CKR_OK) {
			CT_ErrorString(rv, ErrorString, sizeof(ErrorString));
			fprintf(stderr, "%s: Error finding token (%s), %s\n", ProgName, keyspec, ErrorString);
			return CKR_ARGUMENTS_BAD;
		}
	}

	if ((rv = C_OpenSession(hsSlot, CKF_RW_SESSION | CKF_SERIAL_SESSION,
			NULL, NULL, &hsSession)) != CKR_OK) {
		CT_ErrorString(rv, ErrorString, sizeof(ErrorString));
		fprintf(stderr, "%s: Error opening session to slot %ld, %s\n", ProgName, hsSlot,
			ErrorString);
		return CKR_ARGUMENTS_BAD;
	}

	/* Need to login */
	if (hasPin == TRUE) {

		/* Restore the string to what it was before we called
		   FindTokenFromName ().
		*/
		*ptr = '(';

		/* Record the pin position in the string. It may be used later. */
		pin = ptr + 1;
	}
	else {
		/* Restore the original string */
		*ptr = '/';
	}

	/* locate signing key */
	ptr = strchr(keyspec, '/');
	if (ptr == NULL) {
		fprintf(stderr, "Invalid Signing Key Format");
		rv = CKR_ARGUMENTS_BAD;
        goto error;
	}
	label = ptr + 1;

    /* attempt search for public object */
	if ((rv = FindObject(hsSession, id, idLen, label, &pObjList)) != CKR_OK)
        goto error;

	if (pObjList->num == 0) 
    {
        /* discard empty obj list */
        FreeObjList(pObjList);
        pObjList = NULL;

		/* Failed to open object... Because it is a private one? 
		 * Do a C_Login to see.
		 */
		if (hasPin == TRUE) {
			
			/* Find the end of pin string */
			if ((ptr = strchr(pin, ')')) == NULL) {
				fprintf(stderr, "Invalid Signing Key Format\n");
				goto error;
			}

			/* Mark as End of String */
			*ptr = 0;

			rv = C_Login(hsSession, usertype, (CK_BYTE_PTR)pin, strlen(pin));
			if (!((rv == CKR_OK) || (rv == CKR_PIN_INCORRECT))) {
				CT_ErrorString(rv, ErrorString, sizeof(ErrorString));
				fprintf(stderr, "%s: Error logging in, %s\n", ProgName,
						ErrorString);
				goto error;
			}

			/* Restore the original string. */
			*ptr = ')';
			
			/* Correct pin? */
			if (rv == CKR_PIN_INCORRECT) {
				fprintf(stderr, "Pin incorrect. Try Again.\n");
				rv = DoLogin(hsSession, 2);
			}

			if (rv != CKR_OK) {
				CT_ErrorString(rv, ErrorString, sizeof(ErrorString));
				fprintf(stderr, "%s: Error logging in, %s\n", ProgName,
						ErrorString);
				goto error;
			}

		}
		else {
			rv = DoLogin(hsSession, 3);
			if (rv != CKR_OK) {
				CT_ErrorString(rv, ErrorString, sizeof(ErrorString));
				fprintf(stderr, "%s: Error logging in, %s\n", ProgName,
						ErrorString);
				goto error;
			}
		}

	    /* We are logged in now.. Try and see if it still fails. */
	    if ((rv = FindObject(hsSession, id, idLen, label, &pObjList)) != CKR_OK) 
            goto error;
    }
	
error:
    if ( rv ) 
        C_CloseSession(hsSession);
    else
    {
        *phSession = hsSession;
        *ppObjList = pObjList;
    }

    return rv;
}


/*** check if token supports limits ***/

static
CK_BBOOL TokenSupportsLimits(CK_SESSION_HANDLE hSession)
{
    CK_SESSION_INFO sInfo;
    CK_MECHANISM_INFO mInfo;

    if ( C_GetSessionInfo(hSession, &sInfo) )
        return FALSE;

    if ( C_GetMechanismInfo(sInfo.slotID, CKM_SET_ATTRIBUTES, &mInfo) )
        return FALSE;

    return TRUE;
}


/*
    Show Object Attributes
  label
  modifiable
  id
  limit
  start
  end
  admin cert

*/

#define ATTRIBUTE_MAX_CHARS_PER_LINE 32

#undef FN
#define FN "ShowObject:"

CK_RV ShowObject(CK_SESSION_HANDLE hSession,
                 CK_OBJECT_HANDLE hObject,
                 CK_MECHANISM_PTR pDigestMech)
{
    CK_RV rv;
    unsigned int i;

    CK_ATTRIBUTE_PTR pAttribute = NULL;
	CK_TOKEN_INFO   tInfo;
    CK_SESSION_INFO sInfo;
    CK_BYTE_PTR     pSig = NULL;
    CK_ULONG        ulSig;
    unsigned char* pszAttrVal = NULL;
    CK_CHAR         tmpCh;
    CK_CHAR_PTR     tcp = NULL;		

    /* get the list of attribute types */
    CK_ATTRIBUTE objAttr[] = 
    {
        {CKA_LABEL,         NULL, 0},
        {CKA_MODIFIABLE,    NULL, 0},
        {CKA_ID,            NULL, 0},
        {CKA_USAGE_COUNT,   NULL, 0},
        {CKA_USAGE_LIMIT,   NULL, 0},
        {CKA_START_DATE,    NULL, 0},
        {CKA_END_DATE,      NULL, 0},
        {CKA_ADMIN_CERT,    NULL, 0}
    };
    CK_ULONG attrCount = NUMITEMS(objAttr);

    if ( (rv = C_GetSessionInfo(hSession, &sInfo)) != 0 )
        return rv;

    if ((rv = C_GetTokenInfo(sInfo.slotID, &tInfo)) != 0 )
        return rv;

    printf("\tToken SerialNo = ");
    /* Search for first ' ' and replace it with '\0'	*/
    for (i = 0, tcp =  tInfo.serialNumber; 
                i < CK_TOKEN_SERIAL_NUMBER_SIZE; i++, tcp++) {
      if (*tcp == ' ') {
        *tcp = '\0';
        break;
      }
    }			
    if (*tcp != '\0') {
      tmpCh = tInfo.serialNumber[CK_TOKEN_SERIAL_NUMBER_SIZE];				
      tInfo.serialNumber[CK_TOKEN_SERIAL_NUMBER_SIZE] = 0;
    }			
    printf("\"%s\"\n", tInfo.serialNumber);
    if (*tcp != '\0') {		
      tInfo.serialNumber[CK_TOKEN_SERIAL_NUMBER_SIZE] = tmpCh;
    } else {
      *tcp = ' ';
    }			

    printf("\tToken Label =    ");
    /* Search for first ' ' and replace it with '\0'	*/
    for (i = 0, tcp =  tInfo.label; 
                i < CK_TOKEN_LABEL_SIZE; i++, tcp++) {
      if (*tcp == ' ') {
        *tcp = '\0';
        break;
      }
    }			
    if (*tcp != '\0') {
      tmpCh = tInfo.serialNumber[CK_TOKEN_LABEL_SIZE];				
      tInfo.serialNumber[CK_TOKEN_LABEL_SIZE] = 0;
    }			
    printf("\"%s\"\n", tInfo.label);
    if (*tcp != '\0') {		
      tInfo.serialNumber[CK_TOKEN_LABEL_SIZE] = tmpCh;
    } else {
      *tcp = ' ';
    }			

    for (i = 0; i < attrCount; ++i)
    {
        pAttribute = &objAttr[i];

        /* get the attribute value length */
        rv = C_GetAttributeValue(hSession, hObject, pAttribute, 1);

        if ( rv == CKR_OK )
        {
            /* allocate space for the attribute value */
            pAttribute->pValue = SAFE_MALLOC(pAttribute->valueLen + 1);
            if (pAttribute->pValue == NULL)
            {
                return CKR_HOST_MEMORY;
            }
        }

        /* get the attribute value */
        rv = C_GetAttributeValue(hSession, hObject, pAttribute, 1);

        printf( "\tCKA_%s = ", strAttribute(pAttribute->type));

        if (rv != CKR_OK)
        {
            if (rv == CKR_ATTRIBUTE_SENSITIVE)
            {
                printf("*** Value Sensitive ***\n");
            } else if (rv == CKR_ATTRIBUTE_TYPE_INVALID) {
                printf("<no attribute>\n");
            }
            else
            {
                printf("*** ERROR : %s ***\n", strError(rv));
            }
        }
        else
        {
            /* Get the value as a string */
            char* pszAttrVal = NULL;
            CK_SIZE attrValLen = 0;

            rv = CT_AttrToString(pAttribute,
                                 pszAttrVal,
                                 &attrValLen);
            if (rv != CKR_OK) 
            {
                printf("*** ERROR : %s ***\n", strError(rv));
                continue;
            }

            pszAttrVal = (char*) SAFE_MALLOC(attrValLen);
            if (pszAttrVal == NULL) return CKR_HOST_MEMORY;

            rv = CT_AttrToString(pAttribute,
                                 pszAttrVal,
                                 &attrValLen);
            if (rv != CKR_OK) 
            {
                free(pszAttrVal);
                printf("*** ERROR : %s ***\n", strError(rv));
                continue;
            }

            /* Now print it out - make sure it fits within specified width*/
            if (attrValLen <= ATTRIBUTE_MAX_CHARS_PER_LINE)
            {
                printf("%s\n", pszAttrVal);
            }
            else
            {
                unsigned int j = 0;

                for (j = 0; j < strlen(pszAttrVal); j ++)
                {
                    if (!(j%ATTRIBUTE_MAX_CHARS_PER_LINE))
                    {
                        printf("\n\t    ");
                    }

                    printf("%.1s", &(pszAttrVal[j]));
                }

                printf("\n");
            }

            free(pszAttrVal);
            pszAttrVal = NULL;
        }

        /* free attribute value memory */
        free(pAttribute->pValue);
    }

    if ( (rv = CT_GetObjectDigest(hSession, hObject, pDigestMech, &pSig, &ulSig)) != 0)
        return rv;

    if ( (pszAttrVal = (CK_BYTE_PTR)SAFE_MALLOC(ulSig*2+1)) == NULL )
    {
        free(pSig);
        return CKR_HOST_MEMORY;
    }

    bin2hex( (char*)pszAttrVal, pSig, ulSig );
    free(pSig);

    printf( "\tObjDigest = ");

    {
        unsigned int j = 0;

        for (j = 0; j < strlen((char*)pszAttrVal); j ++)
        {
            if (!(j%ATTRIBUTE_MAX_CHARS_PER_LINE))
            {
                printf("\n\t    ");
            }

            printf("%.1s", &(pszAttrVal[j]));
        }

        printf("\n");
    }

    free(pszAttrVal);

    /* put a blank line after the attr set */
    printf("\n");

    return CKR_OK;
}


/*
 * ctlimits vk	[-U<usertype>] -k <keyspec> [-i<key_id>]
 */

CK_RV ViewKey(void)
{
    CK_RV rv;
    CK_SESSION_HANDLE hSession;
    ObjList * pObjList = NULL;
    unsigned int i;

    rv = FindKeyFromSpecAndId( keyspec,
                            target_key_id_len ? target_key_id : NULL,
                            target_key_id_len,
                            &hSession,
                            &pObjList );
    if ( rv )
        return rv;

    if ( pObjList->num == 0 )
    {
		fprintf(stderr, "%s: No matching objects found\n", ProgName);
        return 0;
    }

    /*******
     *******  Check to see if this token can support Limit operation 
     *******/

    if ( !TokenSupportsLimits(hSession) )
    {
		fprintf(stderr, "%s: Warning Target token does not support usage limits (upgrade FW)\n\n", ProgName);
    }

    /*******
     *******  Display all the matching objects
     *******/

    for ( i=0; i<pObjList->num; ++i)
    {
        CK_MECHANISM digestMech = { CKM_SHA256 };

        rv = ShowObject(hSession, pObjList->objs[i], &digestMech);
        if ( rv )
            return rv;
    }

    FreeObjList(pObjList);

    C_CloseSession(hSession);

    return rv;
}

CK_RV GetFileContents(char * filename, char **pbuf, size_t * pfileLength)
{
    CK_RV rv;

    FILE * ifile = NULL;
    size_t fileLength;
    char * buf = NULL;

    ifile = fopen(filename, "r");
    if ( ifile == NULL )
    {
		fprintf(stderr, "%s: Cannot open file %s\n", ProgName, filename);
        rv = CKR_FUNCTION_FAILED;
        goto error;
    }

    /* determine length of the file */
    if ((rv = fseek (ifile, 0, SEEK_END)) != 0)
    {
		fprintf(stderr, "%s: Error determining length of %s\n", ProgName, filename);
        goto error;
    }
    
    fileLength = ftell (ifile);
    rewind (ifile);

    /* get a buffer to hold the file contents */
    buf = malloc(fileLength);
    if (buf == NULL)
    {
        rv = CKR_FUNCTION_FAILED;
        goto error;
    }
    
    /* read file contents into buffer */
    if ( (fileLength = fread(buf, 1, fileLength, ifile)) == 0 )
    {
		fprintf(stderr, "%s: Unable to read %s\n", ProgName, filename);
        rv = CKR_FUNCTION_FAILED;
        goto error;
    }

    *pfileLength = fileLength;
    *pbuf = buf;

error:

    if ( ifile )
        fclose(ifile);

    if (rv && buf)
        free (buf);

    return rv;
}

/* 
 * ctlimits pt	[-U<usertype>] -k <keyspec> [-i<key_id>] filename
 */

CK_RV PresentTicket(void)
{
    CK_RV rv;
    CK_SESSION_HANDLE hSession;
    ObjList * pObjList = NULL;
    char * buf = NULL;
    size_t fileLength;
    CK_MECHANISM mechanism = { CKM_SET_ATTRIBUTES };
    CK_VOID_PTR 	pData = NULL;
    CK_ULONG  	    ulDataLen;


    rv = FindKeyFromSpecAndId( keyspec,
                            target_key_id_len ? target_key_id : NULL,
                            target_key_id_len,
                            &hSession,
                            &pObjList );
    if ( rv )
        return rv;

    if ( pObjList->num == 0 )
    {
		fprintf(stderr, "%s: No matching objects found\n", ProgName);
        rv = 1;
        goto error;
    }

    if ( pObjList->num != 1 )
    {
		fprintf(stderr, "%s: Too many matching objects found\n", ProgName);
        rv = 1;
        goto error;
    }

    /*
    ** Check to see if this token can support Limit operation 
    **/

    if ( !TokenSupportsLimits(hSession) )
    {
		fprintf(stderr, "%s: Target token does not support this operation (upgrade FW)\n", ProgName);
        rv = CKR_FUNCTION_NOT_SUPPORTED;
        goto error;
    }

    /* 
    ** read ticket from file and present to target key 
    */

    if ( (rv = GetFileContents(filename, &buf, &fileLength)) != 0 )
        goto error;

    /* extract certificate from file contents */
    if ((rv = CT_Structure_From_Armor( "ATTRIBUTE_CERTIFICATE", (CK_BYTE_PTR)buf, fileLength,	&pData, &ulDataLen)) != 0)
    {
		fprintf(stderr, "%s: Unable to recover ATTRIBUTE_CERTIFICATE from %s\n", ProgName, filename);
        goto error;
    }

    /* present the ticket */
    rv = CT_PresentTicket(hSession, pObjList->objs[0], &mechanism, pData, ulDataLen);
    if ( rv != CKR_OK )
        printf("%s : Error presenting ticket: %s ***\n", ProgName, strError(rv));

error:

    if (buf)
        free (buf);

    if (pData)
        free (pData);

    FreeObjList(pObjList);

    C_CloseSession(hSession);

    return rv;
}


/*
 * ctlimits up	[-U<usertype>] [-O <objtype>] -k <keyspec> [-i<key_id>] 
 * [-C<count>] [-L<limit>] [-s<time>] [-e<time>] [-c<cert_file_name>]
 */

CK_RV UpdateAttributes(void)
{
    CK_RV rv;
    CK_SESSION_HANDLE hSession;
    ObjList * pObjList = NULL;

    /* PK certificate informatin */
    CK_VOID_PTR 	pData = NULL;
    CK_ULONG  	    ulDataLen = 0;

    /*******
     *******  Identify Target object 
     *******/

    rv = FindKeyFromSpecAndId( keyspec,
                            target_key_id_len ? target_key_id : NULL,
                            target_key_id_len,
                            &hSession,
                            &pObjList );
    if ( rv )
        return rv;

    if ( pObjList->num == 0 )
    {
		fprintf(stderr, "%s: No matching objects found\n", ProgName);
        rv = 1;
        goto error;
    }

    if ( pObjList->num != 1 )
    {
		fprintf(stderr, "%s: Too many matching objects found\n", ProgName);
        rv = 1;
        goto error;
    }

    /*******
     *******  Check to see if this token can support Limit operation 
     *******/

    if ( !TokenSupportsLimits(hSession) )
    {
		fprintf(stderr, "%s: Target token does not support this operation (upgrade FW)\n", ProgName);
        rv = CKR_FUNCTION_NOT_SUPPORTED;
        goto error;
    }


    /*******
     *******  Get Certificate (if any) and apply other attributes
     *******/

    if (cert_file_name)
    {
        char * buf = NULL;
        size_t fileLength;

        if ( (rv = GetFileContents(cert_file_name, &buf, &fileLength)) != 0 )
            goto error;

        rv = CT_Structure_From_Armor( "CERTIFICATE", (CK_BYTE_PTR)buf, fileLength,	&pData, &ulDataLen);
        free (buf);
        if (rv) {
		    fprintf(stderr, "%s: Unable to recover CERTIFICATE from %s\n", ProgName, filename);
            goto error;
        }
    }

    rv = CT_SetLimitsAttributes( hSession,
                              pObjList->objs[0],
                              pData,
                              ulDataLen,
                              str_usage_limit ? &usage_limit : NULL,
                              str_usage_count ? &usage_count : NULL,
                              start_date,
                              end_date);

    if (pData)
        free (pData);

    if ( rv )
    {
        printf("%s : Error setting attributes: %s ***\n", ProgName, strError(rv));
        goto error;
    }

    /*******
     *******  lock down object by setting Modifiable=false
     *******/

    rv = CT_MakeObjectNonModifiable( hSession, pObjList->objs[0], NULL);
    if ( rv )
    {
        printf("%s : Error making object non-modifiable: %s ***\n", ProgName, strError(rv));
        goto error;
    }

error:

    FreeObjList(pObjList);

    C_CloseSession(hSession);

    if ( rv == CKR_OK )
        printf("Attributes set OK\n");

    return rv;
}

/*
 *    ctlimits ct 	[-U<usertype>] -k <keyspec> [-m<message>]
 *       -S<serial_no> -t<tok_label> -l<target_label> -i<key_id>
 *       [-d<time[d|w|m|y]>] [-C<count>] [-L<limit>] [-s<time>] [-e<time>]  filename
 *
 */

CK_RV CreateTicket(void)
{
    CK_RV rv;
    CK_SESSION_HANDLE hSession;
    ObjList * pObjList = NULL;

    /* PK certificate informatin */
    CK_VOID_PTR  pData = NULL;
    CK_ULONG  	 ulDataLen = 0;

    /* Object Digest */
    CK_BYTE_PTR  pDigest = NULL;
    CK_ULONG     ulDigest = 0;

    CK_MECHANISM DigestMech = { CKM_SHA256 };

    CK_CHAR_PTR  pTicketInfo = NULL;
    unsigned int uiTicketInfoLen;

    char * issuerRDN = NULL;

    unsigned long sno;

    CK_MECHANISM signatureAlg;

    CK_KEY_TYPE  keyType;

    CK_BYTE_PTR  pSignature = NULL;
    CK_ULONG     ulSignatureLen;

    CK_CHAR_PTR  pTicket = NULL;
    unsigned int uiTicketLen;

    CK_BYTE_PTR  pArmor;
    CK_ULONG     ulArmorLen;

    FILE * ofile = NULL;

    /*******
     *******  Identify signing Key
     *******/

    rv = FindKeyFromSpecAndId( keyspec,
                            (CK_BYTE_PTR)NULL,  /* ID is used to make ticket not find signing key */
                            0,
                            &hSession,
                            &pObjList );
    if ( rv )
        return rv;

    if ( pObjList->num == 0 )
    {
		fprintf(stderr, "%s: No signing Key found\n", ProgName);
        rv = 1;
        goto error;
    }

    if ( pObjList->num != 1 )
    {
		fprintf(stderr, "%s: Too many signing keys found\n", ProgName);
        rv = 1;
        goto error;
    }

    /*******
     *******  Get Signing Key CKA_KEY_TYPE, CKA_USAGE_COUNT and CKA_SUBJECT_STR (if any)
     *******/
    {
        CK_ATTRIBUTE att;

        att.type = CKA_SUBJECT_STR;
        att.pValue = NULL;
        att.valueLen = 0;

        /* fetch CKA_SUBJECT_STR from signing key - 
         * if none found then we will not worry as this is optional value 
        */
        rv = C_GetAttributeValue(hSession, pObjList->objs[0], &att, 1);
        if ( rv == 0 )
        {
            if ( (issuerRDN = malloc(att.valueLen)) == NULL )
            {
		        fprintf(stderr, "%s: Memory error\n", ProgName);
                rv = 1;
                goto error;
            }
            att.pValue = issuerRDN;
            if ( (rv = C_GetAttributeValue(hSession, pObjList->objs[0], &att, 1)) != 0 )
            {
                free(issuerRDN);
                issuerRDN = NULL;
            }
        }
        
        /* fetch CKA_USAGE_COUNT from signing key - 
         * if none found then we will not worry - we will default the value 
        */
        sno = 0;    /* set default value */

        att.type = CKA_USAGE_COUNT;
        att.pValue = &sno;
        att.valueLen = sizeof(sno);

        C_GetAttributeValue(hSession, pObjList->objs[0], &att, 1);

        /* fetch CKA_KEY_TYPE from signing key. 
        */
        
        att.type = CKA_KEY_TYPE;
        att.pValue = &keyType;
        att.valueLen = sizeof(keyType);

        if ( (rv = C_GetAttributeValue(hSession, pObjList->objs[0], &att, 1)) != 0 )
        {
            printf("%s : Error reading Key Type of signing key: %s ***\n", ProgName, strError(rv));
            goto error;
        }
    }

    /*******
     *******  Construct Object digest
     *******/

    rv = CT_GetObjectDigestFromParts(
                 hSession,
                 &DigestMech,
                 token_sno,
                 token_label,
                 target_label,
                 target_key_id,
                 target_key_id_len,

                 &pDigest,   /* OUT returned buffer (must be freed by caller) */
                 &ulDigest   /* OUT length of returned buffer */
                 );
    if ( rv )
    {
        printf("%s : Error computing object digest: %s ***\n", ProgName, strError(rv));
        goto error;
    }

    /*******
     *******  Get Admin Cert contents (if any)
     *******/

    if (cert_file_name)
    {
        char * buf = NULL;
        size_t fileLength;

        if ( (rv = GetFileContents(cert_file_name, &buf, &fileLength)) != 0 )
            goto error;

        rv = CT_Structure_From_Armor( "CERTIFICATE", (CK_BYTE_PTR)buf, fileLength,	&pData, &ulDataLen);
        free (buf);
        if ( rv )
        {
		    fprintf(stderr, "%s: Unable to recover CERTIFICATE from %s\n", ProgName, filename);
            goto error;
        }
    }

    /*******
     *******  Determine signing algorithm based on key type
     *******/

    memset( &signatureAlg, 0, sizeof(signatureAlg));

    switch( keyType )
    {
        case CKK_RSA:
            signatureAlg.mechanism = CKM_SHA256_RSA_PKCS;
            break;

        case CKK_DSA:
            signatureAlg.mechanism = CKM_DSA_SHA1_PKCS;
            break;

        case CKK_ECDSA:
            signatureAlg.mechanism = CKM_ECDSA_SHA1;
            break;

        default:
		    fprintf(stderr, "%s: Signing Key type not valid: %s\n", ProgName, strKeyType(keyType));
            goto error;

    }

    /*******
     *******  Build ticket Info
     *******/

    rv = CT_Create_Set_Attributes_Ticket_Info
    ( 
        DigestMech.mechanism, /* digest alg */
        pDigest, /* digest of target object */
	    ulDigest,

        issuerRDN,       /* may be NULL or 
                                 * DER of DistName or 
                                 * Common Name string or
                                 * RDN Seq string (CN=Fred+C=USA) */
        strlen(issuerRDN),

        signatureAlg.mechanism, /* signature alg type */

        sno,      /* Attrib Cert serial number */
        cert_start_date,        /* YYYYMMDD string */
        cert_end_date,          /* YYYYMMDD string */


        str_usage_limit ? &usage_limit : NULL,  /* NULL if no CKA_USAGE_LIMIT */
        start_date,             /* NULL if no CKA_START_DATE */
        end_date,               /* NULL if no CKA_END_DATE */
        pData,            /* NULL if no CKA_ADMIN_CERT */
        ulDataLen,

        &pTicketInfo, /* OUT new unsigned ticket returned here - must be freed by caller */
        &uiTicketInfoLen  /* OUT *pTicketInfo buffer length */
    );

    if ( rv )
    {
        printf("%s : Error computing object digest: %s ***\n", ProgName, strError(rv));
        goto error;
    }

    /*******
     *******  Create signature of Cert Info
     *******/

    rv = C_SignInit(hSession, &signatureAlg, pObjList->objs[0]);
    if ( rv )
    {
        printf("%s : Error initialising signing operation: %s ***\n", ProgName, strError(rv));
        goto error;
    }

    rv = C_Sign(hSession, pTicketInfo, uiTicketInfoLen, NULL, &ulSignatureLen );
    if ( rv )
    {
        printf("%s : Error performing signing operation: %s ***\n", ProgName, strError(rv));
        goto error;
    }

    if ( (pSignature = malloc(ulSignatureLen)) == NULL )
    {
		fprintf(stderr, "%s: Memory error\n", ProgName);
        rv = 1;
        goto error;
    }

    rv = C_Sign(hSession, pTicketInfo, uiTicketInfoLen, pSignature, &ulSignatureLen );
    if ( rv )
    {
        printf("%s : Error performing signing operation: %s ***\n", ProgName, strError(rv));
        goto error;
    }

    /*******
     *******  Create signed cert
     *******/

    rv = CT_Create_Set_Attributes_Ticket( 
            pTicketInfo,    		    /* IN unsigned ticket info */
            uiTicketInfoLen, 	/* IN pTicketInfo buffer length */

            signatureAlg.mechanism, /* signature alg */
            pSignature, 	/* IN signature of pTicketData */
            ulSignatureLen, 		    /* IN pSignature buffer length */

            &pTicket,     /* OUT new signed ticket (caller must free) */
            &uiTicketLen 	/* IN/OUT pTicketData buffer length */
                        );

    if ( rv )
    {
        printf("%s : Error constructing signed ticket: %s ***\n", ProgName, strError(rv));
        goto error;
    }

    /*******
     *******  store ticket into output file
     *******/

    rv = CT_Structure_To_Armor( 
            "ATTRIBUTE_CERTIFICATE",	/* IN Armor label (string) */
            message,		            /* IN optional comment string (my be NULL) */
            pTicket, 	                /* IN data to armor */
            uiTicketLen, 	            /* IN length of data */

            &pArmor, 	                /* OUT Armored structure created */
            &ulArmorLen	                /* IN/OUT pArmor buffer length */
                            );
    if ( rv )
    {
        printf("%s : Error constructing PEM encoding: %s ***\n", ProgName, strError(rv));
        goto error;
    }

    ofile = fopen(filename, "w");
    if ( ofile == NULL )
    {
		fprintf(stderr, "%s: Cannot create file %s\n", ProgName, filename);
        rv = 1;
        goto error;
    }

    if ( fwrite( pArmor, 1, ulArmorLen, ofile) != ulArmorLen )
    {
		fprintf(stderr, "%s: Error writing to %s\n", ProgName, filename);
        rv = 1;
        goto error;
    }

    printf("Ticket created OK\n");

error:
    if (pDigest)
        free(pDigest);

    if (pData)
        free(pData);

    if (pTicketInfo)
        free(pTicketInfo);

    if (issuerRDN)
        free(issuerRDN);

    if (pSignature)
        free(pSignature);
    
    if (pTicket)
        free(pTicket);

    if (ofile)
        fclose(ofile);

    return rv;
}


int
main(int argc, char **argv)
{
    CK_RV rv;

    getOption_t myOptions[] = {
        { opt_help,        "help",                'h', NULL, "View this help",
            NULL },
 
        { opt_string,    "usertype",        'U', &str_usertype,
            "User type creating ticket-\n\t\t\t\tmay be either 'SO' or 'USER' (default)",
            "<user>" },

         { opt_string,    "keyspec",            'k', &keyspec,
            "Specification a key.\n"
            "\t\t\t\tExample format for keyspec\n"
            "\t\t\t\tTokenLabel/KeyLabel\n"
            "\t\t\t\tor TokenLabel(pin)/KeyLabel\n"
            "\t\t\t\tor slotid=2(pin)/KeyLabel\n"
            "\t\t\t\tor on unix TokenLabel\\(pin\\)/KeyLabel\n"
            , "<keyspec>" },

         { opt_string,    "objtype",            'O', &str_objtype,
            "May be secret_key, \n\t\t\t\tcertificate,public_key or private_key", "<objtype>" },

        { opt_string,    "message",    'm', &message,
            "Optional message to add\n\t\t\t\tto ticket",
            "<message>" },

        { opt_string,    "duration",    'd', &str_duration,
            "Duration (lifetime) of\n\t\t\t\tticket in days (default is 1 day)",
            "<days>" },

        { opt_string,    "token_label",        't', &token_label,
            "Label of token containing\n\t\t\t\tthe target object (may be numeric\n\t\t\t\tto refer to token by slot number)",
            "<tok_label>" },

        { opt_string,    "tok_sno",        'S', &token_sno,
            "Serial number of Token \n\t\t\t\tcontaining the target object.", "<serial_no>" },

        { opt_string,    "target_label",            'l', &target_label,
            "Label of object that is \n\t\t\t\tthe target of the operation", "<target_label>" },

        { opt_string,    "target_key_id",                'i', &str_target_key_id,
            "Key ID of object that is \n\t\t\t\tthe target of the operation.\n\t\t\t\tkey_id should be in HEX format", "<key_id>" },

        { opt_string,    "usage_usage_count",                'C', &str_usage_count,
            "Specify CKA_USAGE_COUNT value\n\t\t\t\t'count' is in decimal format.", "<count>" },

        { opt_string,    "usage_limit",                'L', &str_usage_limit,
            "Specify CKA_USAGE_LIMIT value\n\t\t\t\t'limit' is in decimal format.", "<limit>" },

        { opt_string,    "start_date",                's', &start_date,
            "Specify new CKA_START_DATE\n\t\t\t\tvalue for the target object.\n\t\t\t\t 'time' format is YYYYMMDD-\n\t\t\t\tthe time specified is GMT.", "<date>" },

        { opt_string,    "end_date",                'e', &end_date,
            "Specify new CKA_END_DATE\n\t\t\t\tvalue for the target object.\n\t\t\t\t 'time' format is YYYYMMDD-\n\t\t\t\tthe time specified is GMT.", "<date>" },

        { opt_string,    "cert",                'c', &cert_file_name,
            "Name of the file containing a\n\t\t\t\tpublic key certificate\n\t\t\t\tto be applied to CKA_ADMIN_CERT attribute", "<cert_file_name>" },

        { opt_end, NULL, 0, NULL, NULL, NULL}
    };

    getOption_t *returnedOptions, *option;
    
    fprintf(stderr,
        "\nProtectToolkit C Limits Utility " CPROV_VERSION_STR "\n");
	fprintf(stderr, CPROV_COPYRIGHT_STR "\n\n");

    if ((ProgName = strrchr(*argv, DIRSEP)) == NULL)
        ProgName = *argv;
    else
        ProgName++;

    if ((returnedOptions = getOption(&argc, argv, myOptions)) == NULL)
    {
        fprintf(stderr, "Use '%s -h' for help\n", ProgName);
        return 1;
    }

    if (argc < 2)
    {
        if (returnedOptions->optionLetter != 'h')
        {
            fprintf(stderr, "%s: No command specifier\n", ProgName);
            printExtraHelp(ProgName);
        }
        return 1;
    }

	/* consume the program arg */
	++argv;
	--argc;

	/* determine what command is being run */

	if (stricmp(argv[0], "ct") == 0)
		cmd_ct = 1;
	else if (stricmp(argv[0], "pt") == 0)
		cmd_pt = 1;
	else if (stricmp(argv[0], "up") == 0)
		cmd_up = 1;
	else if (stricmp(argv[0], "vk") == 0)
		cmd_vk = 1;
	else {
       fprintf(stderr,
	    "%s: Invalid cmd specified (%s)\n\n", ProgName, argv[0]);
       printExtraHelp(ProgName);
       return 1;
	}

	/* consume the command argument */
	++argv;
	--argc;

	/* convert option values and validate them for consistancy */
    for (option = returnedOptions; option->optionType; option++)
    {
        switch (option->optionLetter)
        {
        case 'h':
            return 0;

        case 'U':
			if ( stricmp(str_usertype, "USER") == 0 )
				usertype = CKU_USER;
			else if ( stricmp(str_usertype, "SO") == 0 )
				usertype = CKU_SO;
			else {
       			fprintf(stderr,
	    			"%s: Invalid User specified (%s)\n", ProgName, str_usertype);
       			return 1;
			}

			break;

        case 'O':
			if ( stricmp(str_objtype, "certificate") == 0 )
				objtype = CKO_CERTIFICATE;
			else if ( stricmp(str_objtype, "public_key") == 0 )
				objtype = CKO_PUBLIC_KEY;
			else if ( stricmp(str_objtype, "private_key") == 0 )
				objtype = CKO_PRIVATE_KEY;
			else if ( stricmp(str_objtype, "secret_key") == 0 )
				objtype = CKO_SECRET_KEY; 
			else {
       			fprintf(stderr,
	    			"%s: Invalid Object Type specified (%s)\n", ProgName, str_objtype);
       			return 1;
			}

			if ( cmd_ct )
			{
                fprintf(stderr,
                "%s: 'O' option not allowed on 'ct' command.\n",
                        ProgName);
                return 1;
			}

			break;

        case 'k':
			if ( strchr(keyspec, '/') == NULL )
			{
       			fprintf(stderr,
	    			"%s: Invalid Key specified (%s)\n", ProgName, keyspec);
       			return 1;
			}

			break;

        case 'i':
            if ( strlen(str_target_key_id) > sizeof(target_key_id)*2 )
            {
       			fprintf(stderr,
	    			"%s: Option 'i' too large (%s)\n", ProgName, str_target_key_id);
       			return 1;
            }
            
            if ( (target_key_id_len=hex2bin(target_key_id, str_target_key_id, sizeof(target_key_id))) == 0 )
            {
       			fprintf(stderr,
	    			"%s: Invalid Hex string (%s)\n", ProgName, str_target_key_id);
       			return 1;
            }
			break;

        case 'L':
            {
                char * ptr = str_usage_limit;
                do {
                    if ( !(*ptr == ' ' || (*ptr >= '0' && *ptr <= '9')) )
                    {
                        fprintf(stderr,
            "%s: Can only decimal digits for usage limit option (-L=%s)\n",
                            ProgName, str_usage_limit);
                        return 1;
                    }
                } while(*++ptr); 
                
            }
			usage_limit = atoi(str_usage_limit);

			if ( !(cmd_ct || cmd_up) )
			{
                fprintf(stderr,
                "%s: 'L' option only allowed on 'ct' and 'up' commands.\n",
                        ProgName);
                return 1;
			}
			break;

        case 'C':
            {
                char * ptr = str_usage_count;
                do {
                    if ( !(*ptr == ' ' || (*ptr >= '0' && *ptr <= '9')) )
                    {
                        fprintf(stderr,
            "%s: Can only decimal digits for usage count option (-L=%s)\n",
                            ProgName, str_usage_count);
                        return 1;
                    }
                } while(*++ptr); 
                
            }
			usage_count = atoi(str_usage_count);

			if ( !(cmd_ct || cmd_up) )
			{
                fprintf(stderr,
                "%s: 'C' option only allowed on 'ct' and 'up' commands.\n",
                        ProgName);
                return 1;
			}
			break;

        case 'm':
			if ( !cmd_ct )
			{
                fprintf(stderr,
                "%s: 'm' option only allowed on 'ct' command.\n",
                        ProgName);
                return 1;
			}
			break;

        case 't':
			if ( !cmd_ct )
			{
                fprintf(stderr,
                "%s: 't' option only allowed on 'ct' command.\n",
                        ProgName);
                return 1;
			}
			break;

        case 'S':
			if ( !cmd_ct )
			{
                fprintf(stderr,
                "%s: 'S' option only allowed on 'ct' command.\n",
                        ProgName);
                return 1;
			}
			break;

        case 'l':
			if ( !cmd_ct )
			{
                fprintf(stderr,
                "%s: 'l' option only allowed on 'ct' command.\n",
                        ProgName);
                return 1;
			}
			break;

        case 's':
            if (strlen(start_date) != sizeof(CK_DATE))
            {
                fprintf(stderr,
    "%s: Incorrect date specified for the -s option.\n\tFormat is "
                    "YYYYMMDD.\n", ProgName);
                return 1;
            }

			if ( !(cmd_ct || cmd_up) )
			{
                fprintf(stderr,
                "%s: 's' option only allowed on 'ct' and 'up' commands.\n",
                        ProgName);
                return 1;
			}
            break;

        case 'e':
            if (strlen(end_date) != sizeof(CK_DATE))
            {
                fprintf(stderr,
    "%s: Incorrect date/time specified for the -e option.\n\tFormat is "
                    "YYYYMMDD.\n", ProgName);
                return 1;
            }

			if ( !(cmd_ct || cmd_up) )
			{
                fprintf(stderr,
                "%s: 'e' option only allowed on 'ct' and 'up' commands.\n",
                        ProgName);
                return 1;
			}

            break;

        case 'd':
            {
                int duration;  /* seconds */
                time_t t;

                time(&t);   /* get current time */
                duration = atoi(str_duration) * 60*60*24;

                /* set current date as start date */
                CT_SetCKDateStrFromTime(cert_start_date, &t);

                /* set end date */
                t += duration;
                CT_SetCKDateStrFromTime(cert_end_date, &t);

			    if ( !cmd_ct )
			    {
                    fprintf(stderr,
                    "%s: 'd' option only allowed on 'ct' command.\n",
                            ProgName);
                    return 1;
			    }
            }

            break;

        case 'c':
            if (!(cmd_up || cmd_ct))
            {
                fprintf(stderr,
    "%s: The -c option is only valid when used with the 'up' or 'ct' commands\n",
                    ProgName);
                return 1;
            }

            break;

        default:
            fprintf(stderr, "Unknown option -'%c'\n", option->optionLetter);
            printExtraHelp(ProgName);
            return 1;
        }
    }

    /* ensure sufficient options are provided to run each command */
    if ( cmd_ct )
    {
        if ( keyspec==NULL || token_sno==NULL || token_label==NULL || target_label==NULL || str_target_key_id == NULL ||
            (str_usage_limit==NULL && start_date==NULL && end_date==NULL && cert_file_name==NULL) )
        {
            fprintf(stderr,
                    "%s: ct cmd: Insufficient arguments. Use -h option.\n",
                    ProgName);
                return 1;
        }

        if ( argc > 1 ){
            fprintf(stderr,
                    "%s: ct cmd: Too many arguments. Use -h option.\n",
                    ProgName);
                return 1;
        } else if ( argc == 0 ) {
            fprintf(stderr,
                    "%s: ct cmd: Filename not specified. Use -h option.\n",
                    ProgName);
                return 1;
        } else
           filename = argv[0];
    }
    else if ( cmd_pt )
    {
        if ( keyspec==NULL )
        {
            fprintf(stderr,
                    "%s: pt cmd: Target key not specified. Use -h option.\n",
                    ProgName);
                return 1;
        }

        if ( argc > 1 ){
            fprintf(stderr,
                    "%s: pt cmd: Too many arguments. Use -h option.\n",
                    ProgName);
                return 1;
        } else if ( argc == 0 ) {
            fprintf(stderr,
                    "%s: pt cmd: Filename not specified. Use -h option.\n",
                    ProgName);
                return 1;
        } else
           filename = argv[0];
    }
    else if ( cmd_up )
    {
        if ( keyspec==NULL )
        {
            fprintf(stderr,
                    "%s: up cmd: Target key not specified. Use -h option.\n",
                    ProgName);
                return 1;
        }
        if ( str_usage_count==NULL && str_usage_limit==NULL && start_date==NULL && end_date==NULL && cert_file_name==NULL  )
        {
            fprintf(stderr,
                    "%s: up cmd: At least one attribute is required. Use -h option.\n",
                    ProgName);
                return 1;
        }

        if ( argc > 0 ){
            fprintf(stderr,
                    "%s: up cmd: Too many arguments. Use -h option.\n",
                    ProgName);
                return 1;
        }
    }
    else if ( cmd_vk )
    {
        if ( keyspec==NULL )
        {
            fprintf(stderr,
                    "%s: vk cmd: Target key not specified. Use -h option.\n",
                    ProgName);
                return 1;
        }
        if ( argc > 0 ){
            fprintf(stderr,
                    "%s: vk cmd: Too many arguments. Use -h option.\n",
                    ProgName);
                return 1;
        }
    }

    /*
    ** Argument Parsing complete 
    */

    /* Access HSM */

    rv = C_Initialize(NULL);
    if (rv != CKR_OK)
    {
        fprintf(stderr, "%s: Cannot initialise 0x%lx - %s\n", ProgName, rv,
            strError(rv));
        return 1;    
    }

    /* execute desired function */

    if ( cmd_ct )
    {
        rv = CreateTicket();
    } else if ( cmd_pt )
    {
        rv = PresentTicket();
    } else if ( cmd_up )
    {
        rv = UpdateAttributes();
    } else if ( cmd_vk )
    {
        rv = ViewKey();
    } 

    C_Finalize(NULL);

    return rv;
}




