/**************************************************************************

    Copyright (C) 2004 Eracom Technologies Australia Pty. Ltd.
    All Rights Reserved 

    Use of this file for any purpose whatsoever is prohibited without the
    prior written consent of Eracom Technologies Australia Pty. Ltd.

    File  : ExportKeys.c
 
    Description:
    
    Sample program to demonstrate how to export keys to a file using KMLIB.


    Version Control Info:

    $Revision: 1.1.1.1 $
    $Date: 2011/09/19 11:08:10EDT $
    $Author: Young, Shawn (syoung) $

**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <cryptoki.h>
#include <ctutil.h>

#ifndef _WIN32
#include <unistd.h>
#endif

#include "kmlib.h"
#include "ctextra.h"
#include "integers.h"
#include "genmacro.h"

#ifdef _WIN32
#define strcasecmp _stricmp
#endif

#ifdef __EXIT_FAILURE
#define EXIT_FAILURE __EXIT_FAILURE
#else
#define EXIT_FAILURE 1  /* unixoid */
#endif
#define EXIT_SUCCESS 0

#define SLOT_ID        1
#define USER_PIN       "9999"
#define NUM_COMPONENTS 2
#define BACKUP_FILE    "backup.bin"
#define WRAP_KEY       "secret_key_example"

#define PRE_OPEN_SESSION   0
#define POST_OPEN_SESSION  1
#define POST_CLOSE_SESSION 2

#define EXPECTED_OBJS 1

/**
 *
 * M  A  C  R  O   
 *
 */
 
#define ABORT_MSG(op, errCode)                                              \
    {                                                                       \
         fprintf(stderr,                                                    \
                 "\n%s aborted with error code : %d",                       \
                 op,                                                        \
                (uint32)errCode);                                           \
    }
        
/** 
 * 
 * P R O T O T Y P E 
 * 
 */

static CK_RV GetObjectList(CK_SESSION_HANDLE , CK_OBJECT_HANDLE, CK_OBJECT_HANDLE** ,CK_SIZE* );
static CK_RV GetWrapKey( CK_SESSION_HANDLE , const CK_CHAR*, CK_OBJECT_HANDLE* );
static CK_RV ExportObjsToFile( CK_SESSION_HANDLE , const CK_CHAR* , const char*);
static void  ShowMsg( UICB_MsgType_t, const char* );

/**
 *
 * G  L  O  B  A  L 
 *
 */
 
  
CK_BBOOL ckTrue  = TRUE;
CK_BBOOL ckFalse = FALSE;
     

/**
 *
 * C  A  L  L        B  A  C  K       R  O  U  T  I  N  E 
 *
 */

static void 
ShowMsg( UICB_MsgType_t msgType, 
         const char* pszMessage)
{
    if (msgType == UICB_MT_ERROR)
    {
        fprintf(stderr, "%s", pszMessage);

    }
    else
    {
        printf("%s", pszMessage);

    }
}



/**
 *
 * F  U  N  C  T  I  O  N  S 
 *
 */

 
/**
 * Compile a list of objects to export.
 */
static CK_RV 
GetObjectList(CK_SESSION_HANDLE  hSession,
              CK_OBJECT_HANDLE   hWrapKey,
              CK_OBJECT_HANDLE** ppObjList,
              CK_SIZE*           pObjListSize)
{
    CK_RV rv                    = CKR_GENERAL_ERROR;
    CK_OBJECT_HANDLE hObj       = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE* phObjList = NULL;
    CK_COUNT objectCount        = 0;

    CK_COUNT numObjs            = 0;

    /** Prepare to go through the object list and count wanted objects (excludes wrapper key)  */
    rv = C_FindObjectsInit(hSession, NULL, 0);
    if ( rv != CKR_OK)
        return rv;

    do
    {
        objectCount = 0;
        rv = C_FindObjects(hSession, &hObj, 1, &objectCount);

        if(rv != CKR_OK)
            return rv;

        if (objectCount != 0 && hObj != hWrapKey)
            numObjs++;
    }
    while (objectCount != 0);

    /** make array to hold all objects */
    phObjList = (CK_OBJECT_HANDLE*)malloc(numObjs * sizeof(CK_OBJECT_HANDLE));
        
    if (!phObjList)
        return CKR_HOST_MEMORY;

    /** Prepare to go through the object list and store wanted objects */
    rv = C_FindObjectsInit(hSession, NULL, 0);
    if (rv != CKR_OK)
    {
        free(phObjList);
        return rv;
    }

    numObjs = 0;

    do
    {
        objectCount = 0;
        rv = C_FindObjects(hSession, &hObj, 1, &objectCount);

        if(rv != CKR_OK)
        {
            free(phObjList);
            return rv;
        }

        if (objectCount != 0 && hObj != hWrapKey)
        {
            phObjList[numObjs] = hObj;
            numObjs++;
        }
    }
    while (objectCount != 0);

    *ppObjList = phObjList;
    *pObjListSize = numObjs;

    return rv;
}

/**
 * Get a handle to the specified wrap key.
 */

static CK_RV 
GetWrapKey( CK_SESSION_HANDLE  hSession,
            const CK_CHAR*     pszWrapKey,
            CK_OBJECT_HANDLE*  phObj)
{
    CK_RV rv                      = CKR_GENERAL_ERROR;
    
    static CK_BBOOL bWrap                = FALSE;
    static CK_BBOOL bUnWrap              = FALSE;
    static CK_BBOOL bExport              = FALSE;
    static CK_BBOOL bImport              = FALSE;

    CK_OBJECT_HANDLE* hFoundObjs  = NULL;
    CK_COUNT foundObjsCount       = 0;
    
    
    CK_ATTRIBUTE tpl[] =
    {
        {CKA_WRAP,      &bWrap,       sizeof(CK_BBOOL)},
        {CKA_UNWRAP,    &bUnWrap,     sizeof(CK_BBOOL)},
        {CKA_EXPORT,    &bExport,     sizeof(CK_BBOOL)},
        {CKA_IMPORT,    &bImport,     sizeof(CK_BBOOL)}
    };
    
    CK_SIZE tplCount = sizeof(tpl)/sizeof(CK_ATTRIBUTE);    

    CK_ATTRIBUTE findObjTpl[] =
    {
        {CKA_LABEL,     NULL,       0}
    };

    /** the wrapping key label must not be NULL */
    if (pszWrapKey == NULL)
    {
        return CKR_ARGUMENTS_BAD;
    }

    /** Fill in the label */
    findObjTpl[0].pValue = (void*)pszWrapKey;
    findObjTpl[0].ulValueLen = (CK_ULONG)strlen((char*)pszWrapKey);;

    /** Specify template to search for */
    rv = C_FindObjectsInit(hSession, findObjTpl, NUMITEMS(findObjTpl));
    if (rv != CKR_OK)
    {
        return rv;
    }
    
    hFoundObjs = (CK_OBJECT_HANDLE*)malloc(sizeof(CK_OBJECT_HANDLE) * EXPECTED_OBJS);
    if (!hFoundObjs)
    {
        return CKR_HOST_MEMORY;
    }
    
    /**
     * Here we specify only to find one objects. In real application,
     * we should do a more exhaustive search.
     */
    rv = C_FindObjects(hSession, hFoundObjs, EXPECTED_OBJS, &foundObjsCount);
    if (rv != CKR_OK)
    {
        free(hFoundObjs);
        return rv;
    }

    /** 
     * This sample only expect one wrapper obj. In real application, more 
     * than one objects could be found
     */
    if (foundObjsCount != 1) 
    {
        free(hFoundObjs);
        return CKR_WRAPPING_KEY_HANDLE_INVALID;
    }
    
    /** check that the key has CKA_WRAP=TRUE  and CKA_EXPORT=TRUE */
    rv = C_GetAttributeValue(hSession,
                             *hFoundObjs,
                             tpl,
                             tplCount);

    if (rv != CKR_OK)
    {
        free(hFoundObjs);
        return rv;
    }

    if (!bWrap && !bExport)
    {
        free(hFoundObjs);
        return CKR_WRAPPING_KEY_HANDLE_INVALID;
    }

    *phObj        = *hFoundObjs;

    free(hFoundObjs);
    return rv;
}


/**
 * Export objects to file.
 */
static CK_RV 
ExportObjsToFile( CK_SESSION_HANDLE hSession,
                  const CK_CHAR*    pszWrapKeyLabel,
                  const char*       pszFileName)
{
    CK_RV rv                    = CKR_GENERAL_ERROR;
    CK_OBJECT_HANDLE hWrapKey   = CK_INVALID_HANDLE;

    CK_OBJECT_HANDLE* pObjList = NULL;
    CK_COUNT objListSize       = 0;

    /** check inputs */
    if (pszWrapKeyLabel == NULL)
    {
        fprintf(stderr, "No wrapping key label specified.\n");
        return CKR_ARGUMENTS_BAD;
    }

    if (pszFileName == NULL)
    {
        fprintf(stderr, "No export file specified.\n");
        return CKR_ARGUMENTS_BAD;
    }

    /**
     * Get a handle to the wrapping key.
     */
    rv = GetWrapKey(hSession,
                    pszWrapKeyLabel,
                    &hWrapKey);

    if (rv != CKR_OK) return rv;

    /**
     * Get a list of object handles to export. If pszLabel is not NULL, export
     * a single object, otherwise export all objects that can be exported.
     */
    rv = GetObjectList(hSession, hWrapKey, &pObjList, &objListSize);
    if (rv != CKR_OK)
    {
        if (pObjList != NULL)
            free(pObjList);
        
        return rv;
    }

    /**
     * Note that actual objects that get exported may be less than the number
     * indicated in the list. The HSM will only export objects which are marked
     * CKA_EXPORTABLE or CKA_EXTRACTABLE.
     */
    rv = KM_ExportToFile(hSession,
                         pObjList,
                         objListSize,
                         hWrapKey,
                         pszFileName);

    free(pObjList);
    return rv;
}

/**
 *
 * M  A  I  N  
 *
 */


/**
 * @brief     This sample uses the KMLIB to backup tokens in
 *            slot 1. Note that only token with attributes CKA_EXPORTABLE
 *            can be backedup. 
 * @note      It shall use wrapper key "secret_key_example" from Sample-1 as
 *            export key.
 */
int 
main(int argc, char **argv)
{
	
    CK_RV rv                     = CKR_GENERAL_ERROR;
    CK_SESSION_HANDLE hSession   = CK_INVALID_HANDLE;

    KM_Callbacks_t km_callbacks;

    FILE *pFile = NULL;
     
    ARG_USED(argc);
    ARG_USED(argv);

    pFile = fopen(BACKUP_FILE,"w+");
    if (pFile == NULL)
    {
        ABORT_MSG("Unable to open backup file pointer", 0);
        exit(EXIT_FAILURE);
    }

    /** 
     * Register KMLIB call back - use default call back
     * 
     * @note   Some of the APIs uses call back. See documenatation
     *         for full details. 
     * @see    kmucallbacks.h
     */
    memset(&km_callbacks, 0, sizeof(km_callbacks));
    km_callbacks.showMsg            = ShowMsg;
    
  
    /** Register callback */
    #undef  OP
    #define OP "KM_SetCallbacks"
    
    rv = KM_SetCallbacks(&km_callbacks);
    if (rv != CKR_OK) return rv;
  
    /** Intialize crypto */
    #undef  OP
    #define OP "C_Initialize"
    
    rv = C_Initialize(NULL);
    if (rv != CKR_OK) 
    {
        ABORT_MSG(OP, rv)
        exit(EXIT_FAILURE);
    }
                   
    
    /** Open session */   
    #undef  OP
    #define OP "C_OpenSession"
    
    rv = C_OpenSession( SLOT_ID, 
                        CKF_RW_SESSION, 
                        NULL, 
                        NULL, 
                        &hSession);
    if (rv != CKR_OK) 
    {
        ABORT_MSG(OP, rv)
        goto end;
    }

    /** User login */   
    #undef  OP
    #define OP "C_Login"

    rv = C_Login( hSession, 
                  CKU_USER, 
                  (CK_CHAR*)USER_PIN, 
                  strlen(USER_PIN));
    if (rv != CKR_OK) 
    {
        ABORT_MSG(OP, rv)
        goto end;
    }

    /** Export token */
    #undef  OP
    #define OP "ExportToFile"
    
    rv = ExportObjsToFile( hSession,
                           (CK_CHAR*)WRAP_KEY,
                           BACKUP_FILE);
    if (rv != CKR_OK) 
    {
        ABORT_MSG(OP, rv)
        goto end;
    }
     
        
    /** User logout */   
    #undef  OP
    #define OP "C_Logout"

    rv = C_Logout(hSession);
    if (rv != CKR_OK) 
    {
        ABORT_MSG(OP, rv)
        goto end;
    }

    /** Close session */
    #undef  OP
    #define OP "C_CloseSession"
    
    rv = C_CloseSession(hSession);
    if (rv != CKR_OK) 
    {
        ABORT_MSG(OP, rv)
        goto end;
    }
    
    /** Finalize session */
    #undef  OP
    #define OP "C_Finalize"
    
    rv = C_Finalize(NULL);
    if (rv != CKR_OK) 
    {
        ABORT_MSG("Unable to finalize session", rv);
        exit(EXIT_FAILURE);
    }
    
end:
    fclose(pFile);

    if (rv != CKR_OK) C_Finalize(NULL);

    return(EXIT_SUCCESS);   
}
