/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: WrapUnwrapKey.c
 * $Date: 2014/06/05 15:33:23EDT $
 */
/**
 * @file
 *     Sample program to demonstrate how to wrap and unwrap a key.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cryptoki.h"
#include "ctvdef.h"
#include "ctutil.h"
#include "genmacro.h"

/** 
 * This macro is used to check the return value of a function and print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr,                                     \
                "%s - 0x%lx (%s)\n",                         \
                 string,                                    \
                 rv,                                        \
                 strError(rv));                             \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Generate a secret key.
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param phKey
 *  Location to store the handle of the new secret key.
 */
static CK_RV generateKey(CK_SESSION_HANDLE hSession,
                         CK_OBJECT_HANDLE* phKey);

/**
 * Wraps a secret key with a specified wrapping key.
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param hWrappingKey
 *  Handle to the wrapping key.
 *
 * @param hKey
 *  Handle to the key to be wrapped.
 *
 * @param pWrappedKey
 *  Location to store the wrapped key.
 *
 * @param pWrappedKeyLen
 *  Location to store the length of the wrapped key.
 */
static CK_RV wrapKey(CK_SESSION_HANDLE hSession,
                     CK_OBJECT_HANDLE hWrapKey,
                     CK_OBJECT_HANDLE hKey,
                     CK_BYTE** ppWrappedKey,
                     CK_ULONG* pWrappedKeyLen);

/**
 * Unwraps a secret key with a specified unwrapping key.
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param hUnwrapKey
 *  Handle to the wrapping key.
 *
 * @param pWrappedKey
 *  The wrapped key.
 *
 * @param pWrappedKeyLen
 *  The length of the wrapped key.
 *
 * @param phKey
 *  Location to store the handle of the unwrapped key.
 */
static CK_RV unwrapKey(CK_SESSION_HANDLE hSession,
                       CK_OBJECT_HANDLE hUnwrapKey,
                       CK_BYTE* pWrappedKey,
                       CK_ULONG wrappedKeyLen,
                       CK_OBJECT_HANDLE* phKey);


/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;
    CK_SLOT_ID slotId = 0;

    CK_OBJECT_HANDLE hWrappingKey = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hKey = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hUnwrappedKey = CK_INVALID_HANDLE;

    CK_BYTE* pWrappedKey = NULL;
    CK_ULONG wrappedKeyLen = 0;

    char ch;

    CK_NUMERIC i = 0;

    ARG_USED(argc);
    ARG_USED(argv);

    /*
     * Start cryptoki.
     */
    rv = C_Initialize(NULL);
    CHECK_CK_RV_GOTO(rv, "Could not initialize cryptoki", end);

    rv = C_OpenSession(slotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    CHECK_CK_RV_GOTO(rv, "Could not open session", end);

    printf("\nGenerating test keys\n");

    /*
     * Generate a wrapping key
     */
    rv = generateKey(hSession, &hWrappingKey);
    CHECK_CK_RV_GOTO(rv, "Could not generate wrapping key", end);

    /*
     * Generate wrappee key
     */
    rv = generateKey(hSession, &hKey);
    CHECK_CK_RV_GOTO(rv, "Could not generate wrappee key", end);

    /*
     * Do the wrap.
     */
    printf("Performing the wrap operation... ");

    rv = wrapKey(hSession, hWrappingKey, hKey, &pWrappedKey, &wrappedKeyLen);
    CHECK_CK_RV_GOTO(rv, "Could not wrap key", end);

    printf(" done!\n");

    printf("Wrapped key (hex) : ");
    for (i = 0; i < wrappedKeyLen; ++i)
    {
        printf("%x", pWrappedKey[i]);
    }
    printf("\n");

    /*
     * Do the unwrap
     */
    printf("Press <enter> to unwrap ...");
    scanf("%c", &ch);

    printf("Performing the unwrap operation... ");

    rv = unwrapKey(hSession, hWrappingKey, pWrappedKey, wrappedKeyLen, &hUnwrappedKey);
    CHECK_CK_RV_GOTO(rv, "Could not unwrap key", end);

    printf(" done!\n");

end:
    /*
     * Cleaning up.
     */
    if (pWrappedKey != NULL)
    {
        free(pWrappedKey);
        pWrappedKey = NULL;
    }

    if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

    C_Finalize(NULL);

    return rv;
}


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV generateKey(CK_SESSION_HANDLE hSession,
                         CK_OBJECT_HANDLE* phKey)
{
    CK_RV rv = CKR_OK;

    CK_OBJECT_HANDLE hKey = CK_INVALID_HANDLE;

    CK_MECHANISM mech = {CKM_DES3_KEY_GEN, NULL, 0};

    /*
     * Attribute template for the secret key.
     */
    static CK_BBOOL ckFalse = FALSE;
    static CK_BBOOL ckTrue = TRUE;
    CK_ATTRIBUTE tpl[] = 
    {
        {CKA_TOKEN,         &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_WRAP,          &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_UNWRAP,        &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_EXTRACTABLE,   &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_SENSITIVE,     &ckTrue,    sizeof(CK_BBOOL)},
    };
    CK_COUNT tplSize = sizeof(tpl)/sizeof(CK_ATTRIBUTE);

    /*
     * Generate the secret key
     */
    rv = C_GenerateKey(hSession, &mech, tpl, tplSize, &hKey);
    if (rv == CKR_OK)
    {
        /* copy results to output parameters */
        *phKey = hKey;
    }
    else
    {
        fprintf(stderr,
                "Could not generate secret key - 0x%lx (%s)",
                rv,
                strError(rv));
    }
    
    return rv;
}

static CK_RV wrapKey(CK_SESSION_HANDLE hSession,
                     CK_OBJECT_HANDLE hWrapKey,
                     CK_OBJECT_HANDLE hKey,
                     CK_BYTE** ppWrappedKey,
                     CK_ULONG* pWrappedKeyLen)
{
    CK_RV rv = CKR_OK;

    CK_MECHANISM mech = {CKM_DES3_ECB, NULL, 0};

    CK_ULONG wrappedKeyLen = 0;

    /* check arguments */
    if ((hWrapKey == CK_INVALID_HANDLE) || (hKey == CK_INVALID_HANDLE))
    {
        return CKR_ARGUMENTS_BAD;
    }

    /*
     * First, do a length prediction so we know roughly how much memory to
     * allocate.
     */
    rv = C_WrapKey(hSession, &mech, hWrapKey, hKey, NULL, &wrappedKeyLen);
    if (rv != CKR_OK) return rv;

    *ppWrappedKey = (CK_BYTE*)malloc(wrappedKeyLen);
    if (*ppWrappedKey == NULL) return CKR_HOST_MEMORY;

    /*
     * Now that we have our buffer malloced up, we can do the proper wrap
     * operation.
     */
    rv = C_WrapKey(hSession, &mech, hWrapKey, hKey, *ppWrappedKey, &wrappedKeyLen);
    if (rv == CKR_OK)
    {
        *pWrappedKeyLen = wrappedKeyLen;
    }
    else
    {
        *pWrappedKeyLen = 0;
    }

    return rv;
}

static CK_RV unwrapKey(CK_SESSION_HANDLE hSession,
                       CK_OBJECT_HANDLE hUnwrapKey,
                       CK_BYTE* pWrappedKey,
                       CK_ULONG wrappedKeyLen,
                       CK_OBJECT_HANDLE* phKey)
{
    CK_RV rv = CKR_OK;

    CK_MECHANISM mech = {CKM_DES3_ECB, NULL, 0};

    static CK_BBOOL ckTrue = TRUE;
    static CK_BBOOL ckFalse = FALSE;
    static CK_KEY_TYPE keyType = CKK_DES3;

    /*
     * Attribute template for the unwrapped key.
     */
    CK_ATTRIBUTE tpl[] = 
    {
        {CKA_TOKEN,         &ckFalse,    sizeof(CK_BBOOL)},
        {CKA_WRAP,          &ckFalse,    sizeof(CK_BBOOL)},
        {CKA_UNWRAP,        &ckFalse,    sizeof(CK_BBOOL)},
        {CKA_EXTRACTABLE,   &ckFalse,    sizeof(CK_BBOOL)},
        {CKA_SENSITIVE,     &ckTrue,     sizeof(CK_BBOOL)},
        {CKA_KEY_TYPE,      &keyType,    sizeof(CK_KEY_TYPE)}
    };
    CK_COUNT tplSize = sizeof(tpl)/sizeof(CK_ATTRIBUTE);


    /* check arguments */
    if ((hUnwrapKey == CK_INVALID_HANDLE) || (pWrappedKey == NULL))
    {
        return CKR_ARGUMENTS_BAD;
    }

    rv = C_UnwrapKey(hSession,
                     &mech,
                     hUnwrapKey,
                     pWrappedKey,
                     wrappedKeyLen,
                     tpl,
                     tplSize,
                     phKey);

    return rv;
}
