/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: EccDemo.c
 * $Date: 2014/06/05 15:33:16EDT $
 */
/**
 * @file
 *       Sample program to demonstrate generation of an EC key pair, signing
 *       using an EC private key and verifying using an EC public key.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cryptoki.h"
#include "ctutil.h"

/**
 * Macro used to check a given condition. If the condition is not true, print
 * an error message exit.
 */
#define CHECK_COND(COND)                                             \
    if (!(COND))                                                     \
    {                                                                \
        fprintf(stderr, "%s(%d): Condition '%s' does not hold\n",    \
                __FILE__, __LINE__, #COND);                          \
        exit(EXIT_FAILURE);                                          \
    }

/**
 * Macro called after a P11 function call to check the return value. If the
 * return value != CKR_OK print an error and exit.
 */
#define CHECK_P11_ERROR(RV)                                          \
    if (rv != CKR_OK)                                                \
    {                                                                \
        fprintf(stderr, "%s(%d): PKCS#11 Failure 0x%08lx\n",          \
                __FILE__, __LINE__, RV);                             \
        exit(EXIT_FAILURE);                                          \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

static void generateEccKeyPair(CK_SESSION_HANDLE hSession,
                               const char* label,
                               CK_OBJECT_HANDLE* phPubKey,
                               CK_OBJECT_HANDLE* phPriKey);

static void findEccPrivateKey(CK_SESSION_HANDLE hSession,
                               const char* label,
                               CK_OBJECT_HANDLE* phKey);

static void findEccPublicKey(CK_SESSION_HANDLE hSession,
                             const char* label,
                             CK_OBJECT_HANDLE* phKey);

static void sha1HashData(CK_SESSION_HANDLE hSession,
                         CK_BYTE* pData,
                         CK_SIZE dataLen,
                         CK_BYTE** ppHash,
                         CK_SIZE* pHashLen);

static void eccSign(CK_SESSION_HANDLE hSession,
                    CK_OBJECT_HANDLE hPriKey,
                    CK_BYTE* pHash,
                    CK_SIZE hashLen,
                    CK_BYTE** ppSign,
                    CK_SIZE* pSignLen);

static void eccHashSign(CK_SESSION_HANDLE hSession,
                        CK_OBJECT_HANDLE hPriKey,
                        CK_BYTE* pData,
                        CK_SIZE dataLen,
                        CK_BYTE** ppSign,
                        CK_SIZE* pSignLen);

static void eccVerify(CK_SESSION_HANDLE hSession,
                      CK_OBJECT_HANDLE hPubKey,
                      CK_BYTE* pHash,
                      CK_SIZE hashLen,
                      CK_BYTE* pSign,
                      CK_SIZE sign1Len);

static void eccHashVerify(CK_SESSION_HANDLE hSession,
                          CK_OBJECT_HANDLE hPubKey,
                          CK_BYTE* pData,
                          CK_SIZE dataLen,
                          CK_BYTE* pSign,
                          CK_SIZE sign1Len);

static void dumpMem(const void* mem, unsigned int len);


/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    CK_SLOT_ID slotId = 3;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;

    CK_OBJECT_HANDLE hPriKey = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hPubKey = CK_INVALID_HANDLE;

    // CK_BYTE data[] = "This sentence is 36 characters long.";
    CK_BYTE data[] = {'a', 'b', 'c'};
    CK_SIZE dataLen = 0;

    CK_BYTE* pHash = NULL;
    CK_SIZE hashLen = 0;

    CK_BYTE* pSign1 = NULL;
    CK_SIZE sign1Len = 0;

    CK_BYTE* pSign2 = NULL;
    CK_SIZE sign2Len = 0;

    if (argc == 1 ||
        (argc == 3 && strcmp(argv[1], "gen") != 0))
    {
        printf("Usage:\n\nGenerate keypair:\n%s gen <keyLabel>\n\n"
               "Sign/Verify:\n%s <keyLabel>\n", argv[0], argv[0]);
        exit(EXIT_FAILURE);
    }

    dataLen = strlen((char*)data);

    /*
     * Start a new P11 application and open a session.
     */

    rv = C_Initialize(NULL);
    CHECK_P11_ERROR(rv);

    rv = C_OpenSession(slotId,
                       CKF_SERIAL_SESSION | CKF_RW_SESSION,
                       NULL,
                       NULL,
                       &hSession);
    CHECK_P11_ERROR(rv);

    /*
     * We either generate the key pair or do the sign/verify operations.
     */

    if (argc == 3)
    {
        /* Generate key pair and exit. */
        generateEccKeyPair(hSession, argv[2], &hPubKey, &hPriKey);

        return CKR_OK;
    }


    /*
     * Doing the sign/verify operations.
     */

    findEccPrivateKey(hSession, argv[1], &hPriKey);
    findEccPublicKey(hSession, argv[1], &hPubKey);

    mlsPCKS11_GetECDSAPubkey(hSession, hPubKey);

    /* Hash the data */
    sha1HashData(hSession, data, dataLen, &pHash, &hashLen);

    /* Dump the hash result. */
    printf("Hash is:\n");
    dumpMem(pHash, hashLen);
    printf("\n");

    /* Sign the hash result. */
    eccSign(hSession, hPriKey, pHash, hashLen, &pSign1, &sign1Len);

    /* Hash/sign the data in a single operation. */
    eccHashSign(hSession, hPriKey, data, dataLen, &pSign2, &sign2Len);

    /* Dump both signatures. Ensure they are the same. */
    printf("Signature of the hash is:\n");
    dumpMem(pSign1, sign1Len);
    printf("\nHashed signature of the data is:\n");
    dumpMem(pSign2, sign2Len);
    printf("\n");

    /* Verify the signatures. */
    printf("Checking signature of hash             : ");
    eccVerify(hSession, hPubKey, pHash, hashLen, pSign1, sign1Len);

    printf("Checking hashed signature of data      : ");
    eccHashVerify(hSession, hPubKey, data, dataLen, pSign2, sign2Len);

    printf("Cross Checking signature of hash       : ");
    eccHashVerify(hSession, hPubKey, data, dataLen, pSign1, sign1Len);

    printf("Cross Checking hashed signature of data: ");
    eccVerify(hSession, hPubKey, pHash, hashLen, pSign2, sign2Len);

    /* Free the buffers. */
    if (pHash != NULL) free(pHash);
    if (pSign1 != NULL) free(pSign1);
    if (pSign2 != NULL) free(pSign2);

    rv = C_CloseSession(hSession);
    CHECK_P11_ERROR(rv);

    rv = C_Finalize(NULL);
    CHECK_P11_ERROR(rv);

    return rv;
}

/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
void dump_hex(char *string, CK_BYTE *array, unsigned int len)
{
    unsigned int i;
    printf("%s\r\n", string);
    for (i = 0; i < len; i++)
    {
        printf("0x%02X, ", array[i]);
    }
    printf("\r\n");
}

void sum_print(char *string, CK_BYTE *array, unsigned int len)
{
    unsigned int i;
    unsigned int sum = 0;
    for (i = 0; i < len; i++)
    {
        if ((i == 0) && (i % 8 == 0))
        {
            printf("\r\n\t\t");
        }
        sum += array[i];
    }
    printf("%s\r\n\tvalue=%d\r\n\tsize=%d\r\n", string, sum, len);
}

void mlsPCKS11_GetECDSAPubkey(CK_SESSION_HANDLE hSession, CK_OBJECT_HANDLE hPublicKey)
{
    CK_BYTE *params = NULL;
    CK_ULONG params_len = 0;

    CK_BYTE *point = NULL;
    CK_ULONG point_len = 0;

    CK_ATTRIBUTE* pAttr = NULL;

    CK_ATTRIBUTE publicKeyGetTpl[] =
    {
        { CKA_ECDSA_PARAMS, params, 0 },
        { CKA_EC_POINT, point, 0 },
    };
    CK_COUNT publicKeyGetTplSize = sizeof(publicKeyGetTpl) / sizeof(CK_ATTRIBUTE);

    C_GetAttributeValue(hSession, hPublicKey, publicKeyGetTpl, publicKeyGetTplSize);

    pAttr = FindAttribute(CKA_ECDSA_PARAMS, publicKeyGetTpl, publicKeyGetTplSize);
    params_len = pAttr->valueLen;
    params = malloc(pAttr->valueLen);
    pAttr->pValue = params;

    pAttr = FindAttribute(CKA_EC_POINT, publicKeyGetTpl, publicKeyGetTplSize);
    point_len = pAttr->valueLen;
    point = malloc(pAttr->valueLen);
    pAttr->pValue = point;

    C_GetAttributeValue(hSession, hPublicKey, publicKeyGetTpl, publicKeyGetTplSize);
    sum_print("params: ", params, params_len);
    sum_print("point : ", point, point_len);
    dump_hex("param dump:", params, params_len);
    dump_hex("Point dump:", point, point_len);
}

static void generateEccKeyPair(CK_SESSION_HANDLE hSession,
                               const char* label,
                               CK_OBJECT_HANDLE* phPubKey,
                               CK_OBJECT_HANDLE* phPriKey)
{
    CK_RV rv = CKR_OK;

    static CK_BBOOL ckTrue = TRUE;
    static CK_BBOOL ckFalse = FALSE;
    static CK_OBJECT_CLASS pubClass = CKO_PUBLIC_KEY;
    static CK_OBJECT_CLASS priClass = CKO_PRIVATE_KEY;
    static CK_KEY_TYPE keyType = CKK_EC;
    CK_ATTRIBUTE pubAttr[] = 
    {
        {CKA_LABEL,          NULL,       0},   /* We will fill this in later. */
        {CKA_EC_PARAMS,      NULL,       0},   /* We will fill this in later. */
        {CKA_CLASS,          &pubClass,  sizeof(pubClass)},
        {CKA_KEY_TYPE,       &keyType,   sizeof(keyType)},
        {CKA_TOKEN,          &ckTrue,    sizeof(ckTrue)},
        {CKA_SENSITIVE,      &ckFalse,   sizeof(ckFalse)},
        {CKA_VERIFY,         &ckTrue,    sizeof(ckTrue)}
    };
    CK_SIZE pubAttrCount = sizeof(pubAttr)/sizeof(CK_ATTRIBUTE);

    CK_ATTRIBUTE priAttr[] =
    {
        {CKA_LABEL,         NULL,       0},       /* We will fill this in later. */
        {CKA_CLASS,         &priClass,  sizeof(priClass)},
        {CKA_KEY_TYPE,      &keyType,   sizeof(keyType)},
        {CKA_TOKEN,         &ckTrue,    sizeof(ckTrue)},
        {CKA_SENSITIVE,     &ckFalse,   sizeof(ckFalse)},
        {CKA_SIGN,          &ckTrue,    sizeof(ckTrue)}
    };
    CK_SIZE priAttrCount = sizeof(priAttr)/sizeof(CK_ATTRIBUTE);

    CK_BYTE* pEcParam = NULL;
    CK_SIZE ecParamLen = 0;

    CK_OBJECT_HANDLE hPubKey = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hPriKey = CK_INVALID_HANDLE;

    /*
     * Name of the curve to generate. Possible values are:
     *  c2tnb191v1
     *  c2tnb191v1e
     *  P-192
     *  prime192v1
     *  secp192r1
     */
    const char* psCurveName = "secp256r1";
    CK_MECHANISM mech = {CKM_EC_KEY_PAIR_GEN, NULL, 0};


    /* Get the encoded domain parameters for named curve (needs ctutil library) */
    /* attempt to find Domain Param object to get parameters from */
    pubAttr[1].pValue = NULL;
    rv = CT_GetECCDomainParameters(hSession, &pubAttr[1], psCurveName);
    CHECK_P11_ERROR(rv);

    ecParamLen = pubAttr[1].valueLen;
    pEcParam = (CK_BYTE*)malloc(ecParamLen);
    CHECK_COND(pEcParam != NULL);

    pubAttr[1].pValue = pEcParam;
    rv = CT_GetECCDomainParameters(hSession, &pubAttr[1], psCurveName);
    CHECK_P11_ERROR(rv);

    /* finalise the public key template */
    pubAttr[0].pValue = (CK_VOID_PTR)label;
    pubAttr[0].valueLen = strlen(label);

    /* finalise the private key template */
    priAttr[0].pValue = (CK_VOID_PTR)label;
    priAttr[0].valueLen = strlen(label);

    rv = C_GenerateKeyPair(hSession, &mech,
                           pubAttr, pubAttrCount,
                           priAttr, priAttrCount,
                           &hPubKey, &hPriKey);
    CHECK_P11_ERROR(rv);

    if (pEcParam != NULL)
    {
        free(pEcParam);
        pEcParam = NULL;
    }

    *phPubKey = hPubKey;
    *phPriKey = hPriKey;

    mlsPCKS11_GetECDSAPubkey(hSession, hPubKey);
}


static void findEccPrivateKey(CK_SESSION_HANDLE hSession,
                              const char* label,
                              CK_OBJECT_HANDLE* phKey)
{
    CK_RV rv = CKR_OK;

    static CK_OBJECT_CLASS keyClass = CKO_PRIVATE_KEY;
    static CK_KEY_TYPE keyType = CKK_EC;

    CK_ATTRIBUTE findAttr[] =
    {
        {CKA_LABEL,         NULL,       0}, /* Must be first */
        {CKA_CLASS,         &keyClass,  sizeof(keyClass)},
        {CKA_KEY_TYPE,      &keyType,   sizeof(keyType)}
    };
    CK_COUNT findAttrCount = NUMITEMS(findAttr);

    CK_COUNT keyCount = 0;

    findAttr[0].pValue = (CK_VOID_PTR)label;
    findAttr[0].valueLen = strlen(label);

    rv = C_FindObjectsInit(hSession, findAttr, findAttrCount);
    CHECK_P11_ERROR(rv);

    rv = C_FindObjects(hSession, phKey, 1, &keyCount);
    CHECK_P11_ERROR(rv);
    CHECK_COND(keyCount >= 1);

    rv = C_FindObjectsFinal(hSession);
    CHECK_P11_ERROR(rv);
}

static void findEccPublicKey(CK_SESSION_HANDLE hSession,
                             const char* label,
                             CK_OBJECT_HANDLE* phKey)
{
    CK_RV rv = CKR_OK;

    static CK_OBJECT_CLASS keyClass = CKO_PUBLIC_KEY;
    static CK_KEY_TYPE keyType = CKK_EC;

    CK_ATTRIBUTE findAttr[] =
    {
        {CKA_LABEL,     NULL,       0}, /* Must be first */
        {CKA_CLASS,     &keyClass,  sizeof(keyClass)},
        {CKA_KEY_TYPE,  &keyType,   sizeof(keyType)},
    };
    CK_COUNT findAttrCount = NUMITEMS(findAttr);

    CK_COUNT keyCount = 0;

    findAttr[0].pValue = (CK_VOID_PTR)label;
    findAttr[0].valueLen = strlen(label);

    rv = C_FindObjectsInit(hSession, findAttr, findAttrCount);
    CHECK_P11_ERROR(rv);

    rv = C_FindObjects(hSession, phKey, 1, &keyCount);
    CHECK_P11_ERROR(rv);
    printf("rv=%d\r\n", rv);
    printf("keyCount=%d\r\n", keyCount);
    CHECK_COND(keyCount >= 1);

    rv = C_FindObjectsFinal(hSession);
    CHECK_P11_ERROR(rv);
}

static void sha1HashData(CK_SESSION_HANDLE hSession,
                         CK_BYTE* pData,
                         CK_SIZE dataLen,
                         CK_BYTE** ppHash,
                         CK_SIZE* pHashLen)
{
    CK_RV rv = CKR_OK;

    CK_MECHANISM mech = {CKM_SHA256, NULL, 0};

    CK_BYTE *pHash = NULL;
    CK_SIZE hashLen = 0;

    rv = C_DigestInit(hSession, &mech);
    CHECK_P11_ERROR(rv);

    rv = C_Digest(hSession, pData, dataLen, NULL, &hashLen);
    CHECK_P11_ERROR(rv);

    pHash = (CK_BYTE *)malloc(hashLen);
    CHECK_COND(pHash != NULL);

    rv = C_Digest(hSession, pData, dataLen, pHash, &hashLen);
    CHECK_P11_ERROR(rv);

    *ppHash = pHash;
    *pHashLen = hashLen;
}

static void eccSign(CK_SESSION_HANDLE hSession,
                    CK_OBJECT_HANDLE hPriKey,
                    CK_BYTE* pHash,
                    CK_SIZE hashLen,
                    CK_BYTE** ppSign,
                    CK_SIZE* pSignLen)
{
    CK_RV rv = CKR_OK;
    CK_MECHANISM mech = {CKM_ECDSA, NULL, 0};
    CK_BYTE *pSign = NULL;
    CK_SIZE signLen = 0;

    rv = C_SignInit(hSession, &mech, hPriKey);
    CHECK_P11_ERROR(rv);

    rv = C_Sign(hSession, pHash, hashLen, NULL, &signLen);
    CHECK_P11_ERROR(rv);

    pSign = (CK_BYTE *)malloc(signLen);
    CHECK_COND(pSign != NULL);

    rv = C_Sign(hSession, pHash, hashLen, pSign, &signLen);
    CHECK_P11_ERROR(rv);

    *ppSign = pSign;
    *pSignLen = signLen;
}

static void eccHashSign(CK_SESSION_HANDLE hSession,
                        CK_OBJECT_HANDLE hPriKey,
                        CK_BYTE* pData,
                        CK_SIZE dataLen,
                        CK_BYTE** ppSign,
                        CK_SIZE* pSignLen)
{
    CK_RV rv = CKR_OK;

    CK_MECHANISM mech = {CKM_ECDSA_SHA1, NULL, 0};

    CK_BYTE *pSign = NULL;
    CK_SIZE signLen = 0;

    rv = C_SignInit(hSession, &mech, hPriKey);
    CHECK_P11_ERROR(rv);

    rv = C_Sign(hSession, pData, dataLen, NULL, &signLen);
    CHECK_P11_ERROR(rv);

    pSign = (CK_BYTE *)malloc(signLen);
    CHECK_COND(pSign != NULL);

    rv = C_Sign(hSession, pData, dataLen, pSign, &signLen);
    CHECK_P11_ERROR(rv);

    *ppSign = pSign;
    *pSignLen = signLen;
}

static void eccVerify(CK_SESSION_HANDLE hSession,
                      CK_OBJECT_HANDLE hPubKey,
                      CK_BYTE* pHash,
                      CK_SIZE hashLen,
                      CK_BYTE* pSign,
                      CK_SIZE signLen)
{
    CK_RV rv;
    CK_MECHANISM mech = {CKM_ECDSA, NULL, 0};

    rv = C_VerifyInit(hSession, &mech, hPubKey);
    CHECK_P11_ERROR(rv);

    rv = C_Verify(hSession, pHash, hashLen, pSign, signLen);
    if (rv == CKR_SIGNATURE_INVALID)
    {
        printf("Signature invalid. Signature was:\n");
        dumpMem(pSign, signLen);
    }
    else if (rv == CKR_OK)
    {
        printf("Valid\n");
    }
    else
    {
        CHECK_P11_ERROR(rv);
    }

}

static void eccHashVerify(CK_SESSION_HANDLE hSession,
                          CK_OBJECT_HANDLE hPubKey,
                          CK_BYTE* pData,
                          CK_SIZE dataLen,
                          CK_BYTE* pSign,
                          CK_SIZE signLen)
{
    CK_RV rv = CKR_OK;
    CK_MECHANISM mech = {CKM_ECDSA_SHA1, NULL, 0};

    rv = C_VerifyInit(hSession, &mech, hPubKey);
    CHECK_P11_ERROR(rv);

    rv = C_Verify(hSession, pData, dataLen, pSign, signLen);
    if (rv == CKR_SIGNATURE_INVALID)
    {
        printf("Signature invalid. Signature was:\n");
        dumpMem(pSign, signLen);
    }
    else if (rv == CKR_OK)
    {
        printf("Valid\n");
    }
    else
    {
        CHECK_P11_ERROR(rv);
    }
}

static void dumpMem(const void* mem, unsigned int len)
{
    unsigned int i = 0;

    for (i = 0; i < len; i += 16)
    {
        unsigned int j = 0;

        for (j = 0; j != 16 && i + j < len; ++j)
        {
            printf("0x%02X, ", ((unsigned char*)mem)[i+j]);
        }

        printf("\n");
    }
}
