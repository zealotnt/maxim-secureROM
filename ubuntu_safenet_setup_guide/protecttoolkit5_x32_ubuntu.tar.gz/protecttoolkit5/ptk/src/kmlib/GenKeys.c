/**************************************************************************

    Copyright (C) 2004 Eracom Technologies Australia Pty. Ltd.
    All Rights Reserved 

    Use of this file for any purpose whatsoever is prohibited without the
    prior written consent of Eracom Technologies Australia Pty. Ltd.

    File  : GenKeys.c
 
    Description:
    
    Sample program to demonstrate how to generate keys using KMLIB.


    Version Control Info:

    $Revision: 1.1 $
    $Date: 2009/01/27 10:02:00EST $
    $Author: Sorokine, Joseph (jsorokine) $

**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <cryptoki.h>

#ifndef _WIN32
#include <unistd.h>
#endif

#include "kmlib.h"
#include "ctextra.h"
#include "integers.h"
#include "genmacro.h"


#ifdef _WIN32
#define strcasecmp _stricmp
#endif

#ifdef __EXIT_FAILURE
#define EXIT_FAILURE __EXIT_FAILURE
#else
#define EXIT_FAILURE 1  /* unixoid */
#endif
#define EXIT_SUCCESS 0


#define SO_PIN         "9999"
#define USER_PIN       "9999"
#define SLOT_ID        1
#define NUM_COMPONENTS 2

#define PRE_OPEN_SESSION   0
#define POST_OPEN_SESSION  1
#define POST_CLOSE_SESSION 2


/**
 *
 * M  A  C  R  O   
 *
 */
#define ABORT_MSG(op, errCode)                                              \
    {                                                                       \
         fprintf(stderr,                                                    \
                 "\n%s aborted with error code : %d",                      \
                 op,                                                        \
                (uint32)errCode);                                           \
    }


/** 
 * 
 * P R O T O T Y P E S
 * 
 */

static CK_RV PromptString(const char*, char*,CK_ULONG* );
static void ShowMsg( UICB_MsgType_t, const char*);
static CK_RV createDES3( CK_SESSION_HANDLE,CK_CHAR_PTR,CK_OBJECT_HANDLE* );
static CK_RV createRSA( CK_SESSION_HANDLE  , CK_CHAR_PTR , CK_OBJECT_HANDLE * , CK_OBJECT_HANDLE * );

/**
 *
 * G  L  O  B  A  L S
 *
 */
 
  
CK_BBOOL ckTrue  = TRUE;
CK_BBOOL ckFalse = FALSE;
     
/** 
 * Attribute template for the secret DES3 key.
 */
 
static CK_CHAR secLabel [] = "secret_key_example";
CK_ATTRIBUTE secKeyTpl[] = 
{
        {CKA_LABEL,         secLabel,      sizeof(secLabel)},
        {CKA_TOKEN,         &ckTrue,       sizeof(CK_BBOOL)},
        {CKA_ENCRYPT,       &ckFalse,      sizeof(CK_BBOOL)},
        {CKA_DECRYPT,       &ckFalse,      sizeof(CK_BBOOL)},
        {CKA_SIGN,          &ckFalse,      sizeof(CK_BBOOL)},
        {CKA_VERIFY,        &ckFalse,      sizeof(CK_BBOOL)},
        {CKA_EXPORT,        &ckTrue,       sizeof(CK_BBOOL)},
        {CKA_WRAP,          &ckTrue,       sizeof(CK_BBOOL)},
        {CKA_UNWRAP,        &ckTrue,       sizeof(CK_BBOOL)},
        {CKA_EXPORTABLE,    &ckFalse,      sizeof(CK_BBOOL)},
        {CKA_EXTRACTABLE,   &ckFalse,      sizeof(CK_BBOOL)},
        {CKA_MODIFIABLE,    &ckFalse,      sizeof(CK_BBOOL)},
        {CKA_SENSITIVE,     &ckTrue,       sizeof(CK_BBOOL)},
        {CKA_DERIVE,        &ckFalse,      sizeof(CK_BBOOL)}
};
CK_COUNT secKeyTplSize = sizeof(secKeyTpl)/sizeof(CK_ATTRIBUTE);
   

/** 
 * Attribute template for the public key.
 */
  
static CK_CHAR pubLabel [] = "public_key_example";
CK_ATTRIBUTE pubKeyTpl[] = 
{
        {CKA_LABEL,             pubLabel,   sizeof(pubLabel)},
        {CKA_TOKEN,             &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_PRIVATE,           &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_ENCRYPT,           &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_VERIFY,            &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_WRAP,              &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_MODIFIABLE,        &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_DERIVE,            &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_EXPORTABLE,        &ckTrue,    sizeof(CK_BBOOL)}

};
CK_COUNT pubKeyTplSize = sizeof(pubKeyTpl)/sizeof(CK_ATTRIBUTE);


/**
 * Attribute template for the private key.
 */

static CK_CHAR priLabel[] = "private_key_example";
CK_ATTRIBUTE privKeyTpl[] = 
{
        {CKA_LABEL,             priLabel,   sizeof(priLabel)},
        {CKA_TOKEN,             &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_PRIVATE,           &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_SENSITIVE,         &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_DECRYPT,           &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_SIGN,              &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_UNWRAP,            &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_MODIFIABLE,        &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_EXTRACTABLE,       &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_DERIVE,            &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_EXPORTABLE,        &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_SIGN_LOCAL_CERT,   &ckTrue,    sizeof(CK_BBOOL)}
};
    
CK_COUNT privKeyTplSize = sizeof(privKeyTpl)/sizeof(CK_ATTRIBUTE);
 

/**
 *
 * C  A  L  L        B  A  C  K       R  O  U  T  I  N  E 
 *
 */

static CK_RV 
PromptString(const char* pszMessage,
                   char* pBuf,
                   CK_ULONG* pBufLen)
{
    CK_RV rv = CKR_OK;

    printf("%s", pszMessage);

    ReadLine(pBuf, *pBufLen);

    return rv;
}

static void 
ShowMsg( UICB_MsgType_t msgType, 
         const char*    pszMessage)
{
    if (msgType == UICB_MT_ERROR)
    {
        fprintf(stderr, "%s", pszMessage);

    }
    else
    {
        printf("%s", pszMessage);

    }
}

/**
 *
 * F  U  N  C  T  I  O  N  S 
 *
 */


static CK_RV
createDES3( CK_SESSION_HANDLE hSession, 
            CK_CHAR_PTR       so_pin,
            CK_OBJECT_HANDLE* secret)
{
    CK_RV rv  = CKR_GENERAL_ERROR;  

    /** SO Login */
    #undef  OP
    #define OP "C_Login"

    rv = C_Login( hSession, 
                  CKU_SO, 
                  so_pin, 
                  strlen((char*)so_pin));

    if (rv != CKR_OK) 
    {    
         ABORT_MSG(OP, rv)
         return rv;
    }

    /** 
     * Generate 192bits DES key 
     * 
     * The following callbacks are used
     * 
     * @li  PromptString
     * @li  ShowMsg
     * 
     * @see kmlib.h
     */

    #undef  OP
    #define OP "KM_GenerateSecretKey"
    
    rv = KM_GenerateSecretKey( hSession,
                               CKK_DES3,
                               192,
                               secKeyTpl,
                               secKeyTplSize,
                               NUM_COMPONENTS,
                               secret);
    if (rv != CKR_OK) 
    {    
         ABORT_MSG(OP,rv)
         return rv;
    }

    /** SO logout */

    #undef  OP
    #define OP "C_Logout"

    rv = C_Logout(hSession); 

    if (rv != CKR_OK) 
    {    
         ABORT_MSG(OP,rv)
         return rv;
    }
    
    return rv;
}



static CK_RV
createRSA( CK_SESSION_HANDLE  hSession, 
           CK_CHAR_PTR        user_pin, 
           CK_OBJECT_HANDLE * pub, 
           CK_OBJECT_HANDLE * priv)
{
    CK_RV rv  = CKR_GENERAL_ERROR;

    /** USER Login */
    #undef  OP
    #define OP "C_Login"

    rv = C_Login( hSession, 
                  CKU_USER, 
                  user_pin, 
                  strlen((char*)user_pin));

    if (rv != CKR_OK) 
    {    
         ABORT_MSG(OP,rv);
         return rv;
    }

    /** 
     * Generate 1024bits RSA key 
     * 
     * The following callbacks are used
     * 
     * @li  PromptString
     * @li  ShowMsg
     * 
     * @see kmlib.h
     */

    #undef  OP
    #define OP "KM_GenerateKeyPair"
    
    rv = KM_GenerateKeyPair( hSession,
                             CKK_RSA,
                             1024,
                             pubKeyTpl,
                             pubKeyTplSize,
                             privKeyTpl,
                             privKeyTplSize,
                             pub,
                             priv);
    if (rv != CKR_OK) 
    {    
         ABORT_MSG(OP,rv);
         return rv;
    }

    /** USER logout */

    #undef  OP
    #define OP "C_Logout"

    rv = C_Logout(hSession); 

    if (rv != CKR_OK) 
    {    
         ABORT_MSG(OP,rv);
         return rv;
    }

    return rv;
}
/**
 *
 * M  A  I  N  
 *
 */


/**
 * @brief     This sample uses the KMLIB to create 2 types of keys.
 *            A secret key which is a 192 bit DES3 key and a 512 bit
 *            RSA key pair. Furthermore, each keys will be split into
 *            2 components.           
 */


int 
main(int argc, char **argv)
{
	
    CK_RV rv                     = CKR_GENERAL_ERROR;
    CK_SESSION_HANDLE hSession   = CK_INVALID_HANDLE;

    CK_OBJECT_HANDLE rsaPubKey   = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE rsaPrivKey  = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE desSecKey   = CK_INVALID_HANDLE;
  
    KM_Callbacks_t km_callbacks;

    ARG_USED(argc);
    ARG_USED(argv);


    /** 
     * Register KMLIB call back - use default call back
     * 
     * @note   Some of the APIs uses call back. See documenatation
     *         for full details. 
     * @see    kmucallbacks.h
     */
    memset(&km_callbacks, 0, sizeof(km_callbacks));
    km_callbacks.promptString       = PromptString;
    km_callbacks.showMsg            = ShowMsg;
    
    /** Register callback */
    #undef  OP
    #define OP "KM_SetCallbacks"
    
    rv = KM_SetCallbacks(&km_callbacks);
    
    if (rv != CKR_OK)
    {
        ABORT_MSG(OP, rv);
        exit(EXIT_FAILURE);
    }


    /** Intialize crypto */
    #undef  OP
    #define OP "C_Initialize"
    
    rv = C_Initialize(NULL);    
    if (rv != CKR_OK) 
    {
        ABORT_MSG(OP, rv)
        exit(EXIT_FAILURE);
    }
    
    /** Open session */   
    #undef  OP
    #define OP "C_OpenSession"
    
    rv = C_OpenSession( SLOT_ID, 
                        CKF_RW_SESSION, 
                        NULL, 
                        NULL, 
                        &hSession);
    if (rv != CKR_OK)
    {
        ABORT_MSG(OP,rv);
        goto end;
    }
 
    /**
     * Create DES3 key 
     */
    #undef  OP
    #define OP "createDES3"

    rv = createDES3( hSession, 
                     (CK_CHAR*)SO_PIN, 
                     &desSecKey);
    if (rv != CKR_OK)
    {
        ABORT_MSG(OP,rv);
        goto end;
    }

    /**
     * Create RSA key pair
     */
    #undef  OP
    #define OP "createRSA"

    rv = createRSA( hSession, 
                    (CK_CHAR*)USER_PIN, 
                    &rsaPubKey, 
                    &rsaPrivKey);
    if (rv != CKR_OK)
    {
        ABORT_MSG(OP,rv);
        goto end;
    }
               
    /** Close session */
    #undef  OP
    #define OP "C_CloseSession"
    
    rv = C_CloseSession(hSession);
    if (rv != CKR_OK)
    {
        ABORT_MSG(OP,rv);
        goto end;
    }
    
    /** Finalize session */
    #undef  OP
    #define OP "C_Finalize"
    
    rv = C_Finalize(NULL);
    if (rv != CKR_OK)
    {
        ABORT_MSG(OP,rv);
        goto end;
    }

end:
    if (rv != CKR_OK) C_Finalize(NULL);

    return(EXIT_SUCCESS);   
}
