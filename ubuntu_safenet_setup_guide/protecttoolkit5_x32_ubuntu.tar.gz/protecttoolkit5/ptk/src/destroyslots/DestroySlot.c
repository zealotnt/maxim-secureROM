/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: DestroySlot.c
 * $Date: 2014/06/05 15:33:07EDT $
 */
/**
 * @file
 *      Sample program to demonstrate how to delete a specified user slot.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cryptoki.h"
#include "ctutil.h"
#include "ctvdef.h"


/**
 * Destroy a specified slot.
 *
 * @param slotId
 *  Id of the slot to destroy.
 *
 * @param pAdminPIN
 *  Current Admin Token USER PIN
 */
static CK_RV destroyUserSlot(unsigned int slotNum,
                             CK_CHAR* pAdminPIN);

/**
 * Locate the admin slot for a specified slot.
 *
 * @slotId
 *  Id of the slot whose admin slot we wish to find.
 *
 * @pAdminSlotId
 *  Location to store the admin slot id of the specified slot.
 */
static CK_RV findAdminSlotFromSlot(CK_SLOT_ID slotId,
                                   CK_SLOT_ID* pAdminSlotId);

/**
 * Finds the slot object to destroy.
 *
 * @param hSession
 *  Handle to an open session.
 *
 * @param slotId
 *  Id of the slot object to find.
 *
 * @param phSlotId
 *  Location to store the handle to the slot object.
 */
static CK_RV findSlot(CK_SESSION_HANDLE hSession,
                      CK_SLOT_ID slotId,
                      CK_OBJECT_HANDLE* phSlotObj);

                                       
static void usage(void)
{
    printf("\ndestroyslots -? -s<SlotId> -u<AdminPin>");
    printf("\n");
    printf("\n-?            help display");
    printf("\n-s            id of the slot to delete");
    printf("\n-u            administrator PIN");
    printf("\n");
    exit(0);
}


int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    char* pArg = NULL;
    char* pValue = NULL;

    CK_CHAR* pAdminPIN = NULL;
    unsigned int slotId = 0;

    int i = 0;

    /*
     * Process commandline arguments
     */
#define GET_VALUE                       \
            if (pArg[1] == '\0')        \
            {                           \
                if (++i < argc)         \
                {                       \
                    pValue = argv[i];   \
                }                       \
                else                    \
                {                       \
                    usage();            \
                }                       \
            }                           \
            else                        \
            {                           \
                pValue = pArg+1;        \
            }

    for(i = 1; i < argc; ++i)
    {
        if (argv[i][0] == '-')
        {
            pArg = &argv[i][1];

            switch (toupper((int)*pArg))
            {
                case '?':
                    usage();
                break;

                case 'S':
                    GET_VALUE;
                    slotId = atoi(pValue);
                break;

                case 'U':
                    GET_VALUE;
                    pAdminPIN = (CK_CHAR*)pValue;
                break;
            }
        }
        else
        {
            usage();
        }
    }

    /* 
     * User input sanity check.
     */
    if (pAdminPIN == NULL)
    {
        fprintf(stderr, "\nAdministrator PIN not specified.\n");
        usage();
    }

    rv = destroyUserSlot(slotId, pAdminPIN);
    if (rv == CKR_OK)
    {
        printf("\nUser slot destroyed.\n");
    }
    else
    {
        printf("\nUser slot was not be destroyed.\n");
    }

    return rv;
}

static CK_RV destroyUserSlot(unsigned int slotId,
                             CK_CHAR* pAdminPIN)
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hSlotObj = CK_INVALID_HANDLE;

    CK_COUNT adminPINLen = 0;
    CK_SLOT_ID adminSlotId;

    /* Start cryptoki */
    rv = C_Initialize(NULL);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not initialise cryptoki - 0x%lx (%s)",
                rv,
                strError(rv));

        return rv;
    }

    /* Determine the admin slot to work on. */
    rv = findAdminSlotFromSlot(slotId, &adminSlotId);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not find admin slot for slot %d - 0x%lx (%s)",
                slotId,
                rv,
                strError(rv));

        goto end;
    }

    /* 
     * Open a read/write user session on the admin token. Essentially, we
     * are logging in the Administrator of the specified device.
     */ 
    rv = C_OpenSession(adminSlotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not open a session on slot %ld - 0x%lx (%s)",
                adminSlotId,
                rv,
                strError(rv));

        goto end;
    }

    adminPINLen = (CK_COUNT)strlen((char*)pAdminPIN);

    rv = C_Login(hSession,
                 CKU_USER,
                 pAdminPIN,
                 adminPINLen);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not login user on Admin Slot %ld - 0x%lx (%s)",
                adminSlotId,
                rv,
                strError(rv));

        goto end;
    }

    /*
     * Find and delete the slot.
     */
    rv = findSlot(hSession, slotId, &hSlotObj);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not find Slot %d - 0x%lx (%s)",
                slotId,
                rv,
                strError(rv));

        goto end;
    }

    rv = C_DestroyObject(hSession, hSlotObj);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not destroy Slot %d - 0x%lx (%s)",
                slotId,
                rv,
                strError(rv));

        goto end;
    }

end:
    /*
     * Clean Up...
     */

    if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

    C_Finalize(NULL);

    return rv;
}

static CK_RV findAdminSlotFromSlot(CK_SLOT_ID slotId,
                                   CK_SLOT_ID* pAdminSlotId)
{
    CK_RV rv = CKR_OK;

    CK_SLOT_ID* pSlots = NULL;
    
    CK_NUMERIC count = 0;
    CK_NUMERIC i = 0;

    int adminSlotCount = 0;

    /* 
     * Get the entire slot list.
     */
    rv = C_GetSlotList(FALSE, NULL, &count);
    pSlots = (CK_SLOT_ID_PTR)malloc(sizeof(CK_SLOT_ID) * count);
    if (pSlots == NULL) return CKR_HOST_MEMORY;

    rv = C_GetSlotList(FALSE, pSlots, &count);
    if (rv != CKR_OK) return rv;

    /* 
     * Loop until the correct admin slot is found.
     */
    for (i = 0; i < count; i++)
    {
        CK_SLOT_INFO slotInfo;

        /* Get information on the current slot */
        rv = C_GetSlotInfo(pSlots[i], &slotInfo);
        if (rv != CKR_OK) goto end;

        /* The admin slot cannot be a removable device. */
        if ((slotInfo.flags & CKF_REMOVABLE_DEVICE) == 0)
        {
            CK_TOKEN_INFO tokenInfo;

            rv = C_GetTokenInfo(pSlots[i], &tokenInfo);
            if (rv != CKR_OK) goto end;

            if (tokenInfo.flags & CKF_ADMIN_TOKEN)
            {
                ++adminSlotCount;

                /*
                 * The admin slot is always the last slot on the device
                 * so the input slot id must be less than the slot id
                 * of its admin token.
                 */
                if (slotId < pSlots[i])
                {
                    *pAdminSlotId = pSlots[i];

                    rv = CKR_OK;
                    break;
                }
            }
        }
    }

end:
    if (pSlots != NULL)
    {
        free(pSlots);
        pSlots = NULL;
    }

    return rv;
}


static CK_RV findSlot(CK_SESSION_HANDLE hSession,
                      CK_SLOT_ID slotId,
                      CK_OBJECT_HANDLE* phSlotObj)
{
    CK_RV rv = CKR_OK;
    CK_OBJECT_HANDLE hObj = CK_INVALID_HANDLE;
    CK_NUMERIC count = 0;

    static CK_OBJECT_CLASS objClass = CKO_SLOT;
    static CK_BBOOL bTrue = TRUE;
    CK_ATTRIBUTE slotTpl[] =
    {
        {CKA_CLASS,     &objClass,  sizeof(CK_OBJECT_CLASS)},
        {CKA_TOKEN,     &bTrue,     sizeof(CK_BBOOL)},
        {CKA_SLOT_ID,   NULL,       sizeof(CK_SLOT_ID)}
    };
    CK_COUNT slotTplSize = sizeof(slotTpl) / sizeof(CK_ATTRIBUTE);

    /* setup the attribute template */
    slotTpl[2].pValue = &slotId;

    /*
     * Find the slot.
     */
    rv = C_FindObjectsInit(hSession, slotTpl, slotTplSize);
    if (rv != CKR_OK) return rv;

    rv = C_FindObjects(hSession, &hObj, 1, &count);
    if (rv != CKR_OK) return rv;

    rv = C_FindObjectsFinal(hSession);
    if (rv != CKR_OK) return rv;

    /* 
     * Check if we found it, if not, return an error.
     */
    if (count == 1)
    {
        *phSlotObj = hObj;
    }
    else
    {
        *phSlotObj = CK_INVALID_HANDLE;

        rv = CKR_SLOT_ID_INVALID;
    }

    return rv;
}


