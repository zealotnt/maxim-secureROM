/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: EncDecDataKP.c
 * $Date: 2014/06/05 15:32:57EDT $
 */
/**
 * @file
 *     Sample program to demonstrate how to encrypt and decrypt data using
 *     an asymmetric key pair.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cryptoki.h"
#include "ctvdef.h"
#include "ctutil.h"

/** 
 * This macro is used to check the return value of a function and print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr, "Error occured : %s\n", string);    \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Search for an object, using the given session.
 *
 * @param hSession 
 *  Session to use to perform the search. If searching for a private 
 *  object, it is up to the caller to perform the C_Login call.
 *
 * @param objClass
 *  Type of the object being searched for.
 *
 * @param pObjLabel
 *  Label of the object to search for
 *
 * @param phObj
 *  Pointer to the handle, which, upon successful completion of the function,
 *  will contain a handle to the object.
 */
static CK_RV findObject(CK_SESSION_HANDLE hSession,
                        CK_OBJECT_CLASS objClass,
                        CK_CHAR* pObjLabel,
                        CK_OBJECT_HANDLE* phObj);

/**
 * Encrypt the given buffer of data, using the given key and storing the 
 * ciphertext in the given buffer.
 *
 * @param hSession
 *  Session to use to perform the encrypt operation
 *
 * @param hKey
 *  Handle to the key to use to perform the encrypt operation
 *
 * @param pData
 *  Data to encrypt
 *
 * @param dataLen
 *  Length of the data that to be encrypted
 *
 * @param ppEncData
 *  Pointer to the location to store the encrypted data.
 *
 * @param pEncDataLen
 *  Location to store the length of the encrypted buffer.
 */
static CK_RV encryptData(CK_SESSION_HANDLE hSession,
                         CK_OBJECT_HANDLE hKey,
                         CK_CHAR* pData,
                         CK_SIZE dataLen,
                         CK_CHAR** ppEncData,
                         CK_SIZE* pEncDataLen);

/**
 * Decrypt an encrypted buffer.
 *
 * @param hSession
 *  Session to use to perform the decrypt operation
 *
 * @param hKey
 *  Handle to the key to use to perform the decrypt operation
 *
 * @param pEncData
 *  The encrypted buffer to decrypt
 *
 * @param encDataLen
 *  Length of the encrypted buffer
 *
 * @param ppData
 *  Pointer to the location to store the decrypted data.
 *
 * @param pDataLen
 *  Location to store the length of the decrypted data.
 */
static CK_RV decryptData(CK_SESSION_HANDLE hSession,
                         CK_OBJECT_HANDLE hKey,
                         CK_CHAR* pEncData,
                         CK_SIZE encDataLen,
                         CK_CHAR** ppData,
                         CK_SIZE* pDataLen);

static void usage(void)
{
    printf("\nencdeckp [-?] [-s<SlotId>] -p<PublicKey> -q<PrivateKey>");
    printf("\n");
    printf("\n-?            help display");
    printf("\n-s            id of the slot to initialise a token in");
    printf("\n-p            the name of the public key to encrypt with");
    printf("\n-q            the name of the private key to decrypt with");
    printf("\n");
    exit(0);
}


/* ****************************************************************************
 *
 *  G L O B A L   D A T A 
 *
 * ***************************************************************************/

CK_CHAR g_dataToEncrypt[] = 
    { 'T', 'h', 'i', 's', ' ', 'i', 's', ' ',
      's', 'o', 'm', 'e', ' ', 'd', 'a', 't',
      'a', ' ', 't', 'o', ' ', 's', 'i', 'g',
      'n', ' ', '.', '.', '.', ' ', ' ', '\0' };



/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char **argv)
{
    CK_RV rv = CKR_OK;

    char* pArg = NULL;
    char* pValue = NULL;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hPubKey = CK_INVALID_HANDLE; 
    CK_OBJECT_HANDLE hPriKey = CK_INVALID_HANDLE;
    
    CK_SLOT_ID slotId = 0;
    CK_CHAR* pPubKeyName = NULL;
    CK_CHAR* pPriKeyName = NULL;

    CK_CHAR* pEncData = NULL;
    CK_SIZE encDataLen = 0;

    CK_CHAR* pData = NULL;
    CK_SIZE dataLen = 0;

    int i = 0;

    /*
     * Process command line arguments
     */
#define GET_VALUE                       \
            if (pArg[1] == '\0')        \
            {                           \
                if (++i < argc)         \
                {                       \
                    pValue = argv[i];   \
                }                       \
                else                    \
                {                       \
                    usage();            \
                }                       \
            }                           \
            else                        \
            {                           \
                pValue = pArg+1;        \
            }

    for (i = 1; i < argc; ++i)
    {
        if (argv[i][0] == '-')
        {
            pArg = &argv[i][1];

            switch (toupper((int)*pArg))
            {
                case '?':
                    usage();
                break;

                case 'S':
                    GET_VALUE;
                    slotId = atoi(pValue);
                break;

                case 'P':
                    GET_VALUE;
                    pPubKeyName = (CK_CHAR*)pValue;
                break;

                case 'Q':
                    GET_VALUE;
                    pPriKeyName = (CK_CHAR*)pValue;
                break;
            }
        }
    }

    /* check user input */
    if (pPubKeyName == NULL)
    {
        printf("\n\nNo public key was specified\n");
        usage();
    }

    if (pPriKeyName == NULL)
    {
        printf("\n\nNo private key was specified\n");
        usage();
    }

    /* Initialise the cryptoki API */
    rv = C_Initialize(NULL);
    CHECK_CK_RV_GOTO(rv, "C_Initialize", end);

    /* Obtain a session so we can perform cryptoki operations */
    rv = C_OpenSession(slotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    CHECK_CK_RV_GOTO(rv, "C_OpenSession", end);

    /* 
     * Find the public key to use for the encrypt operation 
     */
    printf("Finding a public key to encrypt with ... ");

    rv = findObject(hSession, 
                    CKO_PUBLIC_KEY,
                    pPubKeyName,
                    &hPubKey);
    CHECK_CK_RV_GOTO(rv, "FindObject", end);

    printf("Got key\n");

    printf("Data (as string) = %s\n", g_dataToEncrypt);

    /*
     * Perform the encrypt operation
     */
    printf("Performing the encrypt operation ... ");

    rv = encryptData(hSession, 
                     hPubKey,
                     g_dataToEncrypt, 
                     strlen((char*)g_dataToEncrypt), 
                     &pEncData, 
                     &encDataLen);
    CHECK_CK_RV_GOTO(rv, "encData", end);

    printf("done!\n");

    /*
     * Perform the decrypt operation
     */
    printf("Performing the decrypt operation ... ");

    rv = findObject(hSession, 
                    CKO_PRIVATE_KEY,
                    pPriKeyName,
                    &hPriKey);
    CHECK_CK_RV_GOTO(rv, "FindObject", end);

    rv = decryptData(hSession, 
                     hPriKey,  
                     pEncData, 
                     encDataLen,
                     &pData,
                     &dataLen);
    CHECK_CK_RV_GOTO(rv, "decryptData", end);

    printf("done!\n");

    /* We've finished our work, close the session */
    rv = C_CloseSession(hSession);
    CHECK_CK_RV_GOTO(rv, "C_CloseSession", end);

    /* We no longer need the cryptoki API ... */
    rv = C_Finalize(NULL);
    CHECK_CK_RV_GOTO(rv, "C_Finalize", end);

end:

    if (pEncData != NULL)
    {
        free(pEncData);
        pEncData = NULL;
    }

    if (pData != NULL)
    {
        free(pData);
        pData = NULL;
    }

    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Error performing encrypt / decrypt operation : 0x%lx\n",
                rv);

        /*
         * Clean up... we don't care if there are any errors.
         */
        if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

        C_Finalize(NULL);
    }
    else
    {
        printf("Successfully performed encrypt / decrypt operation.\n");
    }

    return rv;
}

/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV findObject(CK_SESSION_HANDLE hSession,
                        CK_OBJECT_CLASS objClass,
                        CK_CHAR* pObjLabel,
                        CK_OBJECT_HANDLE* phObj)
{
    CK_RV rv = CKR_OK;

    /* This is the template used to search for the object. The C_FindObjects 
     * call matches all objects that have attributes matching all attributes 
     * within the search template.
     * 
     * The attributes in the search template are : 
     *  CKA_CLASS - Points to the objClass variable which contains the value
     *              CKO_SECRET_KEY, meaning this object is a secret key object.
     *  CKA_LABEL - Points to a char array containing what will be the label
     *              of the data object.
     *
     * The search will hit on all objects with the given class and label. Note
     * that it is possible to have multiple objects on a token with matching 
     * attributes, no matter what the attributes are. There is nothing 
     * precluding the existence of duplicate objects. In the case of duplicate
     * objects, the first one found is returned 
     */
    CK_ATTRIBUTE tpl[] = 
    {
        {CKA_CLASS,         NULL,       0},
        {CKA_LABEL,         NULL,       0},
    };
    CK_SIZE tplSize = sizeof(tpl) / sizeof(CK_ATTRIBUTE);

    CK_ULONG numObjectsToFind = 1;
    CK_ULONG numObjectsFound = 0;

    CK_ATTRIBUTE* pAttr = NULL;

    /* 
     * Fill out the template with the values to search for
     */

    /* First set the object class ... */
    pAttr = FindAttribute(CKA_CLASS, tpl, tplSize);
    pAttr->pValue = &objClass;
    pAttr->ulValueLen = sizeof(CK_OBJECT_CLASS);

    /* Now set the label ... */
    pAttr = FindAttribute(CKA_LABEL, tpl, tplSize);
    pAttr->pValue = pObjLabel;
    pAttr->ulValueLen = strlen((char*)pObjLabel);

    /* 
     * Now perform the search 
     */

    /* First initialise the search operation */
    rv = C_FindObjectsInit(hSession, tpl, tplSize);
    CHECK_CK_RV_GOTO(rv, "C_FindObjectsInit", end);

    /* Search */
    rv = C_FindObjects(hSession,
                       phObj,
                       numObjectsToFind,
                       &numObjectsFound);
    CHECK_CK_RV_GOTO(rv, "C_FindObjects", end);

    /* Terminate the search */
    rv = C_FindObjectsFinal(hSession);
    CHECK_CK_RV_GOTO(rv, "C_FindFinal", end);

    /* Check to see if we found a matching object */
    if (numObjectsFound == 0)
    {
        fprintf(stderr, "Object not found.\n");
        rv = CKR_GENERAL_ERROR;
    }

end:
    return rv;
}

static CK_RV encryptData(CK_SESSION_HANDLE hSession,
                         CK_OBJECT_HANDLE hKey,
                         CK_CHAR* pData,
                         CK_SIZE dataLen,
                         CK_CHAR** ppEncData,
                         CK_SIZE* pEncDataLen)
{

    CK_RV rv = CKR_OK;

    CK_MECHANISM mech = {CKM_RSA_PKCS, NULL, 0};

    /* Initialise the encrypt operation */
    rv = C_EncryptInit(hSession, &mech, hKey);
    CHECK_CK_RV_GOTO(rv, "C_EncryptInit", end);

    /* Do a length prediction so we allocate enough memory for the ciphertext */
    rv = C_Encrypt(hSession, pData, dataLen, NULL, pEncDataLen);
    CHECK_CK_RV_GOTO(rv, "C_Encrypt", end);
    
    *ppEncData = (CK_CHAR*)malloc(*pEncDataLen);
    if (*ppEncData == NULL) return CKR_HOST_MEMORY;

    /* Do the proper encrypt */
    rv = C_Encrypt(hSession, pData, dataLen, *ppEncData, pEncDataLen);
    CHECK_CK_RV_GOTO(rv, "C_Encrypt", end);

    /*
     * Note that the CKM_RSA_PKCS mechanism (as well as other RSA encryption
     * mechanisms) can only be part of a single-part encrypt operation. This
     * means that it CANNOT be called with C_EncryptUpdate or C_EncryptFinal.
     */

end:

    return rv;
}

static CK_RV decryptData(CK_SESSION_HANDLE hSession,
                         CK_OBJECT_HANDLE hKey,
                         CK_CHAR* pEncData,
                         CK_SIZE encDataLen,
                         CK_CHAR** ppData,
                         CK_SIZE* pDataLen)
{

    CK_RV rv = CKR_OK;

    CK_MECHANISM mech = {CKM_RSA_PKCS, NULL, 0};

    /* Initialise the decrypt operation */
    rv = C_DecryptInit(hSession, &mech, hKey);
    CHECK_CK_RV_GOTO(rv, "C_DecryptInit", end);

    /* Length predication */
    rv = C_Decrypt(hSession, pEncData, encDataLen, NULL, pDataLen);
    CHECK_CK_RV_GOTO(rv, "C_Decrypt", end);

    *ppData = (CK_CHAR*)malloc(*pDataLen);
    if (*ppData == NULL) return CKR_HOST_MEMORY;

    /* Do the actual decrypt operation */
    rv = C_Decrypt(hSession, pEncData, encDataLen, *ppData, pDataLen);
    CHECK_CK_RV_GOTO(rv, "C_Decrypt", end);

    /*
     * Note that the CKM_RSA_PKCS mechanism (as well as other RSA decryption
     * mechanisms) can only be part of a single-part decrypt operation. This
     * means that it CANNOT be called with C_DecryptUpdate or C_DecryptFinal.
     */

end:

    return rv;
}

