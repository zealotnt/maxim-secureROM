/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: hsmadmin/sample1.c
 * $Date: 2014/06/05 15:32:48EDT $
 */
/**
 * @file
 *     Illustrates the use of HSMADM_GetTimeofDay function. For this
 *     case, it is used to time how long it takes to perform a digest.
 */
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

#include "hsmadmin.h"
#include "cryptoki.h"
#include "genmacro.h"
#include "integers.h"

#define HSM_INDEX     0
#define SLOT_ID       0   
#define MAX_DATA_SIZE 10000    /** Size in bytes */

int main(int argc, char *argv[])
{     
	CK_BYTE             data_1[MAX_DATA_SIZE];
    CK_BYTE             data_2[MAX_DATA_SIZE];   
	CK_SESSION_HANDLE   hSession;
	CK_MECHANISM        mech;
	CK_BYTE             digest[20];
	CK_ULONG            digestLen = 0;
	CK_RV               rv        = CKR_OK;
	HSMADM_RV           hsm_rv    = HSMADM_OK;
    HSMADM_TimeVal_t    time_1,   time_2;
    uint64  time_ul_1, time_ul_2;
    uint32  delta;

    ARG_USED(argc);
    ARG_USED(argv);

    memset(data_1,0xFF, MAX_DATA_SIZE);
    memset(data_2,0xEE, MAX_DATA_SIZE);
    
    /** Initialize Cryptoki library */
	rv = C_Initialize(NULL);
	if (rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_Initialize failed: 0x%lx ", rv);
		return -1;
    }
    
    /** Open user session */
	rv = C_OpenSession(SLOT_ID, 
	                   CKF_RW_SESSION|CKF_SERIAL_SESSION, 
	                   NULL, 
	                   NULL, 
	                   &hSession);
	if(rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_OpenSession failed: 0x%lx ", rv);
		return -1;
	}

	/** Set SHA1 mechanism */
	memset(&mech, 0, sizeof(CK_MECHANISM));
	mech.mechanism = CKM_SHA_1;
	
	/** Initialize digest */
	rv = C_DigestInit(hSession, &mech);
	if(rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_DigestInit failed: 0x%lx ", rv);
		return -1;
	}

	/** Get starting time */
	hsm_rv = HSMADM_GetTimeOfDay(HSM_INDEX,
                                 &time_1);
	if(hsm_rv != HSMADM_OK) 
	{
		fprintf(stderr, "\nHSMADM_GetTimeOfDay failed: 0x%lx ", (unsigned long) hsm_rv);
		return -1;
	}             

	/** Perform digest */
	rv = C_DigestUpdate( hSession, 
                         data_1,
	                     sizeof(data_1));
	if(rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_Digest_Update failed: 0x%lx ", rv);
		return -1;
	}
	
	rv = C_DigestUpdate( hSession, 
                         data_2,
	                     sizeof(data_2));
	if(rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_DigestUpdate failed: 0x%lx ", rv);
		return -1;
	}

    /** Finalize digest and retreive hash */
    digestLen = sizeof(digest);
	rv = C_DigestFinal( hSession, 
	                    digest,
                        &digestLen);
	if(rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_DigestUpdate failed: 0x%lx ", rv);
		return -1;
	}

	/** Get finish time */
	hsm_rv = HSMADM_GetTimeOfDay(HSM_INDEX,
                                 &time_2);
	if(hsm_rv != HSMADM_OK) 
	{
		fprintf(stderr, "\nHSMADM_GetTimeOfDay failed: 0x%lx ", (unsigned long)hsm_rv);
		return -1;
	}             
	              
	/** Convert all units to micro-seconds */
	time_ul_1 = (uint64)time_1.tv_sec * 1000000 + (uint64)time_1.tv_usec;
	time_ul_2 = (uint64)time_2.tv_sec * 1000000 + (uint64)time_2.tv_usec;

	delta = (uint32) (time_ul_2-time_ul_1);
	
    fprintf(stdout, "\nDigest operation took %f milliseconds",(float)(delta/1000));
	
    /** Close user session */           
    rv = C_CloseSession(hSession);
	if(rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_CloseSession failed: 0x%lx ", rv);
		return -1;
	}	
	
	/** Finalize cryptoki library */
	rv = C_Finalize(NULL);
	if(rv != CKR_OK) 
	{
		fprintf(stderr, "\nC_Finalize failed: 0x%lx ", rv);
		return -1;
	}

    return 0;
}

