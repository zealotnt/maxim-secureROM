/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: GenSecretKey.c
 * $Date: 2014/06/05 15:33:42EDT $
 */
/**
 * @file
 *     Sample program to demonstrate the generation of a symmetric key. This
 *     example generates a triple-length DES key.
 */
#include <stdio.h>
#include <memory.h>
#include <string.h>

#include "cryptoki.h"
#include "ctvdef.h"
#include "ctutil.h"
#include "genmacro.h"

/** 
 * This macro is used to check the return value of a function, print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr, "Error occured : %s\n", string);    \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Create a token secret key object with the given session, returning the 
 * handle.
 *
 * @param hSession
 *  Handle to the session to use to create the key. If the created key is to
 *  be a private object, it is up to the caller to login.
 *
 * @param phObject
 *  Location to store the handle of the created secret key.
 *
 */
static CK_RV CreateSecretKeyObject(CK_SESSION_HANDLE hSession,
                                   CK_OBJECT_HANDLE_PTR phObject);


/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char **argv)
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hObject = CK_INVALID_HANDLE; 
    CK_SLOT_ID slotId = 0;

    ARG_USED(argc);
    ARG_USED(argv);

    /* Initialise the cryptoki API */
    rv = C_Initialize(NULL);
    CHECK_CK_RV_GOTO(rv, "C_Initialize", end);

    /* Obtain a session so we can perform cryptoki operations */
    rv = C_OpenSession(slotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    CHECK_CK_RV_GOTO(rv, "C_OpenSession", end);

    /* 
     * Create the secret key
     */
    printf("Creating secret key ... ");

    rv = CreateSecretKeyObject(hSession, &hObject);
    CHECK_CK_RV_GOTO(rv, "CreateSecretKeyObject", end);
    
    printf("Object created\n");

    /* We've finished our work, close the session */
    rv = C_CloseSession(hSession);
    CHECK_CK_RV_GOTO(rv, "C_CloseSession", end);

    /* We no longer need the cryptoki API ... */
    rv = C_Finalize(NULL);
    CHECK_CK_RV_GOTO(rv, "C_Finalize", end);

end:

    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Error performing create key operation : 0x%lx\n",
                rv);

        /*
         * Clean up... we don't care if there are any errors.
         */
        if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

        C_Finalize(NULL);
    }
    else
    {
        printf("Successfully performed create key operation.\n");
    }

    return rv;

}

/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV CreateSecretKeyObject(CK_SESSION_HANDLE hSession,
                                   CK_OBJECT_HANDLE_PTR phObject)
{
    CK_RV rv = CKR_OK;

    static CK_CHAR objLabel[] = "NewSecretKey";
    static CK_BBOOL ckTrue = TRUE;
    static CK_BBOOL ckFalse = FALSE;


    /* 
     * This is the mechanism used to generate a DES3 secret key. The fields
     * of the structure are :
     *
     *  CKM_DES3_KEY_GEN - Type of the mechanism. This informs the cryptoki 
     *                     library that we want to create a DES3 key.
     *  NULL             - This field is the parameter field. Some mechanisms 
     *                     require certain parameters to perform their 
     *                     functions. CKM_DES3_KEY_GEN does not require a 
     *                     parameter, hence the NULL value.
     *  0                - This field is the parameter length field. Since 
     *                     this mechanism type does not require a parameter,
     *                     0 is passed in as the length.
     */
    static CK_MECHANISM mechanism = {CKM_DES3_KEY_GEN, NULL, 0};
    
    /* 
     * This is the attribute template, which lays out some of the attributes the 
     * object will have when it is created. The object will also contain other
     * attributes, which are populated with default values. 
     * The attributes in the template are :
     * 
     *  CKA_LABEL - Points to a char array containing what will be the label
     *              of the key object.
     *
     *  CKA_TOKEN - Points to a CK_BBOOL variable containing the value TRUE.
     *              This object, therefore will be a token object, which 
     *              means it will persist on the token between sessions.
     *
     *  CKA_ENCRYPT - Points to a CK_BBOOL variable containing the value TRUE.
     *                This key, therefore will be able to encrypt data. 
     *
     *  CKA_DECRYPT - Points to a CK_BBOOL variable containing the value TRUE.
     *                This key, therefore will be able to decrypt data. 
     *
     *  CKA_SIGN    - Points to a CK_BBOOL variable containing the value TRUE.
     *                This key, therefore will be able to sign data. 
     *
     *  CKA_VERIFY  - Points to a CK_BBOOL variable containing the value TRUE.
     *                This key, therefore will be able to verify signatures. 
     *
     *  Other attributes are explicitly set to FALSE to ensure that they are 
     *  not set to TRUE by default.
     *
     *  The CKA_KEY_TYPE attribute is not set, since it is implied by the 
     *  mechanism. The same goes for the CKA_CLASS attribute.
     */
    CK_ATTRIBUTE objectTemplate[] = 
    {
        {CKA_LABEL,         NULL,       0},
        {CKA_TOKEN,         &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_ENCRYPT,       &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_DECRYPT,       &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_SIGN,          &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_VERIFY,        &ckTrue,    sizeof(CK_BBOOL)},
        {CKA_EXPORT,        &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_IMPORT,        &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_WRAP,          &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_UNWRAP,        &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_EXPORTABLE,    &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_EXTRACTABLE,   &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_MODIFIABLE,    &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_SENSITIVE,     &ckFalse,   sizeof(CK_BBOOL)},
        {CKA_DERIVE,        &ckFalse,   sizeof(CK_BBOOL)},
    };
    CK_SIZE objectSize = sizeof(objectTemplate) / sizeof(CK_ATTRIBUTE);

    CK_ATTRIBUTE* pAttr = NULL;

    /* Fill in the public key label */
    pAttr = FindAttribute(CKA_LABEL, objectTemplate, objectSize);
    pAttr->pValue = objLabel;
    pAttr->ulValueLen = (CK_ULONG)strlen((char*)objLabel);

    rv = C_GenerateKey(hSession, &mechanism, objectTemplate, objectSize, phObject);
    CHECK_CK_RV_GOTO(rv, "C_GenerateKey", end);

end:
    return rv;
}

