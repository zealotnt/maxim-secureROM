/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: SignVerifyData.c
 * $Date: 2014/06/05 15:33:12EDT $
 */
/**
 * @file
 *     Sample program to demonstrate how to sign raw data and verify the
 *     signature generated.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cryptoki.h"
#include "ctvdef.h"
#include "ctutil.h"

/** 
 * This macro is used to check the return value of a function and print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr, "Error occured : %s\n", string);    \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Search for an object, using the given session.
 *
 * @param hSession 
 *  Session to use to perform the search. If searching for a private 
 *  object, it is up to the caller to perform the C_Login call.
 *
 * @param objClass
 *  Type of the object being searched for.
 *
 * @param pObjLabel
 *  Label of the object to search for
 *
 * @param phObj
 *  Pointer to the handle, which, upon successful completion of the function,
 *  will contain a handle to the object.
 */
static CK_RV FindObject(CK_SESSION_HANDLE hSession,
                        CK_OBJECT_CLASS objClass,
                        CK_CHAR* pObjLabel,
                        CK_OBJECT_HANDLE* phObj);

/**
 * Sign the given buffer of data, using the given key and storing the 
 * signature in the given buffer.
 *
 * @param hSession
 *  Session to use to perform the sign operation
 *
 * @param hKey
 *  Handle to the key to use to perform the sign operation
 *
 * @param pData
 *  Data to sign
 *
 * @param dataLen
 *  Length of the data that needs to be signed
 *
 * @param ppSignature
 *  Buffer used to store the resulting signature. Memory must be allocated by
 *  the caller.
 *
 * @param pSignatureLen
 *  Pointer to a CK_SIZE containing the length of the signature buffer. Upon 
 *  successful completion of the function, this parameter will contain the 
 *  amount of data copied into the signature buffer, or the size of the 
 *  buffer required to hold the signature if the given buffer was too small.
 */
static CK_RV SignData(CK_SESSION_HANDLE hSession,
                      CK_OBJECT_HANDLE hKey,
                      CK_CHAR* pData,
                      CK_SIZE dataLen,
                      CK_CHAR** ppSignature,
                      CK_SIZE* pSignatureLen);

/**
 * Verify a given buffer of data against a signature
 *
 * @param hSession
 *  Session to use to perform the verify operation
 *
 * @param hKey
 *  Handle to the key to use to perform the verify operation
 *
 * @param pData
 *  Data to verify the signature against
 *
 * @param dataLen
 *  Length of the data 
 *
 * @param pSignature
 *  Signature to verify the data against
 *
 * @param signatureLen
 *  Length of the signature to be verified.
 */
static CK_RV VerifyData(CK_SESSION_HANDLE hSession,
                        CK_OBJECT_HANDLE hKey,
                        CK_CHAR* pData,
                        CK_SIZE dataLen,
                        CK_CHAR* pSignature,
                        CK_SIZE signatureLen);

/**
 * Get the sign/verify mechanism based on the key type of hObj.
 *
 * @hSession
 *  Handle to an open session.
 *
 * @param hObj
 *  Object used to determine the mechanism required.
 *
 * @param pMechType
 *  Location to the type of mechanism to use for the sign/verify operation.
 */
static CK_RV getMechType(CK_SESSION_HANDLE hSession,
                         CK_OBJECT_HANDLE hObj,
                         CK_MECHANISM_TYPE* pMechType);


static void usage(void)
{
    printf("\nsignverifydata [-?] [-s<SlotId>] -n<KeyName>");
    printf("\n");
    printf("\n-?            help display");
    printf("\n-s            id of the slot to operate in");
    printf("\n-n            name of the secret key to sign and verify with");
    printf("\n");
    exit(0);
}


/* ****************************************************************************
 *
 *  G L O B A L   D A T A 
 *
 * ***************************************************************************/

CK_CHAR g_dataToSign[] = 
    { 'T', 'h', 'i', 's', ' ', 'i', 's', ' ',
      's', 'o', 'm', 'e', ' ', 'd', 'a', 't',
      'a', ' ', 't', 'o', ' ', 's', 'i', 'g',
      'n', ' ', '.', '.', '.', ' ', ' ', '\0' };



/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char **argv)
{
    CK_RV rv = CKR_OK;

    char* pArg = NULL;
    char* pValue = NULL;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;
    CK_OBJECT_HANDLE hKey = CK_INVALID_HANDLE;
    
    CK_SLOT_ID slotId = 0;
    CK_CHAR* pKeyName = NULL;

    CK_CHAR* pSignature = NULL;
    CK_SIZE signatureLen = 0;

    int i = 0;

    /*
     * Process command line arguments
     */
#define GET_VALUE                       \
            if (pArg[1] == '\0')        \
            {                           \
                if (++i < argc)         \
                {                       \
                    pValue = argv[i];   \
                }                       \
                else                    \
                {                       \
                    usage();            \
                }                       \
            }                           \
            else                        \
            {                           \
                pValue = pArg+1;        \
            }

    for (i = 1; i < argc; ++i)
    {
        if (argv[i][0] == '-')
        {
            pArg = &argv[i][1];

            switch (toupper((int)*pArg))
            {
                case '?':
                    usage();
                break;

                case 'S':
                    GET_VALUE;
                    slotId = atoi(pValue);
                break;

                case 'N':
                    GET_VALUE;
                    pKeyName = (CK_CHAR*)pValue;
                break;

            }
        }
    }

    /* check user input */
    if (pKeyName == NULL)
    {
        printf("\n\nNo key was specified\n");
        usage();
    }

    /* Initialise the cryptoki API */
    rv = C_Initialize(NULL);
    CHECK_CK_RV_GOTO(rv, "C_Initialize", end);

    /* Obtain a session so we can perform cryptoki operations */
    rv = C_OpenSession(slotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    CHECK_CK_RV_GOTO(rv, "C_OpenSession", end);

    /* 
     * Find the secret key to use for the sign and verify operations
     */
    printf("Finding a the key to sign ... ");

    rv = FindObject(hSession, 
                    CKO_SECRET_KEY,
                    pKeyName,
                    &hKey);
    CHECK_CK_RV_GOTO(rv, "FindObject", end);

    printf("Got key\n");

    printf("Data (as string) = %s\n", g_dataToSign);

    /*
     * Perform the sign operation
     */
    printf("Performing the sign operation ... ");

    rv = SignData(hSession, 
                  hKey,
                  g_dataToSign, 
                  strlen((char*)g_dataToSign), 
                  &pSignature, 
                  &signatureLen);
    CHECK_CK_RV_GOTO(rv, "SignData", end);

    printf("done!\n");

    /*
     * Perform the verify operation
     */
    printf("Performing the verify operation ... ");

    rv = FindObject(hSession, 
                    CKO_SECRET_KEY,
                    pKeyName,
                    &hKey);
    CHECK_CK_RV_GOTO(rv, "FindObject", end);

    rv = VerifyData(hSession, 
                    hKey, 
                    g_dataToSign, 
                    strlen((char*)g_dataToSign), 
                    pSignature, 
                    signatureLen);
    CHECK_CK_RV_GOTO(rv, "VerifyData", end);

    printf("done!\n");

    /* We've finished our work, close the session */
    rv = C_CloseSession(hSession);
    CHECK_CK_RV_GOTO(rv, "C_CloseSession", end);

    /* We no longer need the cryptoki API ... */
    rv = C_Finalize(NULL);
    CHECK_CK_RV_GOTO(rv, "C_Finalize", end);

end:

    if (rv != CKR_OK)
    {
        fprintf(stderr,
		"Error performing sign / verify operation : 0x%0lX\n",
		 rv);

        /*
         * Clean up... we don't care if there are any errors.
         */
        if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

        C_Finalize(NULL);
    }
    else
    {
        printf("Successfully performed sign / verify operation.\n");
    }

    return rv;
}

/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV FindObject(CK_SESSION_HANDLE hSession,
                        CK_OBJECT_CLASS objClass,
                        CK_CHAR* pObjLabel,
                        CK_OBJECT_HANDLE* phObj)
{
    CK_RV rv = CKR_OK;

    /* This is the template used to search for the object. The C_FindObjects 
     * call matches all objects that have attributes matching all attributes 
     * within the search template.
     * 
     * The attributes in the search template are : 
     *  CKA_CLASS - Points to the objClass variable which contains the value
     *              CKO_SECRET_KEY, meaning this object is a secret key object.
     *  CKA_LABEL - Points to a char array containing what will be the label
     *              of the data object.
     *
     * The search will hit on all objects with the given class and label. Note
     * that it is possible to have multiple objects on a token with matching 
     * attributes, no matter what the attributes are. There is nothing 
     * precluding the existence of duplicate objects. In the case of duplicate
     * objects, the first one found is returned 
     */
    CK_ATTRIBUTE objectTemplate[] = 
    {
        {CKA_CLASS,         NULL,       0},
        {CKA_LABEL,         NULL,       0},
    };
    CK_SIZE templateSize = sizeof(objectTemplate) / sizeof(CK_ATTRIBUTE);

    CK_ULONG numObjectsToFind = 1;
    CK_ULONG numObjectsFound = 0;

    CK_ATTRIBUTE* pAttr = NULL;
    
    /* 
     * Fill out the template with the values to search for
     */

    /* First set the object class ... */
    pAttr = FindAttribute(CKA_CLASS, objectTemplate, templateSize);
    pAttr->pValue = &objClass;
    pAttr->ulValueLen = sizeof(CK_OBJECT_CLASS);

    /* Now set the label ... */
    pAttr = FindAttribute(CKA_LABEL, objectTemplate, templateSize);
    pAttr->pValue = pObjLabel;
    pAttr->ulValueLen = strlen((char*)pObjLabel);

    /* 
     * Now perform the search 
     */

    /* First initialise the search operation */
    rv = C_FindObjectsInit(hSession, objectTemplate, templateSize);
    CHECK_CK_RV_GOTO(rv, "C_FindObjectsInit", end);

    /* Search */
    rv = C_FindObjects(hSession,
                       phObj,
                       numObjectsToFind,
                       &numObjectsFound);
    CHECK_CK_RV_GOTO(rv, "C_FindObjects", end);

    /* Terminate the search */
    rv = C_FindObjectsFinal(hSession);
    CHECK_CK_RV_GOTO(rv, "C_FindObjects", end);

    /* Check to see if we found a matching object */
    if (numObjectsFound == 0)
    {
        fprintf(stderr, "Object not found.\n");
        rv = CKR_GENERAL_ERROR;
    }

end:
    return rv;
}

static CK_RV SignData(CK_SESSION_HANDLE hSession,
                      CK_OBJECT_HANDLE hKey,
                      CK_CHAR* pData,
                      CK_SIZE dataLen,
                      CK_CHAR** ppSignature,
                      CK_SIZE* pSignatureLen)
{

    CK_RV rv = CKR_OK;

    CK_MECHANISM mech;
    CK_MECHANISM_TYPE mechType;

    rv = getMechType(hSession, hKey, &mechType);
    if (rv != CKR_OK) return rv;

    mech.mechanism = mechType;
    mech.pParameter = NULL;
    mech.parameterLen = 0;

    /* Initialise the sign operation */
    rv = C_SignInit(hSession, &mech, hKey);
    CHECK_CK_RV_GOTO(rv, "C_SignInit", end);

    /* Length prediction */
    rv = C_Sign(hSession, pData, dataLen, NULL, pSignatureLen);
    CHECK_CK_RV_GOTO(rv, "C_Sign", end);

    *ppSignature = (CK_CHAR*)malloc(*pSignatureLen);
    if (*ppSignature == NULL) return CKR_HOST_MEMORY;

    /* Length prediction */
    rv = C_Sign(hSession, pData, dataLen, *ppSignature, pSignatureLen);
    CHECK_CK_RV_GOTO(rv, "C_Sign", end);

    /*
     * Since we used C_Sign instead of C_SignUpdate, we don't need to 
     * call C_SignFinal.
     */

end:

    return rv;
}

static CK_RV VerifyData(CK_SESSION_HANDLE hSession,
                        CK_OBJECT_HANDLE hKey,
                        CK_CHAR* pData,
                        CK_SIZE dataLen,
                        CK_CHAR* pSignature,
                        CK_SIZE signatureLen)
{

    CK_RV rv = CKR_OK;

    CK_MECHANISM mech;
    CK_MECHANISM_TYPE mechType;

    rv = getMechType(hSession, hKey, &mechType);
    if (rv != CKR_OK) return rv;

    mech.mechanism = mechType;
    mech.pParameter = NULL;
    mech.parameterLen = 0;

    /* Initialise the verify operation */
    rv = C_VerifyInit(hSession, &mech, hKey);
    CHECK_CK_RV_GOTO(rv, "C_VerifyInit", end);

    /* Perform the verify operation */
    rv = C_Verify(hSession, pData, dataLen, pSignature, signatureLen);
    CHECK_CK_RV_GOTO(rv, "C_Verify", end);

    /*
     * Since we used C_Verify instead of C_VerifyUpdate, we don't need to 
     * call C_VerifyFinal.
     */

end:

    return rv;
}

static CK_RV getMechType(CK_SESSION_HANDLE hSession,
                         CK_OBJECT_HANDLE hObj,
                         CK_MECHANISM_TYPE* pMechType)
{
    CK_RV rv = CKR_OK;

    /* Attribute template used by C_GetAttributeValue */
    static CK_KEY_TYPE keyType;
    CK_ATTRIBUTE tpl[] = 
    {
        {CKA_KEY_TYPE,      &keyType,   sizeof(keyType)}
    };

    if (hObj == CK_INVALID_HANDLE) return CKR_ARGUMENTS_BAD;

    /*
     * Determine what type of key we are dealing with.
     */
    rv = C_GetAttributeValue(hSession, hObj, tpl, 1);
    if (rv != CKR_OK) return rv;

    /*
     * We need the right signing mechanism for the key type.
     */
    switch (keyType)
    {
        case CKK_DES:
            *pMechType = CKM_DES_MAC;
        break;

        case CKK_DES2:
        case CKK_DES3:
            *pMechType = CKM_DES3_MAC;
        break;

        case CKK_AES:
            *pMechType = CKM_AES_MAC;
        break;

        case CKK_IDEA:
            *pMechType = CKM_IDEA_MAC;
        break;
    
        case CKK_CAST:
            *pMechType = CKM_CAST_MAC;
        break;

        case CKK_RC2:
            *pMechType = CKM_RC2_MAC;
        break;

        case CKK_SEED:
            *pMechType = CKM_SEED_MAC;
        break;

        default:
            /* invalid key type */
            rv = CKR_KEY_TYPE_INCONSISTENT;
        break;
    }

    return rv;
}

