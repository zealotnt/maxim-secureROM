/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2000-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: x962.h
 * $Date: 2014/06/05 15:32:59EDT $
 */
#ifndef INC_X962_H
#define INC_X962_H

#include "ber.h"
#include "bvalue.h"
#include "ecc.h"

/*
 * This header file contains the structures that holds the decoded values of the
 * ASN.1 data structures defined in X9.62.
 */

typedef enum {
    BT_GnBasis,
    BT_TpBasis,
    BT_PpBasis,
    BT_Unknown
} BasisType;

typedef struct CharacteristicTwo {
    unsigned long m;
    BasisType basisType;
    Oid *basis;
    union {
        unsigned long trinomial;
        unsigned long pentanomial[3];
    } parameter;
} CharacteristicTwo;

typedef enum {
    FT_PrimeField,
    FT_CharTwoField,
    FT_Unknown
} FieldType;

typedef Value PrimeP;

typedef struct FieldId {
    FieldType fldTyp;
    Oid *fieldType;
    union {
        PrimeP *primeP;
        CharacteristicTwo *charTwo;
        /* Handling of this type is hard. Essentially, the original encoding is
         * stripped from the stream, and stored here, so that it can be
         * restored. Therefore, it is not implemented yet.
         */
        Value *unknown;
    } parameters;
} FieldId;

typedef Value FieldElement;

typedef struct Curve {
    FieldElement *a;
    FieldElement *b;
    Value *seed;
} Curve;

typedef Value ECPoint;

typedef struct ECParameters {
    unsigned long version;
    FieldId *fieldId;
    Curve *curve;
    ECPoint *base;
    Value *order;
    Value *cofactor;
    /* ... is specified in X9.62. What does it mean? */
} ECParameters;

typedef enum {
    PT_ECParameters,
    PT_NamedCurve,
    PT_ImplicitlyCa
} ParamType;

typedef struct Parameters
{
    ParamType type;
    union {
        ECParameters *ecParameters;
        Oid *namedCurve;
    } p;
} Parameters;

/*
 * This structure is obtained from SEC-1 section C.4. It is used in PKCS#8
 * encoding.
 */
typedef struct ECPrivateKey
{
    /* version of the structure. It must be 1. */
    unsigned long version;
    /* Encoded private key. It is an unsigned integer,
     * encoded as OCTET STRING.  */
    Value *privateKey;
    /* The EC Parameters structure. It is OPTIONAL (and has explicit tag 0),
     * but it is recommended that this field is always present.  */
    Parameters *parameters;
    /* The public key. It is optional, and has an explicit tag of 1. */
    ECPoint *publicKey;
} ECPrivateKey;

/**
 * This structure is a figment of my imagination. It does not exist as such in
 * any standard. SEC-1 comes close, but it only allows the encoding of the
 * public key value; not the parameters. However, this structure must exist in
 * order to be able to support EC public key in Cprov. Therefore, there will be
 * no encoders and decoders for this structure - only memory management
 * functions NEW, COPY and FREE.
 */
typedef struct ECPublicKey {
    Parameters *parameters;
    ECPoint *publicKey;
} ECPublicKey;

/*
 * Declare all the ASN function prototypes for the defined types.
 * Convention: The type converters for which the destination type is a Value
 * ~~~~~~~~~~  place the DER encoding of the variable in the destination
 * buffer.
 */

Parameters *NewParameters(void);
void FreeParameters(Parameters *src);
Parameters *CopyParameters(Parameters *src);
unsigned int SizeParameters(Parameters *src);
int EncodeParameters(Field *fld, Parameters *src);
int DecodeParameters(Field *fld, Parameters **src);
int ParametersToECC_Curve_t(Parameters *in, ECC_Curve_t *out);
int ConstructECCPolynomial(CharacteristicTwo * charTwo, unsigned char modulus[ECC_MAX_BUF_LEN]);
int DecodeECCPoint( Value *v, ECC_Point_t * base );
int ParametersToValue(Parameters *in, Value *out);
ECParameters *NewECParameters(void);
void FreeECParameters(ECParameters *src);
ECParameters *CopyECParameters(ECParameters *src);
unsigned int SizeECParameters(ECParameters *src);
int EncodeECParameters(Field *fld, ECParameters *src);
int DecodeECParameters(Field *fld, ECParameters **src);
ECPoint *NewECPoint(void);
void FreeECPoint(ECPoint *src);
ECPoint *CopyECPoint(ECPoint *src);
unsigned int SizeECPoint(ECPoint *src);
int EncodeECPoint(Field *fld, ECPoint *src);
int DecodeECPoint(Field *fld, ECPoint **src);
int ECPointToValue(ECPoint *in, Value *out);
Curve *NewCurve(void);
void FreeCurve(Curve *src);
Curve *CopyCurve(Curve *src);
unsigned int SizeCurve(Curve *src);
int EncodeCurve(Field *fld, Curve *src);
int DecodeCurve(Field *fld, Curve **src);
FieldElement *NewFieldElement(void);
void FreeFieldElement(FieldElement *src);
FieldElement *CopyFieldElement(FieldElement *src);
unsigned int SizeFieldElement(FieldElement *src);
int EncodeFieldElement(Field *fld, FieldElement *src);
int DecodeFieldElement(Field *fld, FieldElement **src);
FieldId *NewFieldId(void);
void FreeFieldId(FieldId *src);
FieldId *CopyFieldId(FieldId *src);
unsigned int SizeFieldId(FieldId *src);
int EncodeFieldId(Field *fld, FieldId *src);
int DecodeFieldId(Field *fld, FieldId **src);
PrimeP *NewPrimeP(void);
void FreePrimeP(PrimeP *src);
PrimeP *CopyPrimeP(PrimeP *src);
unsigned int SizePrimeP(PrimeP *src);
int EncodePrimeP(Field *fld, PrimeP *src);
int DecodePrimeP(Field *fld, PrimeP **src);
CharacteristicTwo *NewCharacteristicTwo(void);
void FreeCharacteristicTwo(CharacteristicTwo *src);
CharacteristicTwo *CopyCharacteristicTwo(CharacteristicTwo *src);
unsigned int SizeCharacteristicTwo(CharacteristicTwo *src);
int EncodeCharacteristicTwo(Field *fld, CharacteristicTwo *src);
int DecodeCharacteristicTwo(Field *fld, CharacteristicTwo **src);
ECPrivateKey *NewECPrivateKey(void);
void FreeECPrivateKey(ECPrivateKey *src);
ECPrivateKey *CopyECPrivateKey(ECPrivateKey *src);
unsigned int SizeECPrivateKey(ECPrivateKey *src);
int EncodeECPrivateKey(Field *fld, ECPrivateKey *src);
int DecodeECPrivateKey(Field *fld, ECPrivateKey **src);
ECPublicKey *NewECPublicKey(void);
void FreeECPublicKey(ECPublicKey *src);
ECPublicKey *CopyECPublicKey(ECPublicKey *src);
unsigned int SizeECPublicKey(ECPublicKey *src);
/* ECC Keys do not contain any embedded encoding within a certificate, as
   RSA and DSA keys do. Therefore, these two functions are not required ... 
int EncodeECPublicKey(Field *fld, ECPublicKey *src);
int DecodeECPublicKey(Field *fld, ECPublicKey **src);
*/
int ECPointToECC_Point_t(const ECPoint *ecPoint, ECC_Point_t *ecc_point);

int ECC_Point_tToECPoint(const ECC_Point_t *ecc_point, 
                         size_t modLen,
                         ECPoint **ecPoint);

#endif /* INC_X962_H */
