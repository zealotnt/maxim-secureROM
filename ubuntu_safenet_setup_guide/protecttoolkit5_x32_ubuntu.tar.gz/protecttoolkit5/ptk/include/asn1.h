/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1997-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: asn1.h
 * $Date: 2014/06/05 15:33:38EDT $
 */
#ifndef	ASN1_INCLUDED
#define ASN1_INCLUDED

#ifndef NOIDENT
#pragma ident "@(#)RELEASE VERSION $Name:  $ SafeNet Inc"
#endif

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

/* ASN1 standard definitions */

enum Asn1_TagClass
{
	ASN1_TC_UNIVERSAL,
	ASN1_TC_APPLICATION,
	ASN1_TC_CONTEXT_SPECIFIC,
	ASN1_TC_PRIVATE
};

enum Asn1_TagType
{
	ASN1_TT_BOOLEAN			= 1,
	ASN1_TT_INTEGER,
	ASN1_TT_BIT_STRING,
	ASN1_TT_OCTET_STRING,
	ASN1_TT_NULL			/* = 5 */,
	ASN1_TT_OBJECT_IDENTIFIER,
	ASN1_TT_OBJECT_DESCRIPTOR,
	ASN1_TT_EXTERNAL,
	ASN1_TT_REAL,
	ASN1_TT_ENUMERATED		/* = 10 */,

	ASN1_TT_UTF8_STRING		= 12,

	ASN1_TT_SEQUENCE		= 16,
	ASN1_TT_SET				= 17,

	ASN1_TT_NUMERIC_STRING	= 18,
	ASN1_TT_PRINTABLE_STRING,
	ASN1_TT_T61_STRING,
	ASN1_TT_VIDEO_STRING,
	ASN1_TT_IA5_STRING,
	
	ASN1_TT_UTCTIME			= 23,
	ASN1_TT_GENTIME,

	ASN1_TT_VISIBLE_STRING	= 26,
	
	ASN1_TT_BMP_STRING      = 30,
	ASN1_TT_MAX
};


#ifdef __cplusplus
}
#endif
#endif	/*ASN1_INCLUDED*/
