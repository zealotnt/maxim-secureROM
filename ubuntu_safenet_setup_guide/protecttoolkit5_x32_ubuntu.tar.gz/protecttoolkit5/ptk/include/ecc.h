/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1992-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: ecc.h
 * $Date: 2015/10/23 14:32:25EDT $
 */
/**
 * @file ecc.h
 *
 * This file contains the type and function definitions for the ECC module.
 */
/*
 * $Id: prod/include/ecc.h 1.1.2.4 2015/10/23 14:32:25EDT Sorokine, Joseph (jsorokine) Exp  $
 * $Author: Sorokine, Joseph (jsorokine) $
 *
 * Copyright (c) 1992,2001 ERACOM Pty. Ltd.
 * All Rights Reserved - Proprietary Information of ERACOM Pty. Ltd.
 * Not to be Construed as a Published Work.
 *
 * $Source: prod/include/ecc.h $
 * $Revision: 1.1.2.4 $
 * $Date: 2015/10/23 14:32:25EDT $
 */
#ifndef INC_ECC_H
#define INC_ECC_H

#include "genmacro.h"

/** @defgroup ecdsamod ECC Module Documentation
 *  @{
 */
/**
 * The minimum allowed modulus length, in number of bits, supported by the
 * ECC module.
 */
#define ECC_MIN_MOD_LEN 64

/**
 * The maximum allowed modulus length, in number of bits, supported by the
 * ECC module.
 */
#define ECC_MAX_MOD_LEN 571

/**
 * The maximum number of bytes that will be needed for buffers that hold ECC
 * related data. Although there are two types of data in these buffers (the
 * field elements, and numbers) the lengths of the numbers are always less than
 * or equal to (almost always equal to) the modulus length.
 */
#define ECC_MAX_BUF_LEN ROUND_UP(ECC_MAX_MOD_LEN, 8)/8

/**
 * The Diffie-Hellman Primitives used to derive a shared secret value.
 */
typedef enum
{
	/** Standard Diffie-Hellman Primitive. */
	ECC_STANDARD_DH_PRIMITIVE = 1,
	/** Modified (or Cofactor) Diffie-Hellman Primitive. */
	ECC_MODIFIED_DH_PRIMITIVE = 2 /* FIXME: NOT IMPLEMENTED */
} ECC_DHP;

/**
 * Posible return values from the ECC functions.
 */
typedef enum {
	/** Operation completed successfully. */
	ECC_OK,

	/** Not enough memory to complete operation */
	ECC_NOMEM,

	/** The verify operation failed: Signature invalid. */
	ECC_ECDSA_SIGN_INVALID,

	/** At least one of the parameters passed to the function is invalid. */
	ECC_PARAM_INVALID,

	/** The named curve was not found */
	ECC_CURVE_NOT_FOUND,

	/** Generic problem */
	ECC_UNSUCCESSFUL,

	/** Internal error in the library. This error value should never be
	 * seen by the caller. */
	ECC_INTERNAL_ERROR,

    /** Pairwise consistency check failed when generating a key pair. */
    ECC_ERR_PAIRWISE
} ECC_RV;

/**
 * Possible curve types for an ECC_Curve_t structure.
 */
typedef enum ECC_FieldType_et {
	/** Identifies a curve over a field with an odd prime number of elements. */
	ECC_FT_GFP,

	/** Identifies a curve over a field of characteristic two (F_2^m). */
	ECC_FT_G2M
} ECC_FieldType_t;

/**
 * This structure represents an ECDSA signature. For more information about
 * ECDSA signatures, consult either the ANSI X9.62, or FIPS 186-2 standard.
 */
typedef struct ECC_EcdsaSignature_st {
	/** 'r' value of the signature. */
	unsigned char r[ECC_MAX_BUF_LEN];

	/** 's' value of the signature. */
	unsigned char s[ECC_MAX_BUF_LEN];
} ECC_EcdsaSignature_t;

/**
 * This structure represents the shared secret value produced by an EC 
 * Diffie-Hellman Derive operation.
 */
typedef struct ECC_DHSecret_st {
	/** The buffer containing the shared secret value. */
	unsigned char secret[ECC_MAX_BUF_LEN];
} ECC_DHSecret_t;

/**
 * This structure represents a point on an Elliptic curve.
 *
 * The number of bits in each element is equal to the number of bits in the
 * modulus of the curve.
 *
 * Please note that without an ECC_Curve_t structure accompanying it, this
 * structure is meaningless.
 */
typedef struct ECC_Point_st {
	/** The X coordinate of the point. X is an element of the field over which
	 * the curve is defined. */
	unsigned char x[ECC_MAX_BUF_LEN];

	/** The Y coordinate of the point. Y is an element of the field over which
	 * the curve is defined. */
	unsigned char y[ECC_MAX_BUF_LEN];
} ECC_Point_t;

/**
 * This structure defines an elliptic curve.
 *
 * All the elements have the same structure for different field types, however
 * the interpretation of the bits change slightly. If the field type is
 * ECC_FT_GFP, the buffers hold large numbers in big endian format. If it is
 * ECC_FT_G2M, the buffers hold coefficients of the polynomials in the
 * field. The leftmost bit (most significant bit of first byte) is the
 * coefficient of the largest power of x, and the rightmost bit is the
 * coefficient of x^0. With these definitions, if the bit lengths are not exact
 * multiples of 8, always the leftmost bits of field elements are set to zero.
 *
 * For fields of type ECC_FT_GFP, the curve equation is @code
 *    y^2 = x^3 + a*x + b @endcode
 *
 * For fields of type ECC_FT_G2M, the curve equation is @code
 *    y^2 + x*y = x^3 + a*x^2 + b @endcode
 *
 * @note These equations are defined in ANSI X9.62 standard.
 */
typedef struct ECC_Curve_st {
	/** The field type, over which this curve is defined. */
	ECC_FieldType_t fieldType;

	/** The curve modulus. This value is the field polynomial for ECC_FT_G2M
	 * field types. */
	unsigned char modulus[ECC_MAX_BUF_LEN];

	/** The coefficient 'a' in the elliptic curve equation. */
	unsigned char a[ECC_MAX_BUF_LEN];

	/** The coefficient 'b' in the elliptic curve equation. */
	unsigned char b[ECC_MAX_BUF_LEN];

	/** The base point. */
	ECC_Point_t base;

	/** The base point order. This buffer contains a big endian large number
	 * regardless of the field type. */
	unsigned char bpOrder[ECC_MAX_BUF_LEN];
} ECC_Curve_t;

/**
 * This structure defines an ECC Private key.
 *
 * The private key is a large number, which is used to calculate the public key
 * from the base of the curve. The equation used for this calculation is
 *                  P = d*G
 * where P is the public key (a point), d is the private key (a number), and G
 * is the base of the curve (a point).
 */
typedef struct ECC_PrivateKey_st {
	/** The buffer containing the private key. The private key is always a
	 * big-endian large number, d, regardless of the field type of the curve.
	 */
	unsigned char d[ECC_MAX_BUF_LEN];
} ECC_PrivateKey_t;

/**
 * This structure defines an ECC Public key.
 *
 * The public key is a point on the elliptic curve.
 */
typedef struct ECC_PublicKey_st {
	/** The point P on the curve, which is calculated from the curve base and
	 * the private key. */
	ECC_Point_t p;
} ECC_PublicKey_t;

/**
 * This function is used to obtain Ordinal Length (n) of curve
 *
 * @param curve
 *    IN: The elliptic curve 
 * @param pOrdLen
 *    OUT: The slength in bits.
 *
 * @return
 *    @li ECC_OK: The operation was completed successfully
 */
ECC_RV ECC_GetOrdLen( 
					 const ECC_Curve_t *curve,
					 unsigned int * pOrdLen);

/**
 * This function is used to sign the data (hash) using ECDSA algorithm.
 *
 * The data usually is the output of a hash function. It's length must always
 * be equal to 20.
 *
 * @param msg
 *    IN: Message/Hash to be signed.
 * @param msgLen
 *    Number of bytes in msg
 * @param privKey
 *    IN: The private key
 * @param curve
 *    IN: The elliptic curve on which the private key is defined
 * @param sign
 *    OUT: The signature.
 *
 * @return
 *    @li ECC_OK: The operation was completed successfully
 *    @li otherwise: The operation failed. The cause of failure is indicated by
 *    the value.
 */
ECC_RV ECC_EcdsaSign(const unsigned char *msg,
					 unsigned int msgLen,
					 const ECC_PrivateKey_t *privKey,
					 const ECC_Curve_t *curve,
					 ECC_EcdsaSignature_t *sign);

/*
 * This function is used to sign the data (hash) using ECDSA algorithm.
 *
 * The data usually is the output of a hash function. It's length must always
 * be equal to 20.
 *
 * @param msg
 *    IN: Message/Hash to be signed.
 * @param msgLen
 *    Number of bytes in msg
 * @param pubKey
 *    IN: The public key
 * @param curve
 *    IN: The elliptic curve on which the key is defined
 * @param sign
 *    IN: The signature.
 *
 * @return
 *    @li ECC_OK: The operation was completed successfully. It means the
 *    signature was valid.
 *    @li ECC_ECDSA_SIGN_INVALID: The signature was invalid.
 *    @li otherwise: The operation failed. The cause of failure is indicated by
 *    the value.
 */
ECC_RV ECC_EcdsaVerify(const unsigned char *msg,
					   unsigned int msgLen,
					   const ECC_PublicKey_t *pubKey,
					   const ECC_Curve_t *curve,
					   const ECC_EcdsaSignature_t *sign);

/**
 * This function is used to generate a key pair defined on the specified
 * elliptic curve.
 *
 * @param curve
 *    IN: The curve for which the key pair will be generated.
 * @param pubKey
 *    OUT: The public component of the key pair.
 * @param privKey
 *    OUT: The private component of the key pair.
 *
 * @return
 *    @li ECC_OK: The operation was completed successfully
 *    @li otherwise: The operation failed. The cause of failure is indicated by
 *    the value.
 */
ECC_RV ECC_GenerateKeyPair(const ECC_Curve_t *curve,
						   ECC_PublicKey_t *pubKey,
						   ECC_PrivateKey_t *privKey);

/**
 * This function is used to derive a shared secret value, between two entities,
 * using the specified Diffie-Hellman primitive.  For more information see
 * ANSI X9.63-2001, Section 5.4, or SEC 1, Ver 1.0, Section 3.3.
 *
 * @param privKey
 *    IN: The private key from entity 1.
 * @param pubKey
 *    IN: The public key from entity 2.
 * @param curve
 *    IN: The elliptic curve on which the keys are defined.
 * @param DHprimitive
 *    IN: The Diffie-Hellman primitive to use.
 * @param secretValue
 *    OUT: The derived shared secret value.
 *
 * @return
 *    @li ECC_OK: The operation was completed successfully
 *    @li otherwise: The operation failed. The cause of failure is indicated by
 *    the value.
 */
ECC_RV ECC_DHDerive(const ECC_PrivateKey_t *privKey,
						const ECC_PublicKey_t *pubKey,
						const ECC_Curve_t *curve,
						ECC_DHP DHprimitive,
						ECC_DHSecret_t *secretValue,
						size_t *secretSize);

/**
 * This function can be used to lookup a named curve, known by the ECC
 * module.
 *
 * If the specified named curve is known, then the structure is initialized
 * with the curve parameters.
 *
 * @param curve
 *    The address of the ECC_Curve_t structure that will be initialized with
 *    the curve parameters.
 * @param curveOid
 *    The short constant of the curve OID. For the list of possible constants,
 *    consult objid.h. The relevant vaules all have the form @c OID_CURVE_XXXX.
 *
 * @return
 *    @li ECC_OK: The specified curve was found, and the structure ws
 *    initialized successfuly.
 *    @li ECC_CURVE_NOT_FOUND: The specified curve is not known by the ECDSA
 *    module.
 */
ECC_RV ECC_GetCurve(ECC_Curve_t *curve,
					int curveOid);

/**
 * ECC_GetCurveOid() function returns named curve OID code by curve pattern.
 */
int ECC_GetCurveOid (ECC_Curve_t *curveToIdentify);

/**
 * This function is called at the startup to perform a Sign/Verify known answer
 * test for supported curves.
 *
 * @param verbose
 * 		IN: flag to display KAT fail message
 *
 * @return
 * 		@li ECC_OK - Tests passed
 * 		@li ECC_INTERNAL_ERROR - The signature results did not match the known
 * 		answers.
 * 		@li otherwise - There was an error. The error is identified by the
 * 		return code.
 */
ECC_RV ECC_PerformEcdsaKat(int verbose);

/**
 * This function is called at the startup to perform a Diffie-Hellman shared
 * secret generation known answer test.
 *
 * @param verbose
 * 		IN: flag to display KAT fail message
 *
 * @return
 *		@li ECC_OK - Tests passed
 *		@li ECC_INTERNAL_ERROR - The signature results did not match the known
 *		answers.
 *		@li otherwise - There was an error. The error is identified by the
 *		return code.
 */
ECC_RV ECC_PerformEcDHKat(int verbose);

/**
 * This function converts ECC_RV errors to CO_xxx errors, and is used by the
 * Elliptic Curve cipher objects
 *
 * @param err
 * 		IN: the ECC_RV error to convert
 *
 * @return
 * 		the most applicable matching CO_xxx error
 */
int translateEcdsaErrorToCOError(ECC_RV err);

#if 0
/* Can't implement this unless RCE implements support for randomly generating
   curves.
*/
ECC_RV ECC_Curve_Generate(ECC_Curve_t **curve,
		... /* Not defined yet... */);
#endif

/** @} */

#endif /* INC_ECC_H */
