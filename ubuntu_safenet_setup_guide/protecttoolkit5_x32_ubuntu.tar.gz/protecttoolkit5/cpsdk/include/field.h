/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1997-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: field.h
 * $Date: 2014/06/05 15:33:45EDT $
 */
#ifndef	FIELD_INCLUDED
#define FIELD_INCLUDED

#ifndef NOIDENT
#pragma ident "@(#)RELEASE VERSION $Name:  $ SafeNet Inc"
#endif

#include "bio.h"

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

#define BER_DEFAULT_DEPTH 16

typedef struct TagInfo {
	unsigned int tc;	/* tag class */
	unsigned int tag;
	int constructed;
} TagInfo;

typedef struct LengthInfo LengthInfo;

struct LengthInfo {
	size_t curlen;
	size_t maxlen;
	size_t eocCount;
};

#define FLD_NO_DECODE_SUB_ENCODINGS	0x01

struct Field {
	Io * io;
	TagInfo ti;
	size_t contlen;
	unsigned int depth;
	unsigned int maxDepth;
	int copy;
	int error;
	LengthInfo *stack;
	void * unused; /* unused */
	unsigned int flags;
	int (*f)(struct Field * f, int id,
		unsigned char * buf, unsigned int len);
};
typedef struct Field Field;

/*
**	Field constructors
*/
Field * NewField(void);
Field * NewFieldFromIo(struct Io * io);
void FreeField( Field * f );
int FieldOpenFile( Field ** pf, const char * ifname, unsigned int type);
int FieldOpenBuf( Field ** pf, unsigned char * buf, size_t length,
			   unsigned int type );
int FieldOpenBufCache( Field ** pf, unsigned char * buf, size_t length,
		unsigned int type);
int FieldOpenCount( Field ** pf );
int FieldField( Field ** pf, Field * ef );
int FieldTell(Field *f, size_t *pos);
int FieldSeek(Field *f, ssize_t pos);
int FieldGetPhysicalPos(Field *f, size_t *pos);

/* Field type constants */
#define ASN1_FT_ENCODER 1
#define ASN1_FT_DECODER 2

/* Field Seek type constants */
#define ASN1_SEEK_SET 1
#define ASN1_SEEK_CUR 2
#define ASN1_SEEK_END 3

#ifdef __cplusplus
}
#endif
#endif	/*FIELD_INCLUDED*/
