/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1997-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: dnstr.h
 * $Date: 2014/06/05 15:32:58EDT $
 */
#ifndef INC_DNSTR_H
#define INC_DNSTR_H


CK_RV NameFromBuf(struct DistName ** pName, const char * value, unsigned int size);
CK_RV NameToBuf(const DistName * dname, char ** pvalue, unsigned int * psize);

CK_RV NameToDERBuf(const DistName * dname,	/* the DN to encode */
			unsigned char **pvalue,			/* the DER encoded string */
			unsigned int *psize				/* the length of DER encoded string */
);

#endif /* ifndef INC_DNSTR_H */
