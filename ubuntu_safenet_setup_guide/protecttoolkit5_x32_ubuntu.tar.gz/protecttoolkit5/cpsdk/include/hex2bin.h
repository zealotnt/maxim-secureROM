/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2009-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: hex2bin.h
 * $Date: 2014/09/03 15:13:38EDT $
 */
#ifndef HEX2BIN_INCLUDED
#define HEX2BIN_INCLUDED

#include <integers.h>

#ifdef __cplusplus
extern "C" {                /* define as 'C' functions to prevent mangling */
#endif

size_t asc2bcd(void * bcd, const char * asc, size_t maxLen);

size_t hex2bin( void * bin, const char * hex, size_t maxLen );
size_t bin2hex( char * hex, const void * bin, size_t maxLen );
size_t bin2hexM( char * hex, const void * bin, size_t maxLen, size_t lineLen );

void memdump(const char * txt, const unsigned char * buf, size_t len);

/* parity functions */
void SetOddParity( unsigned char * string, size_t count );
int isOddParity( const unsigned char * string, size_t count );
int MakeParityOdd(unsigned char *string, size_t count );
void xormem(unsigned char * x, const unsigned char * y, size_t len);

#ifdef __cplusplus
}
#endif

#endif
