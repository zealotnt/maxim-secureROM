/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 2004-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: InitToken.c
 * $Date: 2014/06/05 15:33:15EDT $
 */
/**
 * @file
 *     Sample program to demonstrate how to initialize a token.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cryptoki.h"
#include "ctutil.h"

/** 
 * This macro is used to check the return value of a function and print an 
 * error message and jump to a label if the value is not CKR_OK. Using it
 * reduces the complexity of code within a function.
 */
#define CHECK_CK_RV_GOTO(rv, string, label)                 \
    if (rv != CKR_OK)                                       \
    {                                                       \
        fprintf(stderr, "Error occured : %s\n", string);    \
        goto label;                                         \
    }


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N   P R O T O T Y P E S 
 *
 * ***************************************************************************/

/**
 * Initialize a token on the specified slot.
 *
 * @param slotId
 *  Id of the slot to initialize the token in.
 *
 * @param pLabel
 *  The label to set on the new token.
 * 
 * @param pUserPin
 *  The user pin to set on the new token
 *
 * @param pSoPin
 *  The SO pin to set on the new token.
 */
static CK_RV initToken(CK_SLOT_ID slotId,
                       CK_CHAR* pLabel,
                       CK_CHAR* pUserPin,
                       CK_CHAR* pSoPin);

static void usage(void)
{
    printf("\ninittoken [-?] [-s<SlotId>]");
    printf("\n");
    printf("\n-?            help display");
    printf("\n-s            id of the slot to initialise a token in");
    printf("\n");
    exit(0);
}

/* ****************************************************************************
 *
 *  M A I N    F U N C T I O N 
 *
 * ***************************************************************************/
int main(int argc, char* argv[])
{
    CK_RV rv = CKR_OK;

    char* pArg = NULL;
    char* pValue = NULL;

    /* default values */
    char* pCharSlotId = "0";
    CK_SLOT_ID slotId = 0;              /* use slot 0 by default */
    CK_CHAR tokenLabel[32];
    CK_CHAR defaultLabel[] = "Token ";
    CK_CHAR userPin[] = "0000";
    CK_CHAR soPin[] = "9999";

    int i = 0;

    /*
     * Process command line arguments
     */
#define GET_VALUE                       \
            if (pArg[1] == '\0')        \
            {                           \
                if (++i < argc)         \
                {                       \
                    pValue = argv[i];   \
                }                       \
                else                    \
                {                       \
                    usage();            \
                }                       \
            }                           \
            else                        \
            {                           \
                pValue = pArg+1;        \
            }

    for (i = 1; i < argc; ++i)
    {
        if (argv[i][0] == '-')
        {
            pArg = &argv[i][1];

            switch (toupper((int)*pArg))
            {
                case '?':
                    usage();
                break;

                case 'S':
                    GET_VALUE;
                    pCharSlotId = pValue;
                break;
            }
        }
    }

    /*
     * Start cryptoki.
     */
    rv = C_Initialize(NULL);
    if (rv != CKR_OK) 
    {
        fprintf(stderr,
                "Could not initialize cryptoki - 0x%lx (%s)",
                rv,
                strError(rv));

        return rv;
    }

    /*
     * Setup the label.
     */
    strcpy((char*)tokenLabel, (char*)defaultLabel);
    strcat((char*)tokenLabel, pCharSlotId);

    slotId = atoi(pCharSlotId);

    rv = initToken(slotId, tokenLabel, userPin, soPin);
    if (rv == CKR_OK)
    {
        printf("\nToken initialisation successful.\n");
    }
    else
    {
        printf("\nToken initialisation unsuccessful.\n");
    }

    C_Finalize(NULL);

    return rv;
}


/* ****************************************************************************
 *
 *  P R I V A T E   F U N C T I O N S 
 *
 * ***************************************************************************/
static CK_RV initToken(CK_SLOT_ID slotId,
                       CK_CHAR* pLabel,
                       CK_CHAR* pUserPin,
                       CK_CHAR* pSoPin)
{
    CK_RV rv = CKR_OK;

    CK_SESSION_HANDLE hSession = CK_INVALID_HANDLE;

    CK_CHAR paddedLabel[32];
    CK_COUNT actualLabelLen = 0;

    /* check arguments */
    if ((pLabel == NULL) || (pUserPin == NULL) || (pSoPin == NULL))
    {
        return CKR_ARGUMENTS_BAD;
    }

    /*
     * The PKCS#11 standard states that token labels must be 32 bytes padded
     * with spaces.
     */
    actualLabelLen = strlen((char*)pLabel);
    memset(paddedLabel, ' ', sizeof(paddedLabel));
    memcpy(paddedLabel, pLabel, actualLabelLen);

    /*
     * Initialise the token.
     */
    rv = C_InitToken(slotId, pSoPin, strlen((char*)pSoPin), paddedLabel);
    if (rv != CKR_OK) 
    {
        fprintf(stderr,
                "Could not initialise token on slot %ld - 0x%lx (%s)",
                slotId,
                rv,
                strError(rv));

        return rv;
    }

    /*
     * We now want to intialize the user pin. To do this we will use the 
     * C_InitPIN() function which can only be called in the "R/W SO Functions"
     * state. So, open a session and log in the SO.
     */
    rv = C_OpenSession(slotId, CKF_RW_SESSION, NULL, NULL, &hSession);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not open a session on Slot %ld - 0x%lx (%s)",
                slotId,
                rv,
                strError(rv));

        goto end;
    }

    rv = C_Login(hSession,
                 CKU_SO,
                 pSoPin,
                 strlen((char*)pSoPin));
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not login SO on Slot %ld - 0x%lx (%s)",
                slotId,
                rv,
                strError(rv));

        goto end;
    }

    /*
     * No errors, so initialse the user pin.
     */
    rv = C_InitPIN(hSession, pUserPin, strlen((char*)pUserPin));
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not initialize user pin on Slot %ld - 0x%lx (%s)",
                slotId,
                rv,
                strError(rv));

        goto end;
    }

    /*
     * Leave the put the application in the same state as before the function
     * was called. This means closing any open sessions.
     */
    rv = C_CloseSession(hSession);
    if (rv != CKR_OK)
    {
        fprintf(stderr,
                "Could not close session on Slot %ld - 0x%lx (%s)",
                slotId,
                rv,
                strError(rv));

        goto end;
    }

    return CKR_OK;


end:
    /*
     * Clean up... if there were any open sessions, close them.
     */
    if (hSession != CK_INVALID_HANDLE) C_CloseSession(hSession);

    return rv;
}

