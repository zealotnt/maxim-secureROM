/*
 *  This file is provided as part of the SafeNet Protect Toolkit SDK.
 *
 *  (c) Copyright 1999-2014 SafeNet, Inc. All rights reserved.
 *  This file is protected by laws protecting trade secrets and confidential
 *  information, as well as copyright laws and international treaties.
 *
 *  Filename: fcrypt.c
 * $Date: 2014/06/05 15:33:46EDT $
 */

/**
**  @file
**  This is a file encryption program.
**
**  It will encrypt and sign a supplied file using PKCS#11
**  based keys.
**
**  The input file maybe any binary file.
**  The output is encoded with all numeric fields
**  fixed to 32 bits big endian.
**  The encoding is as follows :
**      Encrypted key.
**      Encrypted file length.
**      Encrypted file data.
**      Signature block.
**  A PKCS#7 encoding would be better but is not yet supported.
**  Note that it would have been better to add the signature block
**  to the data that gets encrypted rather than after the encrypted
**  data.
*/

#include <stdio.h>

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#ifdef __linux__
#   define __USE_LARGEFILE64
#endif
#include <sys/stat.h>

#if defined(__SCO_VERSION__) || defined(_AIX43) || defined(__hpux) || \
    defined (__linux__) || defined(sun)
#  include <netinet/in.h>
#  include <arpa/inet.h>
#endif

#ifndef _WINDOWS
#  define _stat stat
#  define _fstat fstat
#  define _fileno fileno
#endif

#include <time.h>

#ifdef __linux__
#undef _fstat
#define _fstat fstat64
#undef _stat
#define _stat stat64
#endif

#include "cprovver.h"
#include "cryptoki.h"
#include "ctextra.h"
#include "ctutil.h"
#include "chkret.h"

int encryptFile( char * sender, char * recipient,
    char * ifile, char * ofile );
int decryptFile( char * sender, char * recipient,
    char * ifile, char * ofile );
void usage(char *progName);

static int dflag = 0;   /* 1 - decrypt */
static int tflag = 0;   /* 1 - time */
static int pflag = 0;   /* 1 - use pbe */
/* used externally to store erro strings for printing */
char ErrorString[100];

#undef FN
#define FN "main:"

int main(int argc, char ** argv)
{
    CK_RV rv;
    int err = 0;
    char * arg, * progName;
    static char * sender = NULL;        /* provides signing key */
    static char * recipient = NULL; /* provides encryption key */
    static char * ofile = "file.enc";   /* default output file name */

    time_t t1 = 0, t2, now;

    printf( "Cryptoki File Encryption " CPROV_VERSION_STR "\n" );
    printf( CPROV_COPYRIGHT_STR "\n" );

    if ((progName = strrchr(*argv, '/')) == NULL) {
        progName = *argv;
    }
    else {
        progName++;
    }

    for ( argv++, argc--; argc && *argv; argv++, argc-- ) {
        arg = *argv;

        if ( arg[0] == '-' ) {
            switch (arg[1]) {
            case 'h':
                printf("usage: %s [-d] [-t] [-o<outfile>] -p<password> "
                        "infile\n", progName);
                printf("       %s [-d] [-t] [-o<outfile>] -s<key> -r<key> "
                        "infile\n", progName);
                printf("       -h View this help\n");
                printf("       -d Decrypt instead of encrypt\n");
                printf("       -o Output file name\n");
                printf("       -p PBE password\n");
                printf("       -r Recipient key name\n");
                printf("       -s Sender key name\n");
                printf("       -t Report timing info\n");
                printf("\nEither a pbe-password is given or sender and "
                        "recipient must be given\n");
                printf("\nKey naming syntax :\n");
                printf("   <token name>(<user pin>)/<key name>\n" );
                printf("   eg -sAlice(0000)/Sign\n");
                return 1;

            case 'd':
                dflag = 1;
                break;
            case 'o':
                ofile = arg+2;
                break;
            case 'p':
                pflag = 1;
                sender = arg+2;
                recipient = sender;
                break;
            case 'r':
                recipient = arg+2;
                break;
            case 's':
                sender = arg+2;
                break;
            case 't':
                tflag = 1;
                break;

            default:
                fprintf(stderr, "%s: Illegal argument: '%s'\n", progName, arg);
                fprintf(stderr, "Use '%s -h' for help\n", progName);
                return 1;
            }
        }
        else {
            break;
        }
    }

    arg = *argv;

    if ( sender == NULL || recipient == NULL ) {
        fprintf(stderr, "\n%s: sender and recipient must be given\n", progName);
        return 2;
    }

    if ( arg == NULL ) {
        fprintf(stderr, "\n%s: Input file must be specified.\n", progName);
        return 2;
    }

    /* This must be the first CRYPTOKI call made */
    rv = C_Initialize(NULL_PTR);
    if ( rv ) {
        CT_ErrorString(rv,ErrorString,sizeof(ErrorString));
        fprintf(stderr, "%s: C_Initialize error %lx, %s\n", progName, rv,
                ErrorString);
        return 1;
    }

    /* Check Cryptoki version */
    rv = CheckCryptokiVersion();
    if ( rv ) {
        fprintf(stderr, "%s: Incompatible Cryptoki version (0x%lx)\n",
                progName, rv );
        return -1;
    }

    if ( tflag ) {
        /* Mark the time now */
        for ( t1 = now = time(NULL); now == t1; )
            t1 = time(NULL);
    }

    /* process the file */
    if ( dflag ) {
        err = decryptFile( sender, recipient, arg, ofile );
    }
    else {
        err = encryptFile( sender, recipient, arg, ofile );
    }

    /* report error or timing */
    if ( err ) {
        fprintf(stderr, "%s: Error %scrypting file %s\n", progName,
                dflag?"de":"en", arg );
    }
    else if ( tflag ) {
        t2 = time(NULL);
        printf("%ld seconds\n", t2-t1);
    }

    /* shut down CRYPTOKI operations */
    rv = C_Finalize(NULL_PTR);
    if ( rv ) {
        CT_ErrorString(rv,ErrorString,sizeof(ErrorString));
        fprintf(stderr, "%s: C_Finalize error %lx, %s\n", progName, rv,
                ErrorString);
        return 1;
    }

    return err;
}

/* Wrapped encryption key template */
static char True = TRUE;
static CK_OBJECT_CLASS Class = CKO_SECRET_KEY;
static CK_KEY_TYPE Kt = CKK_DES2;
static CK_ATTRIBUTE wrappedKeyTemp[] = {
    {CKA_CLASS, &Class, sizeof(Class)},
    {CKA_KEY_TYPE, &Kt, sizeof(Kt)},
    {CKA_EXTRACTABLE, &True, 1},
    {CKA_ENCRYPT, &True, 1},
};

/*
**  Encrypt a file 'ifile' using key specified by 'recipient' and
**  sign it using key specified by 'sender'. Output is encoded and
**  written to 'ofile'.
*/
#undef FN
#define FN "encryptFile:"

int
encryptFile( char * sender, char * recipient,
    char * ifile, char * ofile )
{
    /* sender slot key session handles */
    CK_SLOT_ID hsSlot;
    CK_OBJECT_HANDLE hsKey = 0;
    CK_SESSION_HANDLE hsSession;
    /* recipient slot key session handles */
    CK_SLOT_ID hrSlot;
    CK_OBJECT_HANDLE hrKey;
    CK_SESSION_HANDLE hrSession;

    CK_RV rv;
    CK_MECHANISM mech;
    CK_BYTE iv[8];          /* used with CBC encryption */
    CK_BYTE digest[80];
    CK_SIZE len;
    CK_OBJECT_HANDLE hKey;  /* random encrypting key */
    CK_BYTE wrappedKey[2 * 1024];
    CK_SIZE wrappedKeyLen = 0;
    CK_BYTE signature[2 * 1024];
    unsigned long fileSize;
    unsigned long encodedSize;

    if ( pflag ) {
        /* use PBE to do the encryption */
        static CK_OBJECT_CLASS at_class = CKO_SECRET_KEY;
        static CK_KEY_TYPE kt = CKK_DES2;
        static const CK_BBOOL True = TRUE;
        static const CK_BBOOL False = FALSE;
        CK_ATTRIBUTE attr[] = {
            {CKA_CLASS, &at_class, sizeof(at_class)},
            {CKA_KEY_TYPE, &kt, sizeof(at_class)},
            {CKA_EXTRACTABLE, (void*)&True, sizeof(True)},
            {CKA_SENSITIVE, (void*)&False, sizeof(False)},
            {CKA_DERIVE, (void*)&True, sizeof(True)}
        };
        CK_BYTE iv[8];
        CK_PBE_PARAMS params;
        memset(&params, 0x0, sizeof(CK_PBE_PARAMS));
        params.pInitVector = iv;
        params.pPassword = (CK_CHAR_PTR)sender;
        params.passwordLen = strlen(sender);
        params.pSalt = NULL;
        params.saltLen = 0;
        params.iteration = 1;

        memset(&mech, 0x0, sizeof(CK_MECHANISM));
        mech.mechanism = CKM_PBE_SHA1_DES2_EDE_CBC;
        mech.pParameter = &params;
        mech.parameterLen = sizeof(CK_PBE_PARAMS);

        /* use slot 0 because we just need the mechanism, not a key */
        rv = C_OpenSession(0, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL,
                &hsSession);
        if ( rv ) return 1;
        /* there is no distinction between recipient & sender */
        hrSession = hsSession;

        /* generate the file data encryption key */
        rv = C_GenerateKey(hsSession, &mech, attr, NUMITEMS(attr), &hKey);
        CHECK_RV(FN "C_GenerateKey:CKM_PBE_SHA1_DES2_EDE_CBC", rv);
        if ( rv ) return 1;
    }
    else {
        /* use RSA to encrypt the file */
        /* locate encrypting key */
        rv = FindKeyFromName(sender, CKO_PRIVATE_KEY,
            &hsSlot, &hsSession, &hsKey);
        if ( rv ) {
            fprintf( stderr, "Unable to access sender (%s) key\n", sender );
            CHECK_RV(FN "FindKeyFromName", rv);
            if ( rv ) return 1;
        }
        /* locate signing key */
        rv = FindKeyFromName(recipient, CKO_CERTIFICATE,
            &hrSlot, &hrSession, &hrKey);
        if ( rv ) {
            rv = FindKeyFromName(recipient, CKO_PUBLIC_KEY,
                &hrSlot, &hrSession, &hrKey);
        }
        if ( rv ) {
            fprintf( stderr, "Unable to access recipient (%s) key\n",
                    recipient );
            CHECK_RV(FN "FindKeyFromName", rv);
            if ( rv ) return 1;
        }

        /* create a random des key for the encryption */
        memset(&mech,0,sizeof(mech));
        mech.mechanism = CKM_DES2_KEY_GEN;
        /* generate the key */
        rv = C_GenerateKey(hrSession, &mech,
            wrappedKeyTemp, NUMITEMS(wrappedKeyTemp), &hKey);
        CHECK_RV(FN "C_GenerateKey", rv);
        if ( rv ) return 1;

        /* wrap the encryption key with the recipients public key */
        memset(&mech,0,sizeof(mech));
        mech.mechanism = CKM_RSA_PKCS;
        memset(wrappedKey,0,sizeof(wrappedKey));
        wrappedKeyLen = sizeof(wrappedKey);
        rv = C_WrapKey(hrSession, &mech, hrKey, hKey,
                wrappedKey, &wrappedKeyLen);
        CHECK_RV(FN "C_WrapKey", rv);
        if ( rv ) return 1;
    }

    /* set up the encryption operation using the random key */
    memset(&mech, 0, sizeof(CK_MECHANISM));
    mech.mechanism = CKM_DES3_CBC_PAD;
    memset(iv, 0, sizeof(iv));
    mech.pParameter = iv;
    mech.parameterLen = sizeof(iv);
    rv = C_EncryptInit(hrSession, &mech, hKey);
    CHECK_RV(FN"C_EncryptInit", rv);
    if ( rv ) return 1;

    /* Set up the digest operation */
    memset(&mech, 0, sizeof(CK_MECHANISM));
    mech.mechanism = CKM_SHA_1;
    rv = C_DigestInit(hrSession, &mech);
    CHECK_RV(FN "C_DigestInit", rv);
    if ( rv ) return 1;

    /*
    **  Process the file.
    */
    {
        FILE * ifp; /* input */
        FILE * ofp; /* output */
        CK_SIZE curLen;
        CK_SIZE slen;
        unsigned char buffer[10 * 1024];
        unsigned char encbuffer[10 * 1024];
        unsigned int br;    /* bytes read */
        unsigned int totbw; /* total bytes writted */

        /* open input and output file pointers */
        ifp = fopen(ifile, "rb");
        if ( ifp == NULL ) {
            fprintf( stderr, "Cannot open %s for input\n", ifile );
            return -1;
        }
        ofp = fopen(ofile, "wb");
        if ( ofp == NULL ) {
            fprintf( stderr, "Cannot open %s for input\n", ofile );
            return -1;
        }

        if ( ! pflag ) {
            /* write the encrypted key to the output file */
            encodedSize = (unsigned long)hton_long(
                            (unsigned long)wrappedKeyLen);
            br = fwrite(&encodedSize, 1, sizeof(encodedSize), ofp);
            br = fwrite(wrappedKey, 1, (int)wrappedKeyLen, ofp);
        }

        /* get the file length */
        {
            struct _stat buf;
            int result;
            result = _fstat( _fileno(ifp), &buf );
            if ( result != 0 ) {
                fprintf( stderr, "Cannot get file size for %s\n", ofile );
                return -1;
            }
            fileSize = buf.st_size;
            /*
            fileSize = _filelength(_fileno(ifp));
            */
        }
        fileSize = (fileSize + 8) & ~7; /* round up for padding */

        /* write file size to output file */
        encodedSize = (unsigned long)hton_long(fileSize);      /* big endian */
        br = fwrite(&encodedSize, 1, sizeof(encodedSize), ofp);

        /* read, encrypt, digest and write the cipher text in chunks */
        totbw = 0;
        for ( ;; ) {
            br = fread(buffer, 1, sizeof(buffer), ifp);
            if ( br == 0 )
                break;
            /* digest */
            rv = C_DigestUpdate(hrSession, buffer, (CK_SIZE) br);
            CHECK_RV(FN "C_DigestUpdate", rv);
            if ( rv ) return 1;
            /* encrypt */
            curLen = sizeof(encbuffer);
            rv = C_EncryptUpdate(hrSession, buffer, (CK_SIZE) br,
                encbuffer, &curLen);
            CHECK_RV(FN "C_EncryptUpdate", rv);
            if ( rv ) return 1;
            /* write cipher text */
            br = fwrite(encbuffer, 1, (int)curLen, ofp);
            totbw += br;
        }
        /* finish off the encryption */
        curLen = sizeof(encbuffer);
        rv = C_EncryptFinal(hrSession, encbuffer, &curLen);
        CHECK_RV(FN "C_EncryptFinal", rv);
        if ( rv ) return 1;
        if ( curLen ) {
            br = fwrite(encbuffer, 1, (int)curLen, ofp);
            totbw += br;
        }
        if ( totbw != fileSize ) {
            fprintf( stderr, "size prediction incorrect %u, %ld\n", totbw,
                    fileSize );
        }

        /* finish off the digest */
        len = sizeof(digest);
        rv = C_DigestFinal(hrSession, digest, &len);
        CHECK_RV(FN "C_DigestFinal", rv);
        if ( rv ) return 1;

        if ( pflag ) {
            slen = len;
            memcpy(signature, digest, slen);
        }
        else {
            /* Set up the signature operation */
            memset(&mech, 0, sizeof(CK_MECHANISM));
            mech.mechanism = CKM_RSA_PKCS;
            rv = C_SignInit(hsSession, &mech, hsKey);
            CHECK_RV(FN "C_SignInit", rv);
            if ( rv ) return 1;
            slen = sizeof(signature);
            rv = C_Sign(hsSession, digest, len, signature, &slen);
            CHECK_RV(FN "C_SignInit", rv);
            if ( rv ) return 1;
        }
        /* write the signature to the file */
        encodedSize = (unsigned long)hton_long((unsigned long) slen);
        br = fwrite(&encodedSize, 1, sizeof(encodedSize), ofp);
        br = fwrite(signature, 1, (int)slen, ofp);

        /* clean up */
        fclose(ifp);
        fclose(ofp);
    }

    C_CloseSession(hrSession);
    C_CloseSession(hsSession);

    return 0;
}

/*
**  Decrypt a file that was encrypted by the above function.
*/

#undef FN
#define FN "decryptFile:"

int
decryptFile( char * sender, char * recipient,
    char * ifile, char * ofile )
{
    CK_SLOT_ID hsSlot;
    CK_OBJECT_HANDLE hsKey = CK_INVALID_HANDLE;
    CK_SESSION_HANDLE hsSession;
    CK_SLOT_ID hrSlot;
    CK_OBJECT_HANDLE hrKey;
    CK_SESSION_HANDLE hrSession;
    CK_RV rv;
    CK_MECHANISM mech;
    CK_BYTE digest[80];
    CK_SIZE len;
    CK_OBJECT_HANDLE hKey;
    CK_BYTE wrappedKey[2 * 1024];
    CK_SIZE wrappedKeyLen;
    CK_BYTE signature[2 * 1024];
    CK_BYTE iv[8];
    unsigned long encodedSize;
    FILE * ifp;
    FILE * ofp;
    int br;

    ifp = fopen(ifile, "rb");
    if ( ifp == NULL ) {
        fprintf( stderr, "Cannot open %s for input\n", ifile );
        return -1;
    }
    ofp = fopen(ofile, "wb");
    if ( ofp == NULL ) {
        fprintf( stderr, "Cannot open %s for input\n", ofile );
        return -1;
    }

    if ( pflag ) {
        /* use PBE to do the encryption */
        static CK_OBJECT_CLASS at_class = CKO_SECRET_KEY;
        static CK_KEY_TYPE kt = CKK_DES2;
        static const CK_BBOOL True = TRUE;
        static const CK_BBOOL False = FALSE;
        CK_ATTRIBUTE attr[] = {
            {CKA_CLASS, &at_class, sizeof(at_class)},
            {CKA_KEY_TYPE, &kt, sizeof(at_class)},
            {CKA_EXTRACTABLE, (void*)&True, sizeof(True)},
            {CKA_SENSITIVE, (void*)&False, sizeof(False)},
            {CKA_DERIVE, (void*)&True, sizeof(True)}
        };
        CK_BYTE iv[8];
        CK_PBE_PARAMS params;
        memset(&params, 0x0, sizeof(CK_PBE_PARAMS));
        params.pInitVector = iv;
        params.pPassword = (CK_CHAR_PTR)sender;
        params.passwordLen = strlen(sender);
        params.pSalt = NULL;
        params.saltLen = 0;
        params.iteration = 1;

        memset(&mech, 0x0, sizeof(CK_MECHANISM));
        mech.mechanism = CKM_PBE_SHA1_DES2_EDE_CBC;
        mech.pParameter = &params;
        mech.parameterLen = sizeof(CK_PBE_PARAMS);

        rv = C_OpenSession(0, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL,
                &hsSession);
        if ( rv ) return 1;
        hrSession = hsSession;

        rv = C_GenerateKey(hsSession, &mech, attr, NUMITEMS(attr), &hKey);
        CHECK_RV(FN "C_GenerateKey:CKM_PBE_SHA1_DES2_EDE_CBC", rv);
        if ( rv ) return 1;

        memset(&mech, 0x0, sizeof(CK_MECHANISM));
        mech.mechanism = CKM_SHA1_KEY_DERIVATION;

        rv = C_DeriveKey(hsSession, &mech, hKey, attr, NUMITEMS(attr), &hrKey);
        CHECK_RV(FN "C_DeriveKey:CKM_SHA1_KEY_DERIVATION", rv);
        if ( rv ) return 1;
    }
    else {
        /* decrypting */
        rv = FindKeyFromName(sender, CKO_CERTIFICATE,
            &hsSlot, &hsSession, &hsKey);
        if ( rv ) {
            rv = FindKeyFromName(sender, CKO_PUBLIC_KEY,
                &hsSlot, &hsSession, &hsKey);
        }
        if ( rv ) {
            fprintf( stderr, "Unable to access sender (%s) key\n", sender );
            CHECK_RV(FN "FindKeyFromName", rv);
            if ( rv ) return 1;
        }
        rv = FindKeyFromName(recipient, CKO_PRIVATE_KEY,
            &hrSlot, &hrSession, &hrKey);
        if ( rv ) {
            fprintf( stderr, "Unable to access recipient (%s) key\n",
                    recipient );
            CHECK_RV(FN "FindKeyFromName", rv);
            if ( rv ) return 1;
        }

        /* read the encrypted key to the file */
        br = fread(&encodedSize, 1, sizeof(encodedSize), ifp);
        wrappedKeyLen = (CK_SIZE) ntoh_long((unsigned long) encodedSize);
        br = fread(wrappedKey, 1, (int)wrappedKeyLen, ifp);

        /* unwrap the decryption key with the recipients private key */
        memset(&mech,0,sizeof(mech));
        mech.mechanism = CKM_RSA_PKCS;
        rv = C_UnwrapKey(hrSession, &mech, hrKey,
                wrappedKey, wrappedKeyLen,
                wrappedKeyTemp, NUMITEMS(wrappedKeyTemp),
                &hKey );
        CHECK_RV(FN "C_UnwrapKey", rv);
        if ( rv ) return 1;
    }

    /* set up the decryption ooperation using the random key */
    memset(&mech, 0, sizeof(CK_MECHANISM));
    mech.mechanism = CKM_DES3_CBC_PAD;
    memset(iv, 0, sizeof(iv));
    mech.pParameter = iv;
    mech.parameterLen = sizeof(iv);
    rv = C_DecryptInit(hrSession, &mech, hKey);
    CHECK_RV(FN"C_EncryptInit", rv);
    if ( rv ) return 1;

    /* Set up the digest operation */
    memset(&mech, 0, sizeof(CK_MECHANISM));
    mech.mechanism = CKM_SHA_1;
    rv = C_DigestInit(hrSession, &mech);
    CHECK_RV(FN "C_DigestInit", rv);
    if ( rv ) return 1;

    {
        CK_SIZE curLen;
        CK_SIZE slen;
        unsigned char buffer[10 * 1024];
        unsigned char decbuffer[10 * 1024];
        unsigned int br;

        br = fread(&encodedSize, 1, sizeof(encodedSize), ifp);
        encodedSize = (unsigned long)hton_long(encodedSize);
        for ( ;encodedSize > 0; ) {
            br = sizeof(buffer);
            if ( encodedSize < br )
                br = (unsigned int)encodedSize;
            br = fread(buffer, 1, br, ifp);
            encodedSize -= br;
            if ( br ) {
                curLen = sizeof(decbuffer);
                rv = C_DecryptUpdate(hrSession, buffer, (CK_SIZE) br,
                    decbuffer, &curLen);
                CHECK_RV(FN "C_DecryptUpdate", rv);
                if ( rv ) return 1;
                rv = C_DigestUpdate(hrSession, decbuffer, curLen);
                CHECK_RV(FN "C_DigestUpdate", rv);
                if ( rv ) return 1;
                br = fwrite(decbuffer, 1, (unsigned int)curLen, ofp);
            }
        }
        curLen = sizeof(decbuffer);
        rv = C_DecryptFinal(hrSession, decbuffer, &curLen);
        CHECK_RV(FN "C_DecryptFinal", rv);
        if ( rv ) return 1;
        if ( curLen ) {
            br = fwrite(decbuffer, 1, (unsigned int)curLen, ofp);
            rv = C_DigestUpdate(hrSession, decbuffer, curLen);
            CHECK_RV(FN "C_DigestUpdate", rv);
        }
        len = sizeof(digest);
        rv = C_DigestFinal(hrSession, digest, &len);
        CHECK_RV(FN "C_DigestFinal", rv);
        if ( rv ) return 1;

        /* read the signature from the file */
        br = fread(&encodedSize, 1, sizeof(encodedSize), ifp);
        slen = (CK_SIZE) ntoh_long((unsigned long) encodedSize);
        br = fread(signature, 1, (unsigned int)slen, ifp);

        if ( pflag ) {
            if ( memcmp(digest, signature, len) ) {
                fprintf( stderr, "Verify failed\n" );
                return 1;
            }
        }
        else {
            /* Set up the signature verify operation */
            memset(&mech, 0, sizeof(CK_MECHANISM));
            mech.mechanism = CKM_RSA_PKCS;
            rv = C_VerifyInit(hsSession, &mech, hsKey);
            CHECK_RV(FN "C_VerifyInit", rv);
            if ( rv ) return 1;
            rv = C_Verify(hsSession, digest, len, signature, slen);
            if ( rv ) {
                CT_ErrorString(rv,ErrorString,sizeof(ErrorString));
                fprintf( stderr, "Verify failed 0x%lx, %s\n", rv, ErrorString );
            }
        }

        /* clean up */
        fclose(ifp);
        fclose(ofp);
    }

    C_CloseSession(hrSession);
    C_CloseSession(hsSession);

    return (int)rv;
}
